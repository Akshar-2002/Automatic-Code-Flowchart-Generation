def place_analysis_summary_report(feature, parent):
    """Retrieve an HTML place analysis table report from a multi exposure
    analysis.
    """
    _ = feature, parent  # NOQA
    analysis_dir = get_analysis_dir(exposure_place['key'])
    if analysis_dir:
        return get_impact_report_as_string(analysis_dir)
    return None