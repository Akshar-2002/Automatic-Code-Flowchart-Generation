def services(self):
        """
        Gets the services object which will provide the ArcGIS Server's
        admin information about services and folders.
        """
        if self._resources is None:
            self.__init()
        if "services" in self._resources:
            url = self._url + "/services"
            return _services.Services(url=url,
                                      securityHandler=self._securityHandler,
                                      proxy_url=self._proxy_url,
                                      proxy_port=self._proxy_port,
                                      initialize=True)
        else:
            return None