def parse(self):
        """ parse data """
        url = self.config.get('url')
        self.cnml = CNMLParser(url)
        self.parsed_data = self.cnml.getNodes()