def Update(self,name,description=None,location=None):
		"""Updates the attributes of a given Network via PUT.

		https://www.ctl.io/api-docs/v2/#networks-update-network

		{
      "name": "VLAN for Development Servers",
      "description": "Development Servers on 11.22.33.0/24"
		}

		Returns a 204 and no content
		"""

		if not location:  location = clc.v2.Account.GetLocation(session=self.session)

		payload = {'name': name}
		payload['description'] = description if description else self.description

		r = clc.v2.API.Call('PUT','/v2-experimental/networks/%s/%s/%s' % (self.alias, location, self.id), payload, session=self.session)

		self.name = self.data['name'] = name
		if description: self.data['description'] = description