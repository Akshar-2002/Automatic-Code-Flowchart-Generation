def markov_blanket(y, mean, scale, shape, skewness):
        """ Markov blanket for the Exponential distribution

        Parameters
        ----------
        y : np.ndarray
            univariate time series

        mean : np.ndarray
            array of location parameters for the Exponential distribution

        scale : float
            scale parameter for the Exponential distribution

        shape : float
            tail thickness parameter for the Exponential distribution

        skewness : float
            skewness parameter for the Exponential distribution

        Returns
        ----------
        - Markov blanket of the Exponential family
        """
        return ss.expon.logpdf(x=y, scale=1/mean)