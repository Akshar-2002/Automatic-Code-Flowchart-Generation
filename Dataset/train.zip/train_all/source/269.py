def center(self, width, fillchar=None):
        """Return centered in a string of length width. Padding is done using the specified fill character or space.

        :param int width: Length of output string.
        :param str fillchar: Use this character instead of spaces.
        """
        if fillchar is not None:
            result = self.value_no_colors.center(width, fillchar)
        else:
            result = self.value_no_colors.center(width)
        return self.__class__(result.replace(self.value_no_colors, self.value_colors), keep_tags=True)