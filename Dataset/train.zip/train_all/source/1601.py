def _mk_uninit_array(self, bounds):
        """ given a list of bounds for the N dimensions of an array, 
            _mk_uninit_array() creates and returns an N-dimensional array of 
            the size specified by the bounds with each element set to the value
            None."""
        if len(bounds) == 0:
            raise For2PyError("Zero-length arrays current not handled!.")

        this_dim = bounds[0]
        lo,hi = this_dim[0],this_dim[1]
        sz = hi-lo+1

        if len(bounds) == 1:
            return [None] * sz

        sub_array = self._mk_uninit_array(bounds[1:])
        this_array = [copy.deepcopy(sub_array) for i in range(sz)]

        return this_array