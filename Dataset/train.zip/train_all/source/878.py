def attributes(self, **kwargs):  # pragma: no cover
        """Retrieve the attribute configuration object.

        Retrieves a mapping that identifies the custom directory
        attributes configured for the Directory SyncService instance,
        and the mapping of the custom attributes to standard directory
        attributes.

        Args:
            **kwargs: Supported :meth:`~pancloud.httpclient.HTTPClient.request` parameters.

        Returns:
            requests.Response: Requests Response() object.

        Examples:
            Refer to ``directory_attributes.py`` example.

        """
        path = "/directory-sync-service/v1/attributes"
        r = self._httpclient.request(
            method="GET",
            path=path,
            url=self.url,
            **kwargs
        )
        return r