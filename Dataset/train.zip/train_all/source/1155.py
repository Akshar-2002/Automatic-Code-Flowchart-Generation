def stop(self):
        """Stop this gateway agent."""

        if self._disconnector:
            self._disconnector.stop()

        self.client.disconnect()