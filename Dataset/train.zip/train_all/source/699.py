def add_language_to_project(self, project_id, language_code):
        """
        Adds a new language to project
        """
        self._run(
            url_path="languages/add",
            id=project_id,
            language=language_code
        )
        return True