def getMibSymbol(self):
        """Returns MIB variable symbolic identification.

        Returns
        -------
        str
             MIB module name
        str
             MIB variable symbolic name
        : :py:class:`~pysnmp.proto.rfc1902.ObjectName`
             class instance representing MIB variable instance index.

        Raises
        ------
        SmiError
            If MIB variable conversion has not been performed.

        Examples
        --------
        >>> objectIdentity = ObjectIdentity('1.3.6.1.2.1.1.1.0')
        >>> objectIdentity.resolveWithMib(mibViewController)
        >>> objectIdentity.getMibSymbol()
        ('SNMPv2-MIB', 'sysDescr', (0,))
        >>>
        """
        if self._state & self.ST_CLEAN:
            return self._modName, self._symName, self._indices

        else:
            raise SmiError(
                '%s object not fully initialized' % self.__class__.__name__)