def _servicegroup_get_servers(sg_name, **connection_args):
    '''
    Returns a list of members of a servicegroup or None
    '''
    nitro = _connect(**connection_args)
    if nitro is None:
        return None
    sg = NSServiceGroup()
    sg.set_servicegroupname(sg_name)
    try:
        sg = NSServiceGroup.get_servers(nitro, sg)
    except NSNitroError as error:
        log.debug('netscaler module error - NSServiceGroup.get_servers failed(): %s', error)
        sg = None
    _disconnect(nitro)
    return sg