def buildMask(dqarr, bitvalue):
    """ Builds a bit-mask from an input DQ array and a bitvalue flag """
    return bitfield_to_boolean_mask(dqarr, bitvalue, good_mask_value=1,
                                    dtype=np.uint8)