def create_pull(self, *args, **kwds):
        """
        :calls: `POST /repos/:owner/:repo/pulls <http://developer.github.com/v3/pulls>`_
        :param title: string
        :param body: string
        :param issue: :class:`github.Issue.Issue`
        :param base: string
        :param head: string
        :param maintainer_can_modify: bool
        :rtype: :class:`github.PullRequest.PullRequest`
        """
        if len(args) + len(kwds) >= 4:
            return self.__create_pull_1(*args, **kwds)
        else:
            return self.__create_pull_2(*args, **kwds)