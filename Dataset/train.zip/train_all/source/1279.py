def _TypecheckDecorator(subject=None, **kwargs):
  """Dispatches type checks based on what the subject is.

  Functions or methods are annotated directly. If this method is called
  with keyword arguments only, return a decorator.
  """
  if subject is None:
    return _TypecheckDecoratorFactory(kwargs)
  elif inspect.isfunction(subject) or inspect.ismethod(subject):
    return _TypecheckFunction(subject, {}, 2, None)
  else:
    raise TypeError()