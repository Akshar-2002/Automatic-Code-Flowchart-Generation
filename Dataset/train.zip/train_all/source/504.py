def _reorder_csv(d, filename=""):
    """
    Preserve the csv column ordering before writing back out to CSV file. Keep column data consistent with JSONLD
    column number alignment.
    { "var1" : {"number": 1, "values": [] }, "var2": {"number": 1, "values": [] } }

    :param dict d: csv data
    :param str filename: Filename
    :return dict: csv data
    """
    _ensemble = is_ensemble(d)
    _d2 = []
    try:
        if _ensemble:
            # 1 column ensemble: realizations
            if len(d) == 1:
                for var, data in d.items():
                    if "values" in data:
                        _d2 = data["values"]
            # 2 column ensemble: depth and realizations
            else:
                _count = 0
                # count up how many columns total, and how many placeholders to make in our list
                for var, data in d.items():
                    if isinstance(data["number"], list):
                        _curr_count = len(data["number"])
                        _count += _curr_count
                    elif isinstance(data["number"], (int, float, str)):
                        _count += 1
                # make a list with X number of placeholders
                _d2 = [None for i in range(0, _count)]
                # Loop again and start combining all columns into one list of lists
                for var, data in d.items():
                    # realizations: insert at (hopefully) index 1,2...1001
                    if isinstance(data["number"], list):
                        for idx, number in enumerate(data["number"]):
                            # we can't trust the number entries. sometimes they start at "number 1",
                            # which isn't true, because DEPTH is number 1. Use enumerate index instead.
                            _insert_at = int(idx) + 1
                            # Insert at one above the index. Grab values at exact index
                            _d2[_insert_at] = data["values"][idx-1]

                    # depth column: insert at (hopefully) index 0
                    else:
                        # we can trust to use the number entry as an index placement
                        _insert_at = int(data["number"]) - 1
                        # insert at one below number, to compensate for 0-index
                        _d2[_insert_at] = data["values"]
        else:
            _count = len(d)
            _d2 = [None for i in range(0, _count)]
            for key, data in d.items():
                _insert_at = int(data["number"]) - 1
                _d2[_insert_at] = data["values"]

    except Exception as e:
        print("Error: Unable to write CSV: There was an error trying to prep the values for file write: {}".format(e))
        logger_csvs.error("reorder_csvs: Unable to write CSV file: {}, {}".format(filename, e))
    return _d2