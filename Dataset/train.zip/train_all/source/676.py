def perform(self, cfg):
        """
        Performs transformation according to configuration
        :param cfg: transformation configuration
        """
        self.__src = self._load(cfg[Transformation.__CFG_KEY_LOAD])
        self.__transform(cfg[Transformation.__CFG_KEY_TRANSFORM])
        self.__cleanup(cfg[Transformation.__CFG_KEY_CLEANUP])
        self.__save(cfg[Transformation.__CFG_KEY_SAVE])