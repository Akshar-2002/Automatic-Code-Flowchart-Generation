def monkeycache(apis):
    """
    Feed this a dictionary of api bananas, it spits out processed cache
    """
    if isinstance(type(apis), type(None)) or apis is None:
        return {}

    verbs = set()
    cache = {}
    cache['count'] = apis['count']
    cache['asyncapis'] = []

    apilist = apis['api']
    if apilist is None:
        print("[monkeycache] Server response issue, no apis found")

    for api in apilist:
        name = getvalue(api, 'name')
        verb, subject = splitverbsubject(name)

        apidict = {}
        apidict['name'] = name
        apidict['description'] = getvalue(api, 'description')
        apidict['isasync'] = getvalue(api, 'isasync')
        if apidict['isasync']:
            cache['asyncapis'].append(name)
        apidict['related'] = splitcsvstring(getvalue(api, 'related'))

        required = []
        apiparams = []
        for param in getvalue(api, 'params'):
            apiparam = {}
            apiparam['name'] = getvalue(param, 'name')
            apiparam['description'] = getvalue(param, 'description')
            apiparam['required'] = (getvalue(param, 'required') is True)
            apiparam['length'] = int(getvalue(param, 'length'))
            apiparam['type'] = getvalue(param, 'type')
            apiparam['related'] = splitcsvstring(getvalue(param, 'related'))
            if apiparam['required']:
                required.append(apiparam['name'])
            apiparams.append(apiparam)

        apidict['requiredparams'] = required
        apidict['params'] = apiparams
        if verb not in cache:
            cache[verb] = {}
        cache[verb][subject] = apidict
        verbs.add(verb)

    cache['verbs'] = list(verbs)
    return cache