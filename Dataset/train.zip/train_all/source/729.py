def config(self, name, suffix):
        "Return config variable value, defaulting to environment"
        var = '%s_%s' % (name, suffix)
        var = var.upper().replace('-', '_')
        if var in self._config:
            return self._config[var]
        return os.environ[var]