def make_chunk(chunk_type, chunk_data):
	"""Create a raw chunk by composing chunk type and data. It
	calculates chunk length and CRC for you.

	:arg str chunk_type: PNG chunk type.
	:arg bytes chunk_data: PNG chunk data, **excluding chunk length, type, and CRC**.
	:rtype: bytes
	"""
	out = struct.pack("!I", len(chunk_data))
	chunk_data = chunk_type.encode("latin-1") + chunk_data
	out += chunk_data + struct.pack("!I", binascii.crc32(chunk_data) & 0xffffffff)
	return out