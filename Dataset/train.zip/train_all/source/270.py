def get(self, action, version=None):
        """Get the method class handing the given action and version."""
        by_version = self._by_action[action]
        if version in by_version:
            return by_version[version]
        else:
            return by_version[None]