def _generic_search(cls, name, search_string, metadata={}, ignore=''):
        """ Searches for a specific string given three types of regex search types.  Also auto-checks for camel casing.

        :param name: str, name of object in question
        :param search_string: str, string to find and insert into the search regexes
        :param metadata: dict, metadata to add to the result if we find a match
        :param ignore: str, ignore specific string for the search
        :return: dict, dictionary of search results
        """
        patterns = [cls.REGEX_ABBR_SEOS,
                    cls.REGEX_ABBR_ISLAND,
                    cls.REGEX_ABBR_CAMEL]

        if not search_string[0].isupper():
            patterns.remove(cls.REGEX_ABBR_CAMEL)

        for pattern in patterns:
            search_result = cls._get_regex_search(name,
                                                  pattern.format(ABBR=search_string, SEP=cls.REGEX_SEPARATORS),
                                                  metadata=metadata,
                                                  match_index=0,
                                                  ignore=ignore)
            if search_result is not None:
                if cls.is_valid_camel(search_result.get('match_full'), strcmp=search_result.get('match')):
                    return search_result
        return None