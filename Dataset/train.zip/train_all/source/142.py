def cast_problem(problem):
    """
    Casts problem object with known interface as OptProblem.

    Parameters
    ----------
    problem : Object
    """
    
    # Optproblem
    if isinstance(problem,OptProblem):
        return problem
    
    # Other
    else:
        
        # Type Base
        if (not hasattr(problem,'G') or 
            (problem.G.shape[0] == problem.G.shape[1] and
             problem.G.shape[0] == problem.G.nnz and
             np.all(problem.G.row == problem.G.col) and 
             np.all(problem.G.data == 1.))):
            return create_problem_from_type_base(problem)

        # Type A
        else:
            return create_problem_from_type_A(problem)