def _ordered_categories(df, categories):
    """
    Make the columns in df categorical

    Parameters:
    -----------
    categories: dict
        Of the form {str: list},
        where the key the column name and the value is
        the ordered category list
    """
    for col, cats in categories.items():
        df[col] = df[col].astype(CategoricalDtype(cats, ordered=True))
    return df