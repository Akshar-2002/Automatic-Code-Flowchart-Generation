def choice(*es):
    """
    Create a PEG function to match an ordered choice.
    """
    msg = 'Expected one of: {}'.format(', '.join(map(repr, es)))
    def match_choice(s, grm=None, pos=0):
        errs = []
        for e in es:
            try:
                return e(s, grm, pos)
            except PegreError as ex:
                errs.append((ex.message, ex.position))
        if errs:
            raise PegreChoiceError(errs, pos)
    return match_choice