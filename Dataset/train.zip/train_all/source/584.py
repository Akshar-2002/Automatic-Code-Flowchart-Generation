def usage_records(self):
        """
        Access the usage_records

        :returns: twilio.rest.wireless.v1.sim.usage_record.UsageRecordList
        :rtype: twilio.rest.wireless.v1.sim.usage_record.UsageRecordList
        """
        if self._usage_records is None:
            self._usage_records = UsageRecordList(self._version, sim_sid=self._solution['sid'], )
        return self._usage_records