def _set_enhanced_voq_max_queue_depth(self, v, load=False):
    """
    Setter method for enhanced_voq_max_queue_depth, mapped from YANG variable /telemetry/profile/enhanced_voq_max_queue_depth (list)
    If this variable is read-only (config: false) in the
    source YANG file, then _set_enhanced_voq_max_queue_depth is considered as a private
    method. Backends looking to populate this variable should
    do so via calling thisObj._set_enhanced_voq_max_queue_depth() directly.
    """
    if hasattr(v, "_utype"):
      v = v._utype(v)
    try:
      t = YANGDynClass(v,base=YANGListType("name",enhanced_voq_max_queue_depth.enhanced_voq_max_queue_depth, yang_name="enhanced-voq-max-queue-depth", rest_name="enhanced-voq-max-queue-depth", parent=self, is_container='list', user_ordered=False, path_helper=self._path_helper, yang_keys='name', extensions={u'tailf-common': {u'cli-full-command': None, u'cli-suppress-list-no': None, u'callpoint': u'EnhancedVoqMaxQueueDepthProfile', u'info': u'Enhanced VOQ max queue depth'}}), is_container='list', yang_name="enhanced-voq-max-queue-depth", rest_name="enhanced-voq-max-queue-depth", parent=self, path_helper=self._path_helper, extmethods=self._extmethods, register_paths=True, extensions={u'tailf-common': {u'cli-full-command': None, u'cli-suppress-list-no': None, u'callpoint': u'EnhancedVoqMaxQueueDepthProfile', u'info': u'Enhanced VOQ max queue depth'}}, namespace='urn:brocade.com:mgmt:brocade-telemetry', defining_module='brocade-telemetry', yang_type='list', is_config=True)
    except (TypeError, ValueError):
      raise ValueError({
          'error-string': """enhanced_voq_max_queue_depth must be of a type compatible with list""",
          'defined-type': "list",
          'generated-type': """YANGDynClass(base=YANGListType("name",enhanced_voq_max_queue_depth.enhanced_voq_max_queue_depth, yang_name="enhanced-voq-max-queue-depth", rest_name="enhanced-voq-max-queue-depth", parent=self, is_container='list', user_ordered=False, path_helper=self._path_helper, yang_keys='name', extensions={u'tailf-common': {u'cli-full-command': None, u'cli-suppress-list-no': None, u'callpoint': u'EnhancedVoqMaxQueueDepthProfile', u'info': u'Enhanced VOQ max queue depth'}}), is_container='list', yang_name="enhanced-voq-max-queue-depth", rest_name="enhanced-voq-max-queue-depth", parent=self, path_helper=self._path_helper, extmethods=self._extmethods, register_paths=True, extensions={u'tailf-common': {u'cli-full-command': None, u'cli-suppress-list-no': None, u'callpoint': u'EnhancedVoqMaxQueueDepthProfile', u'info': u'Enhanced VOQ max queue depth'}}, namespace='urn:brocade.com:mgmt:brocade-telemetry', defining_module='brocade-telemetry', yang_type='list', is_config=True)""",
        })

    self.__enhanced_voq_max_queue_depth = t
    if hasattr(self, '_set'):
      self._set()