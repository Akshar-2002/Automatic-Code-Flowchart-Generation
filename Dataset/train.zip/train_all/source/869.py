def make_response(self, image, size, mode, filename=None, *args, **kwargs):
        """
        :param image: image as bytes
        :param size: requested maximum width/height size
        :param mode: one of 'scale', 'fit' or 'crop'
        :param filename: filename
        """
        try:
            fmt = get_format(image)
        except IOError:
            # not a known image file
            raise NotFound()

        self.content_type = "image/png" if fmt == "PNG" else "image/jpeg"
        ext = "." + str(fmt.lower())

        if not filename:
            filename = "image"
        if not filename.lower().endswith(ext):
            filename += ext
        self.filename = filename

        if size:
            image = resize(image, size, size, mode=mode)
            if mode == CROP:
                assert get_size(image) == (size, size)
        else:
            image = image.read()

        return make_response(image)