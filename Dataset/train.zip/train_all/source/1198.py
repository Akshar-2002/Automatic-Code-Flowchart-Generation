def report_change(self, name, value, maxdiff=1, deltat=10):
        '''report a sensor change'''
        r = self.reports[name]
        if time.time() < r.last_report + deltat:
            return
        r.last_report = time.time()
        if math.fabs(r.value - value) < maxdiff:
            return
        r.value = value
        self.say("%s %u" % (name, value))