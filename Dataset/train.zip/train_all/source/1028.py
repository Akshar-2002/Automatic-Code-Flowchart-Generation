def hacking_has_only_comments(physical_line, filename, lines, line_number):
    """Check for empty files with only comments

    H104 empty file with only comments
    """
    if line_number == 1 and all(map(EMPTY_LINE_RE.match, lines)):
        return (0, "H104: File contains nothing but comments")