def _add_bad_rc(self, rc, result):
        """
        Sets an error with a bad return code. Handles 'quiet' logic
        :param rc: The error code
        """
        if not rc:
            return

        self.all_ok = False
        if rc == C.LCB_KEY_ENOENT and self._quiet:
            return

        try:
            raise pycbc_exc_lcb(rc)
        except PyCBC.default_exception as e:
            e.all_results = self
            e.key = result.key
            e.result = result
            self._add_err(sys.exc_info())