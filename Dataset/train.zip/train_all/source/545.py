def get(self, rel_path, cb=None):
        '''Return the file path referenced but rel_path, or None if
        it can't be found. If an upstream is declared, it will try to get the file
        from the upstream before declaring failure.
        '''
        import shutil

        global_logger.debug(
            "LC {} get looking for {}".format(
                self.repo_id,
                rel_path))

        path = os.path.join(self.cache_dir, rel_path)

        # If is already exists in the repo, just return it.
        if os.path.exists(path):

            if not os.path.isfile(path):
                raise ValueError("Path does not point to a file")

            global_logger.debug(
                "LC {} get {} found ".format(
                    self.repo_id,
                    path))
            return path

        if not self.upstream:
            # If we don't have an upstream, then we are done.
            return None

        stream = self.upstream.get_stream(rel_path, cb=cb)

        if not stream:
            global_logger.debug(
                "LC {} get not found in upstream ()".format(
                    self.repo_id,
                    rel_path))
            return None

        # Got a stream from upstream, so put the file in this cache.
        dirname = os.path.dirname(path)
        if not os.path.isdir(dirname):
            os.makedirs(dirname)

        # Copy the file from the lower cache into this cache.
        with open(path, 'w') as f:
            shutil.copyfileobj(stream, f)

        # Since we've added a file, must keep track of the sizes.
        size = os.path.getsize(path)
        self._free_up_space(size, this_rel_path=rel_path)
        self.add_record(rel_path, size)

        stream.close()

        if not os.path.exists(path):
            raise Exception("Failed to copy upstream data to {} ".format(path))

        global_logger.debug(
            "LC {} got return from upstream {} -> {} ".format(self.repo_id, rel_path, path))
        return path