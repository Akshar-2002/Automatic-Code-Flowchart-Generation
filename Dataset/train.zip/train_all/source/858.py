def inc_n(self, n, exception=None):  # type: (int, Optional[ParseError]) -> bool
        """
        Increments the parser by n characters
        if the end of the input has not been reached.
        """
        return self._src.inc_n(n=n, exception=exception)