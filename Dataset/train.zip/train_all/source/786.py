def age(self, as_at_date=None):
        """
        Compute the person's age
        """
        if self.date_of_death != None or self.is_deceased == True:
            return None

        as_at_date = date.today() if as_at_date == None else as_at_date
        
        if self.date_of_birth != None:
            if (as_at_date.month >= self.date_of_birth.month) and (as_at_date.day >= self.date_of_birth.day):
                return (as_at_date.year - self.date_of_birth.year)
            else:
                return ((as_at_date.year - self.date_of_birth.year) -1)
        else:
            return None