def enum(number, zone='e164.arpa'):
    '''
    Printable DNS ENUM (telephone number mapping) record.

    :param number: string
    :param zone: string


    >>> print(enum('+31 20 5423 1567'))
    7.6.5.1.3.2.4.5.0.2.1.3.e164.arpa.
    >>> print(enum('+31 97 99 6642', zone='e164.spacephone.org'))
    2.4.6.6.9.9.7.9.1.3.e164.spacephone.org.

    '''
    number = e164(number).lstrip('+')
    return u'.'.join([
        u'.'.join(number[::-1]),
        zone.strip(u'.'),
        '',
    ])