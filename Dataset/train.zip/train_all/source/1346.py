async def _query_json(
        self, path, method="GET", *, params=None, data=None, headers=None, timeout=None
    ):
        """
        A shorthand of _query() that treats the input as JSON.
        """
        if headers is None:
            headers = {}
        headers["content-type"] = "application/json"
        if not isinstance(data, (str, bytes)):
            data = json.dumps(data)
        response = await self._query(
            path, method, params=params, data=data, headers=headers, timeout=timeout
        )
        data = await parse_result(response)
        return data