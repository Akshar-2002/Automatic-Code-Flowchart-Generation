def adjust_hours_view(request, semester):
    """
    Adjust members' workshift hours requirements.
    """
    page_name = "Adjust Hours"

    pools = WorkshiftPool.objects.filter(semester=semester).order_by(
        "-is_primary", "title",
    )
    workshifters = WorkshiftProfile.objects.filter(semester=semester)
    pool_hour_forms = []

    for workshifter in workshifters:
        forms_list = []
        for pool in pools:
            hours = workshifter.pool_hours.get(pool=pool)
            forms_list.append((
                AdjustHoursForm(
                    data=request.POST or None,
                    prefix="pool_hours-{}".format(hours.pk),
                    instance=hours,
                ),
                hours,
            ))
        pool_hour_forms.append(forms_list)

    if all(
            form.is_valid()
            for workshifter_forms in pool_hour_forms
            for form, pool_hours in workshifter_forms
    ):
        for workshifter_forms in pool_hour_forms:
            for form, pool_hours in workshifter_forms:
                form.save()
        messages.add_message(request, messages.INFO, "Updated hours.")
        return HttpResponseRedirect(wurl(
            "workshift:adjust_hours",
            sem_url=semester.sem_url,
        ))

    return render_to_response("adjust_hours.html", {
        "page_name": page_name,
        "pools": pools,
        "workshifters_tuples": zip(workshifters, pool_hour_forms),
    }, context_instance=RequestContext(request))