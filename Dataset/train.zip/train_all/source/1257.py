def get_permalink_ids_iter(self):
    '''
    Method to get permalink ids from content. To be bound to the class last
    thing.
    '''
    permalink_id_key = self.settings['PERMALINK_ID_METADATA_KEY']
    permalink_ids = self.metadata.get(permalink_id_key, '')

    for permalink_id in permalink_ids.split(','):
        if permalink_id:
            yield permalink_id.strip()