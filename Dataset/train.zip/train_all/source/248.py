def get_vlan_brief_output_vlan_vlan_name(self, **kwargs):
        """Auto Generated Code
        """
        config = ET.Element("config")
        get_vlan_brief = ET.Element("get_vlan_brief")
        config = get_vlan_brief
        output = ET.SubElement(get_vlan_brief, "output")
        vlan = ET.SubElement(output, "vlan")
        vlan_id_key = ET.SubElement(vlan, "vlan-id")
        vlan_id_key.text = kwargs.pop('vlan_id')
        vlan_name = ET.SubElement(vlan, "vlan-name")
        vlan_name.text = kwargs.pop('vlan_name')

        callback = kwargs.pop('callback', self._callback)
        return callback(config)