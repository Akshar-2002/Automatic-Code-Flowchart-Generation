def add_argument(self, *args, **kwargs):
        """
        Add a parameter to this app.
        """
        if not (('action' in kwargs) and (kwargs['action'] == 'help')):
            # make sure required parameter options were defined
            try:
                name = kwargs['dest']
                param_type = kwargs['type']
                optional = kwargs['optional']
            except KeyError as e:
                detail = "%s option required. " % e
                raise KeyError(detail)
            if optional and ('default' not in kwargs):
                detail = "A default value is required for optional parameters %s." % name
                raise KeyError(detail)

            # grab the default and help values
            default = None
            if 'default' in kwargs:
                default = kwargs['default']
            param_help = ""
            if 'help' in kwargs:
                param_help = kwargs['help']

            # set the ArgumentParser's action
            if param_type not in (str, int, float, bool, ChrisApp.path):
                detail = "unsupported type: '%s'" % param_type
                raise ValueError(detail)
            action = 'store'
            if param_type == bool:
                action = 'store_false' if default else 'store_true'
                del kwargs['default'] # 'default' and 'type' not allowed for boolean actions
                del kwargs['type']
            kwargs['action'] = action

            # store the parameters internally (param_type.__name__ to enable json serialization)
            param = {'name': name, 'type': param_type.__name__, 'optional': optional,
                     'flag': args[0], 'action': action, 'help': param_help, 'default': default}
            self._parameters.append(param)

            # add the parameter to the parser
            del kwargs['optional']
        ArgumentParser.add_argument(self, *args, **kwargs)