def optimise_levenberg_marquardt(x, a, c, damping=0.001, tolerance=0.001):
    """
    Optimise value of x using levenberg-marquardt
    """
    x_new = x
    x_old = x-1 # dummy value
    f_old = f(x_new, a, c)
    while np.abs(x_new - x_old).sum() > tolerance:
        x_old = x_new
        x_tmp = levenberg_marquardt_update(x_old, a, c, damping)
        f_new = f(x_tmp, a, c)
        if f_new < f_old:
            damping = np.max(damping/10., 1e-20)
            x_new = x_tmp
            f_old = f_new
        else:
            damping *= 10.
    return x_new