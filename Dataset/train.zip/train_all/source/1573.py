def _close(self, name, suppress_logging):
        """ closes one particular pool and all its amqp amqp connections """
        try:
            pool_names = list(self.pools)
            if name in pool_names:
                self.pools[name].close()
                del self.pools[name]
        except Exception as e:
            self.logger.error('Exception on closing Flopsy Pool for {0}: {1}'.format(name, e),
                              exc_info=not suppress_logging)