def create_geometry(self, input_geometry, dip, upper_depth, lower_depth,
                        mesh_spacing=1.0):
        '''
        If geometry is defined as a numpy array then create instance of
        nhlib.geo.line.Line class, otherwise if already instance of class
        accept class

        :param input_geometry:
            Trace (line) of the fault source as either
            i) instance of nhlib.geo.line.Line class
            ii) numpy.ndarray [Longitude, Latitude]

        :param float dip:
            Dip of fault surface (in degrees)

        :param float upper_depth:
            Upper seismogenic depth (km)

        :param float lower_depth:
            Lower seismogenic depth (km)

        :param float mesh_spacing:
            Spacing of the fault mesh (km) {default = 1.0}
        '''
        assert((dip > 0.) and (dip <= 90.))
        self.dip = dip
        self._check_seismogenic_depths(upper_depth, lower_depth)

        if not isinstance(input_geometry, Line):
            if not isinstance(input_geometry, np.ndarray):
                raise ValueError('Unrecognised or unsupported geometry '
                                 'definition')
            else:
                self.fault_trace = Line([Point(row[0], row[1]) for row in
                                         input_geometry])
        else:
            self.fault_trace = input_geometry
        # Build fault surface
        self.geometry = SimpleFaultSurface.from_fault_data(self.fault_trace,
                                                           self.upper_depth,
                                                           self.lower_depth,
                                                           self.dip,
                                                           mesh_spacing)