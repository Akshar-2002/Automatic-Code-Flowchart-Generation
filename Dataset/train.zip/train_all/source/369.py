async def home_plunger(self, mount: top_types.Mount):
        """
        Home the plunger motor for a mount, and then return it to the 'bottom'
        position.

        :param mount: the mount associated with the target plunger
        :type mount: :py:class:`.top_types.Mount`
        """
        instr = self._attached_instruments[mount]
        if instr:
            await self.home([Axis.of_plunger(mount)])
            await self._move_plunger(mount,
                                     instr.config.bottom)