def map_get(self, key, mapkey):
        """
        Retrieve a value from a map.

        :param str key: The document ID
        :param str mapkey: Key within the map to retrieve
        :return: :class:`~.ValueResult`
        :raise: :exc:`IndexError` if the mapkey does not exist
        :raise: :cb_exc:`NotFoundError` if the document does not exist.

        .. seealso:: :meth:`map_add` for an example
        """
        op = SD.get(mapkey)
        sdres = self.lookup_in(key, op)
        return self._wrap_dsop(sdres, True)