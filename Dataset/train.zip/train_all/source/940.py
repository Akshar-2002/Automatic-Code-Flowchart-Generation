def vector_angle_cos(u, v):
    '''
    vector_angle_cos(u, v) yields the cosine of the angle between the two vectors u and v. If u
    or v (or both) is a (d x n) matrix of n vectors, the result will be a length n vector of the
    cosines.
    '''
    u = np.asarray(u)
    v = np.asarray(v)
    return (u * v).sum(0) / np.sqrt((u ** 2).sum(0) * (v ** 2).sum(0))