def wp_status(self):
        '''show status of wp download'''
        try:
            print("Have %u of %u waypoints" % (self.wploader.count()+len(self.wp_received), self.wploader.expected_count))
        except Exception:
            print("Have %u waypoints" % (self.wploader.count()+len(self.wp_received)))