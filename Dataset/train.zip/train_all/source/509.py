def from_template_string(string, **kwargs):
    """
    Reads the given SMTP formatted template, and creates a new Mail object
    using the information.

    :type  string: str
    :param string: The SMTP formatted template.
    :type  kwargs: str
    :param kwargs: Variables to replace in the template.
    :rtype:  Mail
    :return: The resulting mail.
    """
    tmpl = _render_template(string, **kwargs)
    mail = Mail()
    mail.set_from_template_string(tmpl)
    return mail