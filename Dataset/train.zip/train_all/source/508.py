def find_min_signature(ufunc, dtypes_in):
    """Determine the minimum matching ufunc signature for given dtypes.

    Parameters
    ----------
    ufunc : str or numpy.ufunc
        Ufunc whose signatures are to be considered.
    dtypes_in :
        Sequence of objects specifying input dtypes. Its length must match
        the number of inputs of ``ufunc``, and its entries must be understood
        by `numpy.dtype`.

    Returns
    -------
    signature : str
        Minimum matching ufunc signature, see, e.g., ``np.add.types``
        for examples.

    Raises
    ------
    TypeError
        If no valid signature is found.
    """
    if not isinstance(ufunc, np.ufunc):
        ufunc = getattr(np, str(ufunc))

    dtypes_in = [np.dtype(dt_in) for dt_in in dtypes_in]
    tcs_in = [dt.base.char for dt in dtypes_in]

    if len(tcs_in) != ufunc.nin:
        raise ValueError('expected {} input dtype(s) for {}, got {}'
                         ''.format(ufunc.nin, ufunc, len(tcs_in)))

    valid_sigs = []
    for sig in ufunc.types:
        sig_tcs_in, sig_tcs_out = sig.split('->')
        if all(np.dtype(tc_in) <= np.dtype(sig_tc_in) and
               sig_tc_in in SUPP_TYPECODES
               for tc_in, sig_tc_in in zip(tcs_in, sig_tcs_in)):
            valid_sigs.append(sig)

    if not valid_sigs:
        raise TypeError('no valid signature found for {} and input dtypes {}'
                        ''.format(ufunc, tuple(dt.name for dt in dtypes_in)))

    def in_dtypes(sig):
        """Comparison key function for input dtypes of a signature."""
        sig_tcs_in = sig.split('->')[0]
        return tuple(np.dtype(tc) for tc in sig_tcs_in)

    return min(valid_sigs, key=in_dtypes)