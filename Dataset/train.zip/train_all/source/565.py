def log_url (self, url_data):
        """
        Log URL data in custom XML format.
        """
        self.xml_starttag(u'urldata')
        if self.has_part('url'):
            self.xml_tag(u"url", unicode(url_data.base_url))
        if url_data.name and self.has_part('name'):
            self.xml_tag(u"name", unicode(url_data.name))
        if url_data.parent_url and self.has_part('parenturl'):
            attrs = {
                u'line': u"%d" % url_data.line,
                u'column': u"%d" % url_data.column,
            }
            self.xml_tag(u"parent", unicode(url_data.parent_url),
                         attrs=attrs)
        if url_data.base_ref and self.has_part('base'):
            self.xml_tag(u"baseref", unicode(url_data.base_ref))
        if self.has_part("realurl"):
            self.xml_tag(u"realurl", unicode(url_data.url))
        if self.has_part("extern"):
            self.xml_tag(u"extern", u"%d" % (1 if url_data.extern else 0))
        if url_data.dltime >= 0 and self.has_part("dltime"):
            self.xml_tag(u"dltime", u"%f" % url_data.dltime)
        if url_data.size >= 0 and self.has_part("dlsize"):
            self.xml_tag(u"dlsize", u"%d" % url_data.size)
        if url_data.checktime and self.has_part("checktime"):
            self.xml_tag(u"checktime", u"%f" % url_data.checktime)
        if self.has_part("level"):
            self.xml_tag(u"level", u"%d" % url_data.level)
        if url_data.info and self.has_part('info'):
            self.xml_starttag(u"infos")
            for info in url_data.info:
                self.xml_tag(u"info", info)
            self.xml_endtag(u"infos")
        if url_data.modified and self.has_part('modified'):
            self.xml_tag(u"modified", self.format_modified(url_data.modified))
        if url_data.warnings and self.has_part('warning'):
            self.xml_starttag(u"warnings")
            for tag, data in url_data.warnings:
                attrs = {}
                if tag:
                    attrs["tag"] = tag
                self.xml_tag(u"warning", data, attrs)
            self.xml_endtag(u"warnings")
        if self.has_part("result"):
            attrs = {}
            if url_data.result:
                attrs["result"] = url_data.result
            self.xml_tag(u"valid", u"%d" % (1 if url_data.valid else 0), attrs)
        self.xml_endtag(u'urldata')
        self.flush()