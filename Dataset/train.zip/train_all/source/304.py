def get_by_symbol(self, symbol: str) -> Commodity:
        """
        Returns the commodity with the given symbol.
        If more are found, an exception will be thrown.
        """
        # handle namespace. Accept GnuCash and Yahoo-style symbols.
        full_symbol = self.__parse_gc_symbol(symbol)

        query = (
            self.query
            .filter(Commodity.mnemonic == full_symbol["mnemonic"])
        )
        if full_symbol["namespace"]:
            query = query.filter(Commodity.namespace == full_symbol["namespace"])

        return query.first()