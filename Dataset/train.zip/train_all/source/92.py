def _initial_individual(self):
        """Generates an individual with random parameters within bounds."""
        ind = creator.Individual(
            [random.uniform(-1, 1)
             for _ in range(len(self.value_means))])
        return ind