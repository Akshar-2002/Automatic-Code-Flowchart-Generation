def error(self, amplexception):
        """
        Receives notification of an error.
        """
        msg = '\t'+str(amplexception).replace('\n', '\n\t')
        print('Error:\n{:s}'.format(msg))
        raise amplexception