def list_submodules(module_name: str) -> List[str]:   # pylint: disable=invalid-sequence-index
    """
    List full names of all the submodules in the given module.

    :param module_name: name of the module of which the submodules will be listed
    """
    _module = importlib.import_module(module_name)
    return [module_name+'.'+submodule_name for _, submodule_name, _ in pkgutil.iter_modules(_module.__path__)]