def log(row=None, commit=True, *args, **kargs):
    """Log a dict to the global run's history.  If commit is false, enables multiple calls before commiting.

    Eg.

    wandb.log({'train-loss': 0.5, 'accuracy': 0.9})
    """
    if run is None:
        raise ValueError(
            "You must call `wandb.init` in the same process before calling log")

    if row is None:
        row = {}
    if commit:
        run.history.add(row, *args, **kargs)
    else:
        run.history.update(row, *args, **kargs)