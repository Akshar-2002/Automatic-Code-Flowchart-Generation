def nl_complete_msg(sk, msg):
    """Finalize Netlink message.

    https://github.com/thom311/libnl/blob/libnl3_2_25/lib/nl.c#L450

    This function finalizes a Netlink message by completing the message with desirable flags and values depending on the
    socket configuration.

    - If not yet filled out, the source address of the message (`nlmsg_pid`) will be set to the local port number of the
      socket.
    - If not yet specified, the next available sequence number is assigned to the message (`nlmsg_seq`).
    - If not yet specified, the protocol field of the message will be set to the protocol field of the socket.
    - The `NLM_F_REQUEST` Netlink message flag will be set.
    - The `NLM_F_ACK` flag will be set if Auto-ACK mode is enabled on the socket.

    Positional arguments:
    sk -- Netlink socket (nl_sock class instance).
    msg -- Netlink message (nl_msg class instance).
    """
    nlh = msg.nm_nlh
    if nlh.nlmsg_pid == NL_AUTO_PORT:
        nlh.nlmsg_pid = nl_socket_get_local_port(sk)
    if nlh.nlmsg_seq == NL_AUTO_SEQ:
        nlh.nlmsg_seq = sk.s_seq_next
        sk.s_seq_next += 1
    if msg.nm_protocol == -1:
        msg.nm_protocol = sk.s_proto
    nlh.nlmsg_flags |= NLM_F_REQUEST
    if not sk.s_flags & NL_NO_AUTO_ACK:
        nlh.nlmsg_flags |= NLM_F_ACK