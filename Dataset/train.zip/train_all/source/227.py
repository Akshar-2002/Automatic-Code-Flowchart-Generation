def vignetting(xy, f=100, alpha=0, rot=0, tilt=0, cx=50, cy=50):
    '''
    Vignetting equation using the KANG-WEISS-MODEL
    see http://research.microsoft.com/en-us/um/people/sbkang/publications/eccv00.pdf   

    f - focal length
    alpha - coefficient in the geometric vignetting factor
    tilt - tilt angle of a planar scene
    rot - rotation angle of a planar scene
    cx - image center, x
    cy - image center, y
    '''
    x, y = xy
    # distance to image center:
    dist = ((x - cx)**2 + (y - cy)**2)**0.5

    # OFF_AXIS ILLUMINATION FACTOR:
    A = 1.0 / (1 + (dist / f)**2)**2
    # GEOMETRIC FACTOR:
    if alpha != 0:
        G = (1 - alpha * dist)
    else:
        G = 1
    # TILT FACTOR:
    if tilt != 0:
        T = tiltFactor((x, y), f, tilt, rot, (cy, cx))
    else:
        T = 1
    return A * G * T