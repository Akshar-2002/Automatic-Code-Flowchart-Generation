def dnld_goa(self, species, ext='gaf', item=None, fileout=None):
        """Download GOA source file name on EMBL-EBI ftp server."""
        basename = self.get_basename(species, ext, item)
        src = os.path.join(self.ftp_src_goa, species.upper(), "{F}.gz".format(F=basename))
        dst = os.path.join(os.getcwd(), basename) if fileout is None else fileout
        dnld_file(src, dst, prt=sys.stdout, loading_bar=None)
        return dst