def insertTopLevelItem( self, index, item ):
        """
        Inserts the inputed item at the given index in the tree.
        
        :param      index   | <int>
                    item    | <XGanttWidgetItem>
        """
        self.treeWidget().insertTopLevelItem(index, item)
        
        if self.updatesEnabled():
            try:
                item.sync(recursive = True)
            except AttributeError:
                pass