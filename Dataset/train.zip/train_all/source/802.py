def idle_task(self):
        '''handle missing parameters'''
        self.check_new_target_system()
        sysid = self.get_sysid()
        self.pstate[sysid].vehicle_name = self.vehicle_name
        self.pstate[sysid].fetch_check(self.master)