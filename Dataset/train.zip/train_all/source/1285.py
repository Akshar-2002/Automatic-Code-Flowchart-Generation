def get_image(verbose=False):
  """Get the image as a TensorFlow variable.

  Returns:
    A `tf.Variable`, which must be initialized prior to use:
    invoke `sess.run(result.initializer)`."""
  base_data = tf.constant(image_data(verbose=verbose))
  base_image = tf.image.decode_image(base_data, channels=3)
  base_image.set_shape((IMAGE_HEIGHT, IMAGE_WIDTH, 3))
  parsed_image = tf.Variable(base_image, name='image', dtype=tf.uint8)
  return parsed_image