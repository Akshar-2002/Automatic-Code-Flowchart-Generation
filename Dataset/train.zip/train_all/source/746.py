def to_json(value, **kwargs):
        """Convert array to JSON list

        nan values are converted to string 'nan', inf values to 'inf'.
        """
        def _recurse_list(val):
            if val and isinstance(val[0], list):
                return [_recurse_list(v) for v in val]
            return [str(v) if np.isnan(v) or np.isinf(v) else v for v in val]
        return _recurse_list(value.tolist())