def tar_extract(cls, tar_comp_file_path):
        """Extract tar.gz or tar bz2 file.

        It behaves like
          - tar xzf tar_gz_file_path
          - tar xjf tar_bz2_file_path
        It raises tarfile.ReadError if the file is broken.
        """
        try:
            with contextlib.closing(tarfile.open(tar_comp_file_path)) as tar:
                tar.extractall()
        except tarfile.ReadError as e:
            message_format = (
                'Extract failed: '
                'tar_comp_file_path: {0}, reason: {1}'
            )
            raise InstallError(message_format.format(tar_comp_file_path, e))