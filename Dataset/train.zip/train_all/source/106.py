def mechanism(self, mechanism):
        """
        Sets the mechanism of this DeviceData.
        The ID of the channel used to communicate with the device.

        :param mechanism: The mechanism of this DeviceData.
        :type: str
        """
        allowed_values = ["connector", "direct"]
        if mechanism not in allowed_values:
            raise ValueError(
                "Invalid value for `mechanism` ({0}), must be one of {1}"
                .format(mechanism, allowed_values)
            )

        self._mechanism = mechanism