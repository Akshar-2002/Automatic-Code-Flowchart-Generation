def run(data):
    """HLA typing with OptiType, parsing output from called genotype files.
    """
    hlas = []
    for hla_fq in tz.get_in(["hla", "fastq"], data, []):
        hla_type = re.search("[.-](?P<hlatype>HLA-[\w-]+).fq", hla_fq).group("hlatype")
        if hla_type in SUPPORTED_HLAS:
            if utils.file_exists(hla_fq):
                hlas.append((hla_type, hla_fq))
    if len(hlas) > 0:
        out_dir = utils.safe_makedir(os.path.join(dd.get_work_dir(data), "align",
                                                  dd.get_sample_name(data), "hla",
                                                  "OptiType-HLA-A_B_C"))
        # When running UMIs and hla typing we want to pick the original fastqs
        if len(hlas) > len(SUPPORTED_HLAS):
            hlas = [x for x in hlas if os.path.basename(x[1]).find("-cumi") == -1]
        if len(hlas) == len(SUPPORTED_HLAS):
            hla_fq = combine_hla_fqs(hlas, out_dir + "-input.fq", data)
            if utils.file_exists(hla_fq):
                out_file = glob.glob(os.path.join(out_dir, "*", "*_result.tsv"))
                if len(out_file) > 0:
                    out_file = out_file[0]
                else:
                    out_file = _call_hla(hla_fq, out_dir, data)
                out_file = _prepare_calls(out_file, os.path.dirname(out_dir), data)
                data["hla"].update({"call_file": out_file,
                                    "hlacaller": "optitype"})
    return data