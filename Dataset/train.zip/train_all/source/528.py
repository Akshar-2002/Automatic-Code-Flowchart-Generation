def _process_file_continue_request(self, request: BaseRequest):
        '''Modify the request to resume downloading file.'''
        if os.path.exists(self._filename):
            size = os.path.getsize(self._filename)
            request.set_continue(size)
            self._file_continue_requested = True

            _logger.debug('Continue file from {0}.', size)
        else:
            _logger.debug('No file to continue.')