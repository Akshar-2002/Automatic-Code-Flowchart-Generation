def _get_si():
    '''
    Authenticate with vCenter server and return service instance object.
    '''

    url = config.get_cloud_config_value(
        'url', get_configured_provider(), __opts__, search_global=False
    )
    username = config.get_cloud_config_value(
        'user', get_configured_provider(), __opts__, search_global=False
    )
    password = config.get_cloud_config_value(
        'password', get_configured_provider(), __opts__, search_global=False
    )
    protocol = config.get_cloud_config_value(
        'protocol', get_configured_provider(), __opts__, search_global=False, default='https'
    )
    port = config.get_cloud_config_value(
        'port', get_configured_provider(), __opts__, search_global=False, default=443
    )

    return salt.utils.vmware.get_service_instance(url,
                                                  username,
                                                  password,
                                                  protocol=protocol,
                                                  port=port)