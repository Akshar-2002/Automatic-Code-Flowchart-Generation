def _timer_update(self):
        """Add some moving points to the dependency resolution text."""
        self._timer_counter += 1
        dot = self._timer_dots.pop(0)
        self._timer_dots = self._timer_dots + [dot]
        self._rows = [[_(u'Resolving dependencies') + dot, u'', u'', u'']]
        index = self.createIndex(0, 0)
        self.dataChanged.emit(index, index)

        if self._timer_counter > 150:
            self._timer.stop()
            self._timer_counter = 0