def render(self, context, instance, placeholder):
        """
        Update the context with plugin's data
        """
        context = super(CMSRandomEntriesPlugin, self).render(
            context, instance, placeholder)
        context['template_to_render'] = (str(instance.template_to_render) or
                                         'zinnia/tags/entries_random.html')
        return context