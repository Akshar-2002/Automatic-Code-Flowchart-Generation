def set_day_time(self, hour):
        """Queue up a change day time command. It will be applied when `tick` or `step` is called next.
        By the next tick, the lighting and the skysphere will be updated with the new hour. If there is no skysphere
        or directional light in the world, the command will not function properly but will not cause a crash.

        Args:
            hour (int): The hour in military time, between 0 and 23 inclusive.
        """
        self._should_write_to_command_buffer = True
        command_to_send = DayTimeCommand(hour % 24)
        self._commands.add_command(command_to_send)