def _at_dump_functions(self, calculator, rule, scope, block):
        """
        Implements @dump_functions
        """
        sys.stderr.write("%s\n" % repr(rule.namespace._functions))