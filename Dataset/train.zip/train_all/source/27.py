def _ProcessGrepSource(self, source):
    """Find files fulfilling regex conditions."""
    attributes = source.base_source.attributes
    paths = artifact_utils.InterpolateListKbAttributes(
        attributes["paths"], self.knowledge_base,
        self.ignore_interpolation_errors)
    regex = utils.RegexListDisjunction(attributes["content_regex_list"])
    condition = rdf_file_finder.FileFinderCondition.ContentsRegexMatch(
        regex=regex, mode="ALL_HITS")
    file_finder_action = rdf_file_finder.FileFinderAction.Stat()
    request = rdf_file_finder.FileFinderArgs(
        paths=paths,
        action=file_finder_action,
        conditions=[condition],
        follow_links=True)
    action = file_finder.FileFinderOSFromClient

    yield action, request