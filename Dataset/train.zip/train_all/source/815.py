def _md5_compute(self, f):
        '''
        Computes the checksum of the file
        '''
        md5 = hashlib.md5()
        block_size = 16384
        f.seek(0, 2)
        remaining = f.tell()
        f.seek(0)

        while (remaining > block_size):
            data = f.read(block_size)
            remaining = remaining - block_size
            md5.update(data)

        if remaining > 0:
            data = f.read(remaining)
            md5.update(data)

        return md5.digest()