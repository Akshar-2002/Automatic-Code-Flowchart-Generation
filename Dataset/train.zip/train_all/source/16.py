def _insert_stmt(self, name, value, timestamp, interval, config):
    '''Helper to generate the insert statement.'''
    # Calculate the TTL and abort if inserting into the past
    expire, ttl = config['expire'], config['ttl'](timestamp)
    if expire and not ttl:
      return None

    i_time = config['i_calc'].to_bucket(timestamp)
    if not config['coarse']:
      r_time = config['r_calc'].to_bucket(timestamp)
    else:
      r_time = -1

    # TODO: figure out escaping rules of CQL
    stmt = '''INSERT INTO %s (name, interval, i_time, r_time, value)
      VALUES ('%s', '%s', %s, %s, %s)'''%(self._table, name, interval, i_time, r_time, value)
    expire = config['expire']
    if ttl:
      stmt += " USING TTL %s"%(ttl)
    return stmt