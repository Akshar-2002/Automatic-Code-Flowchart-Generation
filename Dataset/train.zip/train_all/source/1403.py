def marshall(self):
        """Return the measurement in the line protocol format.

        :rtype: str

        """
        return '{},{} {} {}'.format(
            self._escape(self.name),
            ','.join(['{}={}'.format(self._escape(k), self._escape(v))
                      for k, v in self.tags.items()]),
            self._marshall_fields(),
            int(self.timestamp * 1000))