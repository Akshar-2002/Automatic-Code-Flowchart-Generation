def convert_noun_phrases(self, id_run, pos_run):
        """
        Converts any identified phrases in the run into phrase_ids.  The dictionary provides all acceptable phrases
        :param id_run: a run of token ids
        :param dictionary: a dictionary of acceptable phrases described as there component token ids
        :return: a run of token and phrase ids.
        """
        i = 0
        rv = []
        while i < len(id_run):
            phrase_id, offset = PhraseDictionary.return_max_phrase(id_run, i, self)
            if phrase_id:
                if pos_run[i] in ('JJ', 'JJR', 'JJS', 'NN', 'NNS', 'NNP', 'NNPS', 'SYM', 'CD', 'VBG', 'FW', 'NP'):
                    print "MERGED", pos_run[i], self.get_phrase(phrase_id)
                    rv.append((phrase_id,'NP'))
                    i = offset
                else:
                    print "SKIPPED", pos_run[i], self.get_phrase(phrase_id)
                    rv.append((id_run[i], pos_run[i]))
                    i += 1
            else:
                rv.append((id_run[i], pos_run[i]))
                i += 1
        return rv