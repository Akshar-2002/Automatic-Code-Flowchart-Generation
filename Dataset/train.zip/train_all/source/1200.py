def downloadTo(self, href, localpath):
        """
        Download file to localstorage
        :param href: remote path
        :param localpath: local path
        :return: response
        """
        for iTry in range(TRYINGS):
            logger.info(u("downloadTo(%s): %s %s") % (iTry, href, localpath))
            try:
                href = remote(href)
                localpath = _(localpath)

                conn = self.getConnection()
                conn.request("GET", _encode_utf8(href), "", self.getHeaders())
                response = conn.getresponse()
                checkResponse(response)
                f = None
                try:
                    while True:
                        data = _decode_utf8(response.read(1024))
                        if not data:
                            break
                        if data == u('resource not found'):
                            return False
                        if not f:
                            f = open(localpath, "w")
                        f.write(data)
                finally:
                    if f:
                        f.close()
                return True
            except ConnectionException:
                raise
            except Exception:
                e = sys.exc_info()[1]
                logger.exception(e)