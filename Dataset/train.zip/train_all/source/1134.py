def add_request_log_fields(
            self, log_fields: LogFields,
            call_details: Union[grpc.HandlerCallDetails,
                                grpc.ClientCallDetails]
    ):
        """Add log fields related to a request to the provided log fields

        :param log_fields: log fields instance to which to add the fields
        :param call_details: some information regarding the call

        """
        service, method = call_details.method[1:].split("/")
        log_fields.add_fields({
            "system":       "grpc",
            "span.kind":    self.KIND,
            "grpc.service": service,
            "grpc.method":  method,
        })