def is_available(self) -> bool:
        """Indicate if this Monitor is currently available."""
        status_response = self._client.get_state(
            'api/monitors/daemonStatus/id:{}/daemon:zmc.json'.format(
                self._monitor_id
            )
        )

        if not status_response:
            _LOGGER.warning('Could not get availability for monitor {}'.format(
                self._monitor_id
            ))
            return False

        # Monitor_Status was only added in ZM 1.32.3
        monitor_status = self._raw_result.get('Monitor_Status', None)
        capture_fps = monitor_status and monitor_status['CaptureFPS']

        return status_response.get('status', False) and capture_fps != "0.00"