def _http_request(url,
                  headers=None,
                  data=None):
    '''
    Make the HTTP request and return the body as python object.
    '''
    if not headers:
        headers = _get_headers()
    session = requests.session()
    log.debug('Querying %s', url)
    req = session.post(url,
                       headers=headers,
                       data=salt.utils.json.dumps(data))
    req_body = req.json()
    ret = _default_ret()
    log.debug('Status code: %d', req.status_code)
    log.debug('Response body:')
    log.debug(req_body)
    if req.status_code != 200:
        if req.status_code == 500:
            ret['comment'] = req_body.pop('message', '')
            ret['out'] = req_body
            return ret
        ret.update({
            'comment': req_body.get('error', '')
        })
        return ret
    ret.update({
        'result': True,
        'out': req.json()
    })
    return ret