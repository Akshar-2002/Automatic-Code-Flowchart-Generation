def _get_service_state(service_id: str):
        """Get the Service state object for the specified id."""
        LOG.debug('Getting state of service %s', service_id)
        services = get_service_id_list()
        service_ids = [s for s in services if service_id in s]
        if len(service_ids) != 1:
            return 'Service not found! services = {}'.format(str(services))
        subsystem, name, version = service_ids[0].split(':')
        return ServiceState(subsystem, name, version)