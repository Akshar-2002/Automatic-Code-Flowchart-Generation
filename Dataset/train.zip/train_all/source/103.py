def find_minimum_spanning_tree(graph):
    """Calculates a minimum spanning tree for a graph.
    Returns a list of edges that define the tree.
    Returns an empty list for an empty graph.
    """
    mst = []

    if graph.num_nodes() == 0:
        return mst
    if graph.num_edges() == 0:
        return mst

    connected_components = get_connected_components(graph)
    if len(connected_components) > 1:
        raise DisconnectedGraphError

    edge_list = kruskal_mst(graph)

    return edge_list