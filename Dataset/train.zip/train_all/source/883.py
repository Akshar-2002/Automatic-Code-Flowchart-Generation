def _create_scales(hist: HistogramBase, vega: dict, kwargs: dict):
    """Find proper scales for axes."""
    if hist.ndim == 1:
        bins0 = hist.bins.astype(float)
    else:
        bins0 = hist.bins[0].astype(float)

    xlim = kwargs.pop("xlim", "auto")
    ylim = kwargs.pop("ylim", "auto")

    if xlim is "auto":
        nice_x = True
    else:
        nice_x = False

    if ylim is "auto":
        nice_y = True
    else:
        nice_y = False

    # TODO: Unify xlim & ylim parameters with matplotlib
    # TODO: Apply xscale & yscale parameters

    vega["scales"] = [
        {
            "name": "xscale",
            "type": "linear",
            "range": "width",
            "nice": nice_x,
            "zero": None,
            "domain": [bins0[0, 0], bins0[-1, 1]] if xlim == "auto" else [float(xlim[0]), float(xlim[1])],
            # "domain": {"data": "table", "field": "x"}
        },
        {
            "name": "yscale",
            "type": "linear",
            "range": "height",
            "nice": nice_y,
            "zero": True if hist.ndim == 1 else None,
            "domain": {"data": "table", "field": "y"} if ylim == "auto" else [float(ylim[0]), float(ylim[1])]
        }
    ]

    if hist.ndim >= 2:
        bins1 = hist.bins[1].astype(float)
        vega["scales"][1]["domain"] = [bins1[0, 0], bins1[-1, 1]]