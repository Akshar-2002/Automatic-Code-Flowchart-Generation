def filter_by_label(self, pores=[], throats=[], labels=None, mode='or'):
        r"""
        Returns which of the supplied pores (or throats) has the specified
        label

        Parameters
        ----------
        pores, or throats : array_like
            List of pores or throats to be filtered

        labels : list of strings
            The labels to apply as a filter

        mode : string

            Controls how the filter is applied.  Options include:

            **'or', 'union', 'any'**: (default) Returns a list of the given
            locations where *any* of the given labels exist.

            **'and', 'intersection', 'all'**: Only locations where *all* the
            given labels are found.

            **'xor', 'exclusive_or'**: Only locations where exactly *one* of
            the given labels are found.

            **'nor', 'none', 'not'**: Only locations where *none* of the given
            labels are found.

            **'nand'** : Only locations with *some but not all* of the given
            labels are returned.

            **'xnor'** : Only locations with *more than one* of the given
            labels are returned.

        Returns
        -------
        A list of pores (or throats) that have been filtered according the
        given criteria.  The returned list is a subset of the received list of
        pores (or throats).

        See Also
        --------
        pores
        throats

        Examples
        --------
        >>> import openpnm as op
        >>> pn = op.network.Cubic(shape=[5, 5, 5])
        >>> pn.filter_by_label(pores=[0, 1, 5, 6], labels='left')
        array([0, 1])
        >>> Ps = pn.pores(['top', 'bottom', 'front'], mode='or')
        >>> pn.filter_by_label(pores=Ps, labels=['top', 'front'],
        ...                    mode='and')
        array([ 4,  9, 14, 19, 24])
        """
        # Convert inputs to locations and element
        if (sp.size(throats) > 0) and (sp.size(pores) > 0):
            raise Exception('Can only filter either pores OR labels')
        if sp.size(pores) > 0:
            element = 'pore'
            locations = self._parse_indices(pores)
        elif sp.size(throats) > 0:
            element = 'throat'
            locations = self._parse_indices(throats)
        else:
            return(sp.array([], dtype=int))
        labels = self._parse_labels(labels=labels, element=element)
        labels = [element+'.'+item.split('.')[-1] for item in labels]
        all_locs = self._get_indices(element=element, labels=labels, mode=mode)
        mask = self._tomask(indices=all_locs, element=element)
        ind = mask[locations]
        return locations[ind]