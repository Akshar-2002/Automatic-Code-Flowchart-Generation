def get_active_topics_count(last_seen_timestamp=None):
    """
    Returns count of new topics since last visit, or one day.
    {% get_active_topics_count as active_topic_count %}
    """
    if not last_seen_timestamp:
        last_seen_timestamp = yesterday_timestamp()
    return Topic.objects.filter(modified_int__gt=last_seen_timestamp).count()