def version():
    '''
    Return the system version for this minion

    .. versionchanged:: 2016.11.4
        Added support for AIX

    .. versionchanged:: 2018.3.0
        Added support for OpenBSD

    CLI Example:

    .. code-block:: bash

        salt '*' status.version
    '''
    def linux_version():
        '''
        linux specific implementation of version
        '''
        try:
            with salt.utils.files.fopen('/proc/version', 'r') as fp_:
                return salt.utils.stringutils.to_unicode(fp_.read()).strip()
        except IOError:
            return {}

    def bsd_version():
        '''
        bsd specific implementation of version
        '''
        return __salt__['cmd.run']('sysctl -n kern.version')

    # dict that returns a function that does the right thing per platform
    get_version = {
        'Linux': linux_version,
        'FreeBSD': bsd_version,
        'OpenBSD': bsd_version,
        'AIX': lambda: __salt__['cmd.run']('oslevel -s'),
    }

    errmsg = 'This method is unsupported on the current operating system!'
    return get_version.get(__grains__['kernel'], lambda: errmsg)()