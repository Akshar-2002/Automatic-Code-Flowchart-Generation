def classify_file(f):
    """Examine the column names to determine which type of file
    this is. Return a tuple:
    retvalue[0] = "file is non-parameterized"
    retvalue[1] = "file contains error column"
    """
    cols=f[1].columns
    if len(cols) == 2:
        #Then we must have a simple file
        return (True,False)
    elif len(cols) == 3 and ('ERROR' in cols.names):
        return (True,True)
    elif len(cols) > 2 and ('ERROR' not in cols.names):
        return (True,False)
    else:
        return (False,True)