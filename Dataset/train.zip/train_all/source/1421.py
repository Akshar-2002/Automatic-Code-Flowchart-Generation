def make_psf_kernel(psf, npix, cdelt, xpix, ypix, psf_scale_fn=None, normalize=False):
    """
    Generate a kernel for a point-source.

    Parameters
    ----------

    psf : `~fermipy.irfs.PSFModel`

    npix : int
        Number of pixels in X and Y dimensions.

    cdelt : float
        Pixel size in degrees.

    """

    egy = psf.energies
    x = make_pixel_distance(npix, xpix, ypix)
    x *= cdelt

    k = np.zeros((len(egy), npix, npix))
    for i in range(len(egy)):
        k[i] = psf.eval(i, x, scale_fn=psf_scale_fn)

    if normalize:
        k /= (np.sum(k, axis=0)[np.newaxis, ...] * np.radians(cdelt) ** 2)

    return k