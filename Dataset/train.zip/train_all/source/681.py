def terminate(self):
        """ Terminate Qutepart instance.
        This method MUST be called before application stop to avoid crashes and
        some other interesting effects
        Call it on close to free memory and stop background highlighting
        """
        self.text = ''
        self._completer.terminate()

        if self._highlighter is not None:
            self._highlighter.terminate()

        if self._vim is not None:
            self._vim.terminate()