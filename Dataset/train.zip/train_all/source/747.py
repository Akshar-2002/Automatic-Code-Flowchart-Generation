def add_place(self, **kwargs):
        """Adds a place to the Google Places database.

        On a successful request, this method will return a dict containing
        the the new Place's place_id and id in keys 'place_id' and 'id'
        respectively.

        keyword arguments:
        name        -- The full text name of the Place. Limited to 255
                       characters.
        lat_lng     -- A dict containing the following keys: lat, lng.
        accuracy    -- The accuracy of the location signal on which this request
                       is based, expressed in meters.
        types       -- The category in which this Place belongs. Only one type
                       can currently be specified for a Place. A string or
                       single element list may be passed in.
        language    -- The language in which the Place's name is being reported.
                       (defaults 'en').
        sensor      -- Boolean flag denoting if the location came from a device
                       using its location sensor (default False).
        """
        required_kwargs = {'name': [str], 'lat_lng': [dict],
                           'accuracy': [int], 'types': [str, list]}
        request_params = {}
        for key in required_kwargs:
            if key not in kwargs or kwargs[key] is None:
                raise ValueError('The %s argument is required.' % key)
            expected_types = required_kwargs[key]
            type_is_valid = False
            for expected_type in expected_types:
                if isinstance(kwargs[key], expected_type):
                    type_is_valid = True
                    break
            if not type_is_valid:
                raise ValueError('Invalid value for %s' % key)
            if key is not 'lat_lng':
                request_params[key] = kwargs[key]

        if len(kwargs['name']) > 255:
            raise ValueError('The place name must not exceed 255 characters ' +
                             'in length.')
        try:
            kwargs['lat_lng']['lat']
            kwargs['lat_lng']['lng']
            request_params['location'] = kwargs['lat_lng']
        except KeyError:
            raise ValueError('Invalid keys for lat_lng.')

        request_params['language'] = (kwargs.get('language')
                if kwargs.get('language') is not None else
                lang.ENGLISH)

        sensor = (kwargs.get('sensor')
                       if kwargs.get('sensor') is not None else
                       False)

        # At some point Google might support multiple types, so this supports
        # strings and lists.
        if isinstance(kwargs['types'], str):
            request_params['types'] = [kwargs['types']]
        else:
            request_params['types'] = kwargs['types']
        url, add_response = _fetch_remote_json(
                GooglePlaces.ADD_API_URL % (str(sensor).lower(),
                self.api_key), json.dumps(request_params), use_http_post=True)
        _validate_response(url, add_response)
        return {'place_id': add_response['place_id'],
                'id': add_response['id']}