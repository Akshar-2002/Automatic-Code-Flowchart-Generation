def _map_relations(relations, p, language='any'):
    '''
    :param: :class:`list` relations: Relations to be mapped. These are
        concept or collection id's.
    :param: :class:`skosprovider.providers.VocabularyProvider` p: Provider
        to look up id's.
    :param string language: Language to render the relations' labels in
    :rtype: :class:`list`
    '''
    ret = []
    for r in relations:
        c = p.get_by_id(r)
        if c:
            ret.append(_map_relation(c, language))
        else:
            log.warning(
                'A relation references a concept or collection %d in provider %s that can not be found. Please check the integrity of your data.' %
                (r, p.get_vocabulary_id())
            )
    return ret