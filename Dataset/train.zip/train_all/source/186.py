def _read_para_cert(self, code, cbit, clen, *, desc, length, version):
        """Read HIP CERT parameter.

        Structure of HIP CERT parameter [RFC 7401]:
             0                   1                   2                   3
             0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            |             Type              |             Length            |
            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            |  CERT group   |  CERT count   |    CERT ID    |   CERT type   |
            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            |                          Certificate                          /
            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            /                               |   Padding (variable length)   |
            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

            Octets      Bits        Name                Description
              0           0     cert.type           Parameter Type
              1          15     cert.critical       Critical Bit
              2          16     cert.length         Length of Contents
              4          32     cert.group          CERT Group
              5          40     cert.count          CERT Count
              6          48     cert.id             CERT ID
              7          56     cert.cert_type      CERT Type
              8          64     cert.certificate    Certificate
              ?           ?     -                   Padding

        """
        _ctgp = self._read_unpack(1)
        _ctct = self._read_unpack(1)
        _ctid = self._read_unpack(1)
        _cttp = self._read_unpack(1)
        _ctdt = self._read_fileng(clen-4)

        cert = dict(
            type=desc,
            critical=cbit,
            length=clen,
            group=_GROUP_ID.get(_ctgp, 'Unassigned'),
            count=_ctct,
            id=_ctid,
            cert_type=_CERT_TYPE.get(_cttp, 'Unassigned'),
            certificate=_ctdt,
        )

        _plen = length - clen
        if _plen:
            self._read_fileng(_plen)

        return cert