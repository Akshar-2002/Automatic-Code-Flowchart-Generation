def _to_mongo_query(query):
        """
        Convert the query received by the Sacred Web API to a MongoDB query.

        Takes a query in format
        {"type": "and", "filters": [
         {"field": "host.hostname", "operator": "==", "value": "ntbacer"},
         {"type": "or", "filters": [
            {"field": "result", "operator": "==", "value": 2403.52},
            {"field": "host.python_version", "operator": "==", "value":"3.5.2"}
            ]}]}
        and returns an appropriate MongoDB Query.
        :param query: A query in the Sacred Web API format.
        :return: Mongo Query.
        """
        mongo_query = []
        for clause in query["filters"]:
            if clause.get("type") is None:
                mongo_clause = MongoRunDAO. \
                    _simple_clause_to_query(clause)
            else:
                # It's a subclause
                mongo_clause = MongoRunDAO._to_mongo_query(clause)
            mongo_query.append(mongo_clause)

        if len(mongo_query) == 0:
            return {}
        if query["type"] == "and":
            return {"$and": mongo_query}
        elif query["type"] == "or":
            return {"$or": mongo_query}
        else:
            raise ValueError("Unexpected query type %s" % query.get("type"))