def abort(self):
        """Abort the SBI (and associated PBs)."""
        self.set_status('aborted')
        DB.remove_from_list('{}:active'.format(self._type), self._id)
        DB.append_to_list('{}:aborted'.format(self._type), self._id)
        sbi_pb_ids = ast.literal_eval(
            DB.get_hash_value(self._key, 'processing_block_ids'))

        for pb_id in sbi_pb_ids:
            pb = ProcessingBlock(pb_id)
            pb.abort()