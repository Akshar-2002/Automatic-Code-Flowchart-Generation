def log(self, format_, args, level=logging.INFO):
        """
        This function is called for anything that needs to get logged.
        It logs to the logger of this listener.

        It is not defined in the standard handler class; our version
        has an additional `level` argument that allows to control the
        logging level in the standard Python logging support.

        Another difference is that the variable arguments are passed
        in as a tuple.
        """
        self.server.listener.logger.log(level, format_, *args)