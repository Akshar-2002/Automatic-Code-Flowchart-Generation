def as_dictionary(self):
        """
        Return the parameter as a dictionary.

        :return: dict
        """
        return {
            "name": self.name,
            "type": self.type,
            "value": remove_0x_prefix(self.value) if self.type == 'bytes32' else self.value
        }