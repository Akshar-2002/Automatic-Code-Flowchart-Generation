def init_with_context(self, context):
        """
        Initializes the status list.
        """
        super(CacheStatusGroup, self).init_with_context(context)

        if 'dashboardmods' in settings.INSTALLED_APPS:
            import dashboardmods
            memcache_mods = dashboardmods.get_memcache_dash_modules()

            try:
                varnish_mods = dashboardmods.get_varnish_dash_modules()
            except (socket.error, KeyError) as e:
                # dashboardmods 2.2 throws KeyError for 'cache_misses' when the Varnish cache is empty.
                # Socket errors are also ignored, to work similar to the memcache stats.
                logger.exception("Unable to request Varnish stats: {0}".format(str(e)))
                varnish_mods = []
            except ImportError:
                varnish_mods = []

            self.children = memcache_mods + varnish_mods