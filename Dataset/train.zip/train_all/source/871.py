def sanitize_qualifiers(repos=None, followers=None, language=None):
    '''
    qualifiers = c repos:+42 followers:+1000 language:
    params = {'q': 'tom repos:>42 followers:>1000'}
    '''
    qualifiers = ''

    if repos:
        qualifiers += 'repos:{0} '.format(repos)
        qualifiers = re.sub(r"([+])([=a-zA-Z0-9]+)", r">\2", qualifiers)
        qualifiers = re.sub(r"([-])([=a-zA-Z0-9]+)", r"<\2", qualifiers)

    if followers:
        qualifiers += 'followers:{0} '.format(followers)
        qualifiers = re.sub(r"([+])([=a-zA-Z0-9]+)", r">\2", qualifiers)
        qualifiers = re.sub(r"([-])([=a-zA-Z0-9]+)", r"<\2", qualifiers)

    try:
        if language in ALLOWED_LANGUAGES and not language == '':
            qualifiers += 'language:{0} '.format(language)
        elif language == '':
            qualifiers += ''
        else:
            raise AllowedLanguagesException
    except AllowedLanguagesException as e:
        print(e)

    return qualifiers