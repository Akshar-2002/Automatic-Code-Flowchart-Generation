def stop_if(expr, msg='', no_output=False):
    '''Abort the execution of the current step or loop and yield
    an warning message `msg` if `expr` is False '''
    if expr:
        raise StopInputGroup(msg=msg, keep_output=not no_output)
    return 0