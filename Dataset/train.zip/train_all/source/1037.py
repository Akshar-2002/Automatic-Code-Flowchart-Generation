def toggle(self, key):
        """ Toggles a boolean key """
        val = self[key]
        assert isinstance(val, bool), 'key[%r] = %r is not a bool' % (key, val)
        self.pref_update(key, not val)