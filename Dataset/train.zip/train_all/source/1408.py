def validate_line_list(dist, attr, value):
    """
    Validate that the value is compatible
    """

    # does not work as reliably in Python 2.
    if isinstance(value, str):
        value = value.split()
    value = list(value)

    try:
        check = (' '.join(value)).split()
        if check == value:
            return True
    except Exception:
        pass
    raise DistutilsSetupError("%r must be a list of valid identifiers" % attr)