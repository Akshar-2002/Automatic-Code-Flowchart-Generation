def search(self, query: Optional[dict] = None, offset: Optional[int] = None,
               limit: Optional[int] = None,
               order_by: Union[None, list, tuple] = None) -> Sequence['IModel']:
        """return search result based on specified rulez query"""
        raise NotImplementedError