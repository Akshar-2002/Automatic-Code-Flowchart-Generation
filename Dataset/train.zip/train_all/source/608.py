def start(args):
    """
    %prog start

    Launch ec2 instance through command line.
    """
    p = OptionParser(start.__doc__)
    p.add_option("--ondemand", default=False, action="store_true",
                 help="Do we want a more expensive on-demand instance")
    p.add_option("--profile", default="mvrad-datasci-role", help="Profile name")
    p.add_option("--price", default=4.0, type=float, help="Spot price")
    opts, args = p.parse_args(args)

    if len(args) != 0:
        sys.exit(not p.print_help())

    role(["htang"])
    session = boto3.Session(profile_name=opts.profile)
    client = session.client('ec2')
    s = InstanceSkeleton()

    # Make sure the instance id is empty
    instance_id = s.instance_id
    if instance_id != "":
        logging.error("Instance exists {}".format(instance_id))
        sys.exit(1)

    launch_spec = s.launch_spec
    instance_id = ""

    if opts.ondemand:
        # Launch on-demand instance
        response = client.run_instances(
            BlockDeviceMappings=s.block_device_mappings,
            MaxCount=1, MinCount=1,
            ImageId=s.image_id,
            InstanceType=s.instance_type,
            KeyName=s.key_name,
            Placement={"AvailabilityZone": s.availability_zone},
            SecurityGroupIds=s.security_group_ids,
            SubnetId=s.subnet_id,
            EbsOptimized=s.ebs_optimized,
            IamInstanceProfile=s.iam_instance_profile,
        )
        instance_id = response["Instances"][0]["InstanceId"]

    else:
        # Launch spot instance
        response = client.request_spot_instances(
            SpotPrice=str(opts.price),
            InstanceCount=1,
            Type="one-time",
            AvailabilityZoneGroup=s.availability_zone,
            LaunchSpecification=launch_spec
        )

        request_id = response["SpotInstanceRequests"][0]["SpotInstanceRequestId"]
        print("Request id {}".format(request_id), file=sys.stderr)

        while not instance_id:
            response = client.describe_spot_instance_requests(
                SpotInstanceRequestIds=[request_id]
            )
            if "InstanceId" in response["SpotInstanceRequests"][0]:
                instance_id = response["SpotInstanceRequests"][0]["InstanceId"]
            else:
                logging.debug("Waiting to be fulfilled ...")
                time.sleep(10)

    # Check if the instance is running
    print("Instance id {}".format(instance_id), file=sys.stderr)
    status = ""
    while status != "running":
        logging.debug("Waiting instance to run ...")
        time.sleep(3)
        response = client.describe_instance_status(InstanceIds=[instance_id])
        if len(response["InstanceStatuses"]) > 0:
            status = response["InstanceStatuses"][0]["InstanceState"]["Name"]

    # Tagging
    name = "htang-lx-ondemand" if opts.ondemand else "htang-lx-spot"
    response = client.create_tags(
        Resources=[instance_id],
        Tags=[{"Key": k, "Value": v} for k, v in { \
                    "Name": name,
                    "owner": "htang",
                    "project": "mv-bioinformatics"
                }.items()]
    )

    # Attach working volumes
    volumes = s.volumes
    for volume in volumes:
        response = client.attach_volume(
            VolumeId=volume["VolumeId"],
            InstanceId=instance_id,
            Device=volume["Device"]
        )

    # Save instance id and ip
    response = client.describe_instances(InstanceIds=[instance_id])
    ip_address = response["Reservations"][0]["Instances"][0]["PrivateIpAddress"]
    print("IP address {}".format(ip_address), file=sys.stderr)

    s.save_instance_id(instance_id, ip_address)