def acquire(self, specification, arguments=None):
        """
        Returns an object for `specification` injecting its provider
        with a mix of its :term:`dependencies <dependency>` and given
        `arguments`. If there is a conflict between the injectable
        dependencies and `arguments`, the value from `arguments` is
        used.

        When one of `arguments` keys is neither an integer nor a string
        a `TypeError` is raised.

        :param specification:
            An object :term:`specification`.
        :param arguments:
            A dictionary of arguments given to the object :term:`provider`,
            overriding those that would be injected or filling in for those
            that wouldn't.  Positional arguments should be stored under 0-based
            integer keys.
        :raises:
            TypeError
        """
        if arguments is None:
            realized_dependencies = {}
        else:
            realized_dependencies = copy.copy(arguments)

        provider = self.providers[specification]

        scope = None
        if provider.scope is not None:
            try:
                scope = self.scopes[provider.scope]
            except KeyError:
                raise UnknownScopeError(provider.scope)

        if scope is not None and specification in scope:
            return scope[specification]

        dependencies = six.iteritems(provider.dependencies)
        for argument, dependency_specification in dependencies:
            if argument not in realized_dependencies:
                if isinstance(dependency_specification, Factory):
                    realized_dependencies[argument] = self.FactoryProxy(
                        self,
                        dependency_specification.specification
                    )
                else:
                    realized_dependencies[argument] = self.acquire(
                        dependency_specification
                    )

        args = []
        kwargs = {}
        for argument, value in six.iteritems(realized_dependencies):
            if isinstance(argument, six.integer_types):
                # Integer keys are for positional arguments.
                if len(args) <= argument:
                    args.extend([None] * (argument + 1 - len(args)))
                args[argument] = value
            elif isinstance(argument, six.string_types):
                # String keys are for keyword arguments.
                kwargs[argument] = value
            else:
                raise TypeError(
                    "{} is not a valid argument key".format(repr(argument))
                )

        instance = provider(*args, **kwargs)

        if scope is not None:
            scope[specification] = instance

        return instance