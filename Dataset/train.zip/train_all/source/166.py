def put_user(self, username, body, params=None):
        """
        `<https://www.elastic.co/guide/en/elasticsearch/reference/current/security-api-put-user.html>`_

        :arg username: The username of the User
        :arg body: The user to add
        :arg refresh: If `true` (the default) then refresh the affected shards
            to make this operation visible to search, if `wait_for` then wait
            for a refresh to make this operation visible to search, if `false`
            then do nothing with refreshes., valid choices are: 'true', 'false',
            'wait_for'
        """
        for param in (username, body):
            if param in SKIP_IN_PATH:
                raise ValueError("Empty value passed for a required argument.")
        return self.transport.perform_request(
            "PUT", _make_path("_security", "user", username), params=params, body=body
        )