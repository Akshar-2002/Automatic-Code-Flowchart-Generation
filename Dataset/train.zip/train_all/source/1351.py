def make_basic_ngpu(nb_classes=10, input_shape=(None, 28, 28, 1), **kwargs):
  """
  Create a multi-GPU model similar to the basic cnn in the tutorials.
  """
  model = make_basic_cnn()
  layers = model.layers

  model = MLPnGPU(nb_classes, layers, input_shape)
  return model