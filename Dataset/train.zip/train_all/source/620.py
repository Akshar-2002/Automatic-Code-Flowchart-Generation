def _get_event_id(object_type: str) -> str:
    """Return an event key for the event on the object type.

    This must be a unique event id for the object.

    Args:
        object_type (str): Type of object

    Returns:
        str, event id

    """
    key = _keys.event_counter(object_type)
    DB.watch(key, pipeline=True)
    count = DB.get_value(key)
    DB.increment(key)
    DB.execute()
    if count is None:
        count = 0
    return '{}_event_{:08d}'.format(object_type, int(count))