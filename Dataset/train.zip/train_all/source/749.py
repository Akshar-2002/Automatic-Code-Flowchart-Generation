def get_daemon_stats(self, details=False):
        """Increase the stats provided by the Daemon base class

        :return: stats dictionary
        :rtype: dict
        """
        # Call the base Daemon one
        res = super(Receiver, self).get_daemon_stats(details=details)

        res.update({'name': self.name, 'type': self.type})

        counters = res['counters']
        counters['external-commands'] = len(self.external_commands)
        counters['external-commands-unprocessed'] = len(self.unprocessed_external_commands)

        return res