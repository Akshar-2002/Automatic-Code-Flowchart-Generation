def upload_rpm(rpm_path, repoid, connector, callback=None):
    """upload an rpm into pulp

    rpm_path: path to an rpm
    connector: the connector to use for interacting with pulp

    callback: Optional callback to call after an RPM is
    uploaded. Callback should accept one argument, the name of the RPM
    which was uploaded
    """
    ts = rpm.TransactionSet()
    ts.setVSFlags(rpm._RPMVSF_NOSIGNATURES)

    info = rpm_info(rpm_path)
    pkg_name = info['name']
    nvrea = info['nvrea']
    cksum = info['cksum']
    size = info['size']
    package_basename = info['package_basename']

    juicer.utils.Log.log_notice("Expected amount to seek: %s (package size by os.path.getsize)" % size)

    # initiate upload
    upload = juicer.utils.Upload.Upload(package_basename, cksum, size, repoid, connector)

    #create a statusbar
    pbar = ProgressBar(size)

    # read in rpm
    total_seeked = 0
    rpm_fd = open(rpm_path, 'rb')
    rpm_fd.seek(0)
    while total_seeked < size:
        rpm_data = rpm_fd.read(Constants.UPLOAD_AT_ONCE)
        last_offset = total_seeked
        total_seeked += len(rpm_data)
        juicer.utils.Log.log_notice("Seeked %s data... (total seeked: %s)" % (len(rpm_data), total_seeked))
        upload_code = upload.append(fdata=rpm_data, offset=last_offset)
        if upload_code != Constants.PULP_PUT_OK:
            juicer.utils.Log.log_error("Upload failed.")
        pbar.update(len(rpm_data))
    pbar.finish()
    rpm_fd.close()

    juicer.utils.Log.log_notice("Seeked total data: %s" % total_seeked)

    # finalize upload
    rpm_id = upload.import_upload(nvrea=nvrea, rpm_name=pkg_name)

    juicer.utils.Log.log_debug("RPM upload complete. New 'packageid': %s" % rpm_id)

    # clean up working dir
    upload.clean_upload()

    # Run callbacks?
    if callback:
        try:
            juicer.utils.Log.log_debug("Calling upload callack: %s" % str(callback))
            callback(pkg_name)
        except Exception:
            juicer.utils.Log.log_error("Exception raised in callback: %s", str(callback))
            pass

    return rpm_id