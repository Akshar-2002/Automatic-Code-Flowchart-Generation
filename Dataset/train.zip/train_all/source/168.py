def modprobe(module, persist=True):
    """Load a kernel module and configure for auto-load on reboot."""
    cmd = ['modprobe', module]

    log('Loading kernel module %s' % module, level=INFO)

    subprocess.check_call(cmd)
    if persist:
        persistent_modprobe(module)