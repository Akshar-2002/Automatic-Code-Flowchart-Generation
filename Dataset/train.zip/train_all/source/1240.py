def add_gemini_query(self, name, query):
        """Add a user defined gemini query

        Args:
            name (str)
            query (str)
        """
        logger.info("Adding query {0} with text {1}".format(name, query))
        new_query = GeminiQuery(name=name, query=query)
        self.session.add(new_query)
        self.save()
        return new_query