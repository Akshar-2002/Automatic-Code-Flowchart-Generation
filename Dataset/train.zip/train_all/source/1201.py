def _p_iteration(self, P, Bp_solver, Vm, Va, pvpq):
        """ Performs a P iteration, updates Va.
        """
        dVa = -Bp_solver.solve(P)

        # Update voltage.
        Va[pvpq] = Va[pvpq] + dVa
        V = Vm * exp(1j * Va)

        return V, Vm, Va