def get_password_from_keyring(entry=None, username=None):
    """
      :param entry: The entry in the keychain. This is a caller specific key.
      :param username: The username to get the password for. Default is the current user.
    """

    if username is None:
        username = get_username()

    has_keychain = initialize_keychain()

    # Unlock the user's keychain otherwise, if running under SSH, 'security(1)' will thrown an error.
    unlock_keychain(username)

    if has_keychain and entry is not None:
        try:
            return keyring.get_password(entry, username)
        except Exception as e:
            log.warn("Unable to get password from keyring. Continuing..")
            log.debug(e)

    return None