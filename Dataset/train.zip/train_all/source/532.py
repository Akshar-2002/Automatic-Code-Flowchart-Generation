def _RetryLoop(self, func, timeout=None):
    """Retries an operation until success or deadline.

    Args:

      func: The function to run. Must take a timeout, in seconds, as a single
        parameter. If it raises grpc.RpcError and deadline has not be reached,
        it will be run again.

      timeout: Retries will continue until timeout seconds have passed.
    """
    timeout = timeout or self.DEFAULT_TIMEOUT
    deadline = time.time() + timeout
    sleep = 1
    while True:
      try:
        return func(timeout)
      except grpc.RpcError:
        if time.time() + sleep > deadline:
          raise
        time.sleep(sleep)
        sleep *= 2
        timeout = deadline - time.time()