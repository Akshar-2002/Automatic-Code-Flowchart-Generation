def read (self, files):
        """Read settings from given config files.

        @raises: LinkCheckerError on syntax errors in the config file(s)
        """
        assert isinstance(files, list), "Invalid file list %r" % files
        try:
            self.read_ok = super(LCConfigParser, self).read(files)
            if len(self.read_ok) < len(files):
                failed_files = set(files) - set(self.read_ok)
                log.warn(LOG_CHECK, "Could not read configuration files %s.", failed_files)
            # Read all the configuration parameters from the given files.
            self.read_checking_config()
            self.read_authentication_config()
            self.read_filtering_config()
            self.read_output_config()
            self.read_plugin_config()
        except Exception as msg:
            raise LinkCheckerError(
              _("Error parsing configuration: %s") % unicode(msg))