def iteritems(self):
        """
        Wow this class is messed up. I had to overwrite items when
        moving to python3, just because I haden't called it yet
        """
        for (key, val) in six.iteritems(self.__dict__):
            if key in self._printable_exclude:
                continue
            yield (key, val)