def usages_list(location, **kwargs):
    '''
    .. versionadded:: 2019.2.0

    List subscription network usage for a location.

    :param location: The Azure location to query for network usage.

    CLI Example:

    .. code-block:: bash

        salt-call azurearm_network.usages_list westus

    '''
    netconn = __utils__['azurearm.get_client']('network', **kwargs)
    try:
        result = __utils__['azurearm.paged_object_to_list'](netconn.usages.list(location))
    except CloudError as exc:
        __utils__['azurearm.log_cloud_error']('network', str(exc), **kwargs)
        result = {'error': str(exc)}

    return result