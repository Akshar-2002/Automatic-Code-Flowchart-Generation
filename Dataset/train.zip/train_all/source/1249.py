def counts_map(self):
        """Return 3-D counts map for this component as a Map object.

        Returns
        -------
        map : `~fermipy.skymap.MapBase`

        """
        try:
            if isinstance(self.like, gtutils.SummedLikelihood):
                cmap = self.like.components[0].logLike.countsMap()
                p_method = cmap.projection().method()
            else:
                cmap = self.like.logLike.countsMap()
                p_method = cmap.projection().method()
        except Exception:
            p_method = 0

        if p_method == 0:  # WCS
            z = cmap.data()
            z = np.array(z).reshape(self.enumbins, self.npix, self.npix)
            return WcsNDMap(copy.deepcopy(self.geom), z)
        elif p_method == 1:  # HPX
            z = cmap.data()
            z = np.array(z).reshape(self.enumbins, np.max(self.geom.npix))
            return HpxNDMap(copy.deepcopy(self.geom), z)
        else:
            self.logger.error('Did not recognize CountsMap type %i' % p_method,
                              exc_info=True)
        return None