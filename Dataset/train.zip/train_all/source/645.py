def minutes_back(self, date):
        ''' Gives a number (integer) of days
        since a given date
        '''
        elapsed = (datetime.utcnow() - datetime.strptime(date,'%Y-%m-%dT%H:%M:%S'))
        if elapsed.days > 0:
            secondsback = (elapsed.days * 24 * 60 * 60) + elapsed.seconds
        else:
            secondsback = elapsed.seconds
        minutesback = secondsback / 60
        return int(minutesback)