def post_copy_notes(self, post_id, other_post_id):
        """Function to copy notes (requires login).

        Parameters:
            post_id (int):
            other_post_id (int): The id of the post to copy notes to.
        """
        return self._get('posts/{0}/copy_notes.json'.format(post_id),
                         {'other_post_id': other_post_id}, 'PUT', auth=True)