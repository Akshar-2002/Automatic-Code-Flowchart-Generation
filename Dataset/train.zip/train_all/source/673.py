def do_add_device_override(self, args):
        """Add a device override to the IM.

        Usage:
            add_device_override address cat subcat [firmware]

        Arguments:
            address: Insteon address of the device to override
            cat: Device category
            subcat: Device subcategory
            firmware: Optional - Device firmware

        The device address can be written with our without the dots and in
        upper or lower case, for example: 1a2b3c or 1A.2B.3C.

        The category, subcategory and firmware numbers are written in hex
        format, for example: 0x01 0x1b

        Example:
            add_device_override 1a2b3c 0x02 0x1a
        """
        params = args.split()
        addr = None
        cat = None
        subcat = None
        firmware = None
        error = None

        try:
            addr = Address(params[0])
            cat = binascii.unhexlify(params[1][2:])
            subcat = binascii.unhexlify(params[2][2:])
            firmware = binascii.unhexlify(params[3][2:])
        except IndexError:
            error = 'missing'
        except ValueError:
            error = 'value'

        if addr and cat and subcat:
            self.tools.add_device_override(addr, cat, subcat, firmware)
        else:
            if error == 'missing':
                _LOGGING.error('Device address, category and subcategory are '
                               'required.')
            else:
                _LOGGING.error('Check the vales for address, category and '
                               'subcategory.')
            self.do_help('add_device_override')