def undo(self, hard=False):
        """Makes last commit not exist"""

        if not self.fake:
            return self.repo.git.reset('HEAD^', working_tree=hard)
        else:
            click.echo(crayons.red('Faked! >>> git reset {}{}'
                                   .format('--hard ' if hard else '', 'HEAD^')))
            return 0