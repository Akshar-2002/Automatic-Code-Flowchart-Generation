def replace(self, re_text, replace_str, text):
        """
        正则表达式替换
        :param re_text: 正则表达式
        :param replace_str: 替换字符串
        :param text: 搜索文档
        :return: 替换后的字符串
        """
        return re.sub(re_text, replace_str, text)