def make_vbox_dirs(max_vbox_id, output_dir, topology_name):
    """
    Create VirtualBox working directories if required

    :param int max_vbox_id: Number of directories to create
    :param str output_dir: Output directory
    :param str topology_name: Topology name
    """
    if max_vbox_id is not None:
        for i in range(1, max_vbox_id + 1):
            vbox_dir = os.path.join(output_dir, topology_name + '-files',
                                    'vbox', 'vm-%s' % i)
            os.makedirs(vbox_dir)