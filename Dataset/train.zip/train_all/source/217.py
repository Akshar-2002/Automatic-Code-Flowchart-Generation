def _to_dict(self):
        """Return a json dictionary representing this model."""
        _dict = {}
        if hasattr(self, 'grammars') and self.grammars is not None:
            _dict['grammars'] = [x._to_dict() for x in self.grammars]
        return _dict