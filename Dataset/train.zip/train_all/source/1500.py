def get_all_items_of_reminder(self, reminder_id):
        """
        Get all items of reminder
        This will iterate over all pages until it gets all elements.
        So if the rate limit exceeded it will throw an Exception and you will get nothing

        :param reminder_id: the reminder id
        :return: list
        """
        return self._iterate_through_pages(
            get_function=self.get_items_of_reminder_per_page,
            resource=REMINDER_ITEMS,
            **{'reminder_id': reminder_id}
        )