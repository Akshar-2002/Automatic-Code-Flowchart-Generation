def summarize_url(url, num_sentences=4, fmt='default'):
    '''returns: tuple containing
       * single-line summary candidate 
       * key points
       in the format specified.
    '''

    title, meta, full_text = goose_extractor(url)

    if not full_text:
        raise ArticleExtractionFail("Couldn't extract: {}".format(url))

    its = _intertext_score(full_text)
    tss = _title_similarity_score(full_text,title)

    if _eval_meta_as_summary(meta):
        summ = meta
        if tss[0][2].lower() in summ.lower():
            its, tss = _remove_title_from_tuples(its, tss)
        elif summ.lower() in tss[0][2].lower():
            summ = tss[0][2]
            its, tss = _remove_title_from_tuples(its, tss)
    else:
        summ = tss[0][2]
        its, tss = _remove_title_from_tuples(its, tss)

    scores = [score[2] for score in _aggregrate_scores(its, tss, num_sentences)]
    formatted = Formatter(scores, fmt).frmt()
    return summ, formatted