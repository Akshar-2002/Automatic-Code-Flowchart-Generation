def _parse_reports_by_type(self):
    """ Returns a data dictionary

        Goes through logs and parses them based on 'No errors found', VERBOSE or SUMMARY type.
    """

    data = dict()

    for file_meta in self.find_log_files('picard/sam_file_validation', filehandles=True):
        sample = file_meta['s_name']

        if sample in data:
            log.debug("Duplicate sample name found! Overwriting: {}".format(sample))

        filehandle = file_meta['f']
        first_line = filehandle.readline().rstrip()
        filehandle.seek(0)  # Rewind reading of the file

        if 'No errors found' in first_line:
            sample_data = _parse_no_error_report()
        elif first_line.startswith('ERROR') or first_line.startswith('WARNING'):
            sample_data = _parse_verbose_report(filehandle)
        else:
            sample_data = _parse_summary_report(filehandle)

        data[sample] = sample_data

    return data