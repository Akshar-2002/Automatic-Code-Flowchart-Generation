def fetcher_factory(conf):
    """Return initialized fetcher capable of processing given conf."""
    global PROMOTERS
    applicable = []
    if not PROMOTERS:
        PROMOTERS = load_promoters()
    for promoter in PROMOTERS:
        if promoter.is_applicable(conf):
            applicable.append((promoter.PRIORITY, promoter))
    if applicable:
        best_match = sorted(applicable, reverse=True)[0][1]
        return best_match(conf)
    else:
        raise ConfigurationError(
            'No fetcher is applicable for "{0}"'.format(conf['name'])
        )