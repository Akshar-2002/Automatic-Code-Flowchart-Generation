def partial_trace(self, qubits: Qubits) -> 'Channel':
        """Return the partial trace over the specified qubits"""
        vec = self.vec.partial_trace(qubits)
        return Channel(vec.tensor, vec.qubits)