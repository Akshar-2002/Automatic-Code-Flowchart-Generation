def query_most_pic(num, kind='1'):
        '''
        Query most pics.
        '''
        return TabPost.select().where(
            (TabPost.kind == kind) & (TabPost.logo != "")
        ).order_by(TabPost.view_count.desc()).limit(num)