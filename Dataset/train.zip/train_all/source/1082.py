def do_response(self, response_args=None, request=None, **kwargs):
        """
        **Placeholder for the time being**

        :param response_args:
        :param request:
        :param kwargs: request arguments
        :return: Response information
        """

        links = [Link(href=h, rel=OIC_ISSUER) for h in kwargs['hrefs']]

        _response = JRD(subject=kwargs['subject'], links=links)

        info = {
            'response': _response.to_json(),
            'http_headers': [('Content-type', 'application/json')]
        }

        return info