def delete_driver_script(driver, script_delete=None):  # noqa: E501
    """Delete a script

    Delete a script # noqa: E501

    :param driver: The driver to use for the request. ie. github
    :type driver: str
    :param script_delete: The data needed to delete this script
    :type script_delete: dict | bytes

    :rtype: Response
    """
    if connexion.request.is_json:
        script_delete = ScriptDelete.from_dict(connexion.request.get_json())  # noqa: E501

    response = errorIfUnauthorized(role='developer')
    if response:
        return response
    else:
        response = ApitaxResponse()

    driver: Driver = LoadedDrivers.getDriver(driver)
    driver.deleteDriverScript(script_delete.script.name)

    return Response(status=200, body=response.getResponseBody())