def setValidityErrorHandler(self, err_func, warn_func, arg=None):
        """
        Register error and warning handlers for RelaxNG validation.
        These will be called back as f(msg,arg)
        """
        libxml2mod.xmlRelaxNGSetValidErrors(self._o, err_func, warn_func, arg)