def groups(self):
        """Method returns a list of all goup paths
        
        Examples
        --------        
        >>> for group in h5f.groups():
                print(group)        
        '/'
        '/dataset1'
        '/dataset1/data1'
        '/dataset1/data2'
        """
        HiisiHDF._clear_cache()
        self.CACHE['group_paths'].append('/')
        self.visititems(HiisiHDF._is_group)
        return HiisiHDF.CACHE['group_paths']