def read(self, filename):
        """Reads the file specified by filename

        This method will load the eapi.conf file specified by filename into
        the instance object.  It will also add the default connection localhost
        if it was not defined in the eapi.conf file

        Args:
            filename (str): The full path to the file to load
        """

        try:
            SafeConfigParser.read(self, filename)
        except SafeConfigParserError as exc:
            # Ignore file and syslog a message on SafeConfigParser errors
            msg = ("%s: parsing error in eapi conf file: %s" %
                   (type(exc).__name__, filename))
            debug(msg)

        self._add_default_connection()

        for name in self.sections():
            if name.startswith('connection:') and \
               'host' not in dict(self.items(name)):

                self.set(name, 'host', name.split(':')[1])
        self.generate_tags()