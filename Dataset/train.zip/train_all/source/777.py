def _build_session(self, name, start_info, end_info):
    """Builds a session object."""

    assert start_info is not None
    result = api_pb2.Session(
        name=name,
        start_time_secs=start_info.start_time_secs,
        model_uri=start_info.model_uri,
        metric_values=self._build_session_metric_values(name),
        monitor_url=start_info.monitor_url)
    if end_info is not None:
      result.status = end_info.status
      result.end_time_secs = end_info.end_time_secs
    return result