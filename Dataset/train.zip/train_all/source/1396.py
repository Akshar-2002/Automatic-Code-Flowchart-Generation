def get_transformed_feature_indices(features, stats):
  """Returns information about the transformed features.

  Returns:
    List in the from
    [(transformed_feature_name, {size: int, index_start: int})]
  """

  feature_indices = []
  index_start = 1
  for name, transform in sorted(six.iteritems(features)):
    transform_name = transform['transform']
    source_column = transform['source_column']
    info = {}
    if transform_name in [IDENTITY_TRANSFORM, SCALE_TRANSFORM]:
      info['size'] = 1
    elif transform_name in [ONE_HOT_TRANSFORM, MULTI_HOT_TRANSFORM]:
      info['size'] = stats['column_stats'][source_column]['vocab_size']
    elif transform_name == IMAGE_TRANSFORM:
      info['size'] = IMAGE_BOTTLENECK_TENSOR_SIZE
    elif transform_name == TARGET_TRANSFORM:
      info['size'] = 0
    else:
      raise ValueError('xgboost does not support transform "%s"' % transform)

    info['index_start'] = index_start
    index_start += info['size']
    feature_indices.append((name, info))

  return feature_indices