def _set_people(self, people):
        """ Sets who the object is sent to """
        if hasattr(people, "object_type"):
            people = [people]
        elif hasattr(people, "__iter__"):
            people = list(people)

        return people