async def activate_scene(self, scene_id: int):
        """Activate a scene

        :param scene_id: Scene id.
        :return:
        """

        _scene = await self.get_scene(scene_id)
        await _scene.activate()