def routerify(obj):
    """
    Scan through attributes of object parameter looking for any which
    match a route signature.
    A router will be created and added to the object with parameter.

    Args:
        obj (object): The object (with attributes) from which to
            setup a router

    Returns:
        Router: The router created from attributes in the object.
    """
    router = Router()
    for info in get_routing_attributes(obj):
        router.add_route(*info)
    obj.__growler_router = router
    return router