def sources(
            self):
        """*The results of the search returned as a python list of dictionaries*

        **Usage:**

            .. code-block:: python

                sources = tns.sources
        """
        sourceResultsList = []
        sourceResultsList[:] = [dict(l) for l in self.sourceResultsList]
        return sourceResultsList