def dump(self, ret):
        """
        Dumps the return value
        :param ret:
        :return:
        """
        if self.args.flatten:
            ret = drop_none(flatten(ret))

        logger.info('Dump: \n' + json.dumps(ret, cls=AutoJSONEncoder, indent=2 if self.args.indent else None))