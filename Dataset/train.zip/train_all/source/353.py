def update_fallbackserver(self, serverid, data):
        """Update Fallback server"""
        return self.api_call(
            ENDPOINTS['fallbackservers']['update'],
            dict(serverid=serverid),
            body=data)