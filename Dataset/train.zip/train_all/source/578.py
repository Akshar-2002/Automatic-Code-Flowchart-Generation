def download(self, id, directory_path='.', checksum=True):
        """Download a product.

        Uses the filename on the server for the downloaded file, e.g.
        "S1A_EW_GRDH_1SDH_20141003T003840_20141003T003920_002658_002F54_4DD1.zip".

        Incomplete downloads are continued and complete files are skipped.

        Parameters
        ----------
        id : string
            UUID of the product, e.g. 'a8dd0cfd-613e-45ce-868c-d79177b916ed'
        directory_path : string, optional
            Where the file will be downloaded
        checksum : bool, optional
            If True, verify the downloaded file's integrity by checking its MD5 checksum.
            Throws InvalidChecksumError if the checksum does not match.
            Defaults to True.

        Returns
        -------
        product_info : dict
            Dictionary containing the product's info from get_product_info() as well as
            the path on disk.

        Raises
        ------
        InvalidChecksumError
            If the MD5 checksum does not match the checksum on the server.
        """
        product_info = self.get_product_odata(id)
        path = join(directory_path, product_info['title'] + '.zip')
        product_info['path'] = path
        product_info['downloaded_bytes'] = 0

        self.logger.info('Downloading %s to %s', id, path)

        if exists(path):
            # We assume that the product has been downloaded and is complete
            return product_info

        # An incomplete download triggers the retrieval from the LTA if the product is not online
        if not product_info['Online']:
            self.logger.warning(
                'Product %s is not online. Triggering retrieval from long term archive.',
                product_info['id'])
            self._trigger_offline_retrieval(product_info['url'])
            return product_info

        # Use a temporary file for downloading
        temp_path = path + '.incomplete'

        skip_download = False
        if exists(temp_path):
            if getsize(temp_path) > product_info['size']:
                self.logger.warning(
                    "Existing incomplete file %s is larger than the expected final size"
                    " (%s vs %s bytes). Deleting it.",
                    str(temp_path), getsize(temp_path), product_info['size'])
                remove(temp_path)
            elif getsize(temp_path) == product_info['size']:
                if self._md5_compare(temp_path, product_info['md5']):
                    skip_download = True
                else:
                    # Log a warning since this should never happen
                    self.logger.warning(
                        "Existing incomplete file %s appears to be fully downloaded but "
                        "its checksum is incorrect. Deleting it.",
                        str(temp_path))
                    remove(temp_path)
            else:
                # continue downloading
                self.logger.info(
                    "Download will resume from existing incomplete file %s.", temp_path)
                pass

        if not skip_download:
            # Store the number of downloaded bytes for unit tests
            product_info['downloaded_bytes'] = self._download(
                product_info['url'], temp_path, self.session, product_info['size'])

        # Check integrity with MD5 checksum
        if checksum is True:
            if not self._md5_compare(temp_path, product_info['md5']):
                remove(temp_path)
                raise InvalidChecksumError('File corrupt: checksums do not match')

        # Download successful, rename the temporary file to its proper name
        shutil.move(temp_path, path)
        return product_info