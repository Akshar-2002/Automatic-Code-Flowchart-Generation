def root_task_parser():
    """
    Returns a new *ArgumentParser* instance that only contains paremeter actions of the root task.
    The returned instance is cached.
    """
    global _root_task_parser

    if _root_task_parser:
        return _root_task_parser

    luigi_parser = luigi.cmdline_parser.CmdlineParser.get_instance()
    if not luigi_parser:
        return None

    root_task = luigi_parser.known_args.root_task

    # get all root task parameter destinations
    root_dests = []
    for task_name, _, param_name, _ in luigi.task_register.Register.get_all_params():
        if task_name == root_task:
            root_dests.append(param_name)

    # create a new parser and add all root actions
    _root_task_parser = ArgumentParser(add_help=False)
    for action in list(full_parser()._actions):
        if not action.option_strings or action.dest in root_dests:
            _root_task_parser._add_action(action)

    logger.debug("build luigi argument parser for root task {}".format(root_task))

    return _root_task_parser