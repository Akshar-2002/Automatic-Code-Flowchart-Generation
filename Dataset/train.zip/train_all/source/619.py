def separator_width(self, value):
        """
        Setter for **self.__separator_width** attribute.

        :param value: Attribute value.
        :type value: int
        """

        if value is not None:
            assert type(value) is int, "'{0}' attribute: '{1}' type is not 'int'!".format("separator_width", value)
            assert value > 0, "'{0}' attribute: '{1}' need to be exactly positive!".format("separator_width", value)
        self.__separator_width = value