def dict_subset(dict_, keys, default=util_const.NoParam):
    r"""
    Args:
        dict_ (dict):
        keys (list):

    Returns:
        dict: subset dictionary

    Example:
        >>> # ENABLE_DOCTEST
        >>> from utool.util_dict import *  # NOQA
        >>> import utool as ut
        >>> dict_ = {'K': 3, 'dcvs_clip_max': 0.2, 'p': 0.1}
        >>> keys = ['K', 'dcvs_clip_max']
        >>> d = tuple([])
        >>> subdict_ = dict_subset(dict_, keys)
        >>> result = ut.repr4(subdict_, sorted_=True, newlines=False)
        >>> print(result)
        {'K': 3, 'dcvs_clip_max': 0.2}
    """
    if default is util_const.NoParam:
        items = dict_take(dict_, keys)
    else:
        items = dict_take(dict_, keys, default)
    subdict_ = OrderedDict(list(zip(keys, items)))
    #item_sublist = [(key, dict_[key]) for key in keys]
    ##subdict_ = type(dict_)(item_sublist)  # maintain old dict format
    #subdict_ = OrderedDict(item_sublist)
    return subdict_