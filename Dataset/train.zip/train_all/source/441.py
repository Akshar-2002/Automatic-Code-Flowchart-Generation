def init_submodules(self, cache):
    """cache = path or bool"""
    self.cache = CacheService(cache, weakref.proxy(self)) 
    self.mesh = PrecomputedMeshService(weakref.proxy(self))
    self.skeleton = PrecomputedSkeletonService(weakref.proxy(self))