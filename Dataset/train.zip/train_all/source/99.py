def list_device_events(self, **kwargs):
        """List all device logs.

        :param int limit: The number of logs to retrieve.
        :param str order: The ordering direction, ascending (asc) or
            descending (desc)
        :param str after: Get logs after/starting at given `device_event_id`
        :param dict filters: Dictionary of filters to apply.
        :return: list of :py:class:`DeviceEvent` objects
        :rtype: PaginatedResponse
        """
        kwargs = self._verify_sort_options(kwargs)
        kwargs = self._verify_filters(kwargs, DeviceEvent, True)

        api = self._get_api(device_directory.DefaultApi)
        return PaginatedResponse(api.device_log_list, lwrap_type=DeviceEvent, **kwargs)