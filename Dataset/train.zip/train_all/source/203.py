def gps_raw_int_encode(self, time_usec, fix_type, lat, lon, alt, eph, epv, vel, cog, satellites_visible):
                '''
                The global position, as returned by the Global Positioning System
                (GPS). This is                 NOT the global position
                estimate of the system, but rather a RAW sensor value.
                See message GLOBAL_POSITION for the global position
                estimate. Coordinate frame is right-handed, Z-axis up
                (GPS frame).

                time_usec                 : Timestamp (microseconds since UNIX epoch or microseconds since system boot) (uint64_t)
                fix_type                  : See the GPS_FIX_TYPE enum. (uint8_t)
                lat                       : Latitude (WGS84), in degrees * 1E7 (int32_t)
                lon                       : Longitude (WGS84), in degrees * 1E7 (int32_t)
                alt                       : Altitude (AMSL, NOT WGS84), in meters * 1000 (positive for up). Note that virtually all GPS modules provide the AMSL altitude in addition to the WGS84 altitude. (int32_t)
                eph                       : GPS HDOP horizontal dilution of position (unitless). If unknown, set to: UINT16_MAX (uint16_t)
                epv                       : GPS VDOP vertical dilution of position (unitless). If unknown, set to: UINT16_MAX (uint16_t)
                vel                       : GPS ground speed (m/s * 100). If unknown, set to: UINT16_MAX (uint16_t)
                cog                       : Course over ground (NOT heading, but direction of movement) in degrees * 100, 0.0..359.99 degrees. If unknown, set to: UINT16_MAX (uint16_t)
                satellites_visible        : Number of satellites visible. If unknown, set to 255 (uint8_t)

                '''
                return MAVLink_gps_raw_int_message(time_usec, fix_type, lat, lon, alt, eph, epv, vel, cog, satellites_visible)