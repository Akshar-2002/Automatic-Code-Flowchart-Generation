def update(cls, whitelist_sdd_id, monetary_account_paying_id=None,
               maximum_amount_per_month=None, custom_headers=None):
        """
        :type user_id: int
        :type whitelist_sdd_id: int
        :param monetary_account_paying_id: ID of the monetary account of which
        you want to pay from.
        :type monetary_account_paying_id: int
        :param maximum_amount_per_month: The maximum amount of money that is
        allowed to be deducted based on the whitelist.
        :type maximum_amount_per_month: object_.Amount
        :type custom_headers: dict[str, str]|None

        :rtype: BunqResponseInt
        """

        if custom_headers is None:
            custom_headers = {}

        api_client = client.ApiClient(cls._get_api_context())

        request_map = {
            cls.FIELD_MONETARY_ACCOUNT_PAYING_ID: monetary_account_paying_id,
            cls.FIELD_MAXIMUM_AMOUNT_PER_MONTH: maximum_amount_per_month
        }
        request_map_string = converter.class_to_json(request_map)
        request_map_string = cls._remove_field_for_request(request_map_string)

        request_bytes = request_map_string.encode()
        endpoint_url = cls._ENDPOINT_URL_UPDATE.format(cls._determine_user_id(),
                                                       whitelist_sdd_id)
        response_raw = api_client.put(endpoint_url, request_bytes,
                                      custom_headers)

        return BunqResponseInt.cast_from_bunq_response(
            cls._process_for_id(response_raw)
        )