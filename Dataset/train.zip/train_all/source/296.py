def get_prefix_stripper(strip_prefix):
    """ Return function to strip `strip_prefix` prefix from string if present

    Parameters
    ----------
    prefix : str
        Prefix to strip from the beginning of string if present

    Returns
    -------
    stripper : func
        function such that ``stripper(a_string)`` will strip `prefix` from
        ``a_string`` if present, otherwise pass ``a_string`` unmodified
    """
    n = len(strip_prefix)
    def stripper(path):
        return path if not path.startswith(strip_prefix) else path[n:]
    return stripper