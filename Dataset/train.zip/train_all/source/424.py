def add_federation(self, provider, federated_id):
        """
        Add federated login to the current user
        :param provider:
        :param federated_id:
        :return:
        """
        models.AuthUserFederation.new(user=self,
                                      provider=provider,
                                      federated_id=federated_id)