def assert_raises(expected_exception, extras=None, *args, **kwargs):
    """Assert that an exception is raised when a function is called.

    If no exception is raised, test fail. If an exception is raised but not
    of the expected type, the exception is let through.

    This should only be used as a context manager:
        with assert_raises(Exception):
            func()

    Args:
        expected_exception: An exception class that is expected to be
            raised.
        extras: An optional field for extra information to be included in
            test result.
    """
    context = _AssertRaisesContext(expected_exception, extras=extras)
    return context