def user_can_edit_news(user):
    """
    Check if the user has permission to edit any of the registered NewsItem
    types.
    """
    newsitem_models = [model.get_newsitem_model()
                       for model in NEWSINDEX_MODEL_CLASSES]

    if user.is_active and user.is_superuser:
        # admin can edit news iff any news types exist
        return bool(newsitem_models)

    for NewsItem in newsitem_models:
        for perm in format_perms(NewsItem, ['add', 'change', 'delete']):
            if user.has_perm(perm):
                return True

    return False