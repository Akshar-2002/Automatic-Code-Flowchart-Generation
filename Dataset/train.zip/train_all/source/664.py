def stop(self, timeout=1.0):
        """Stop the handler thread (from another thread).

        Parameters
        ----------
        timeout : float, optional
            Seconds to wait for server to have *started*.

        """
        if timeout:
            self._running.wait(timeout)
        self._running.clear()
        # Make sure to wake the run thread.
        self._wake.set()