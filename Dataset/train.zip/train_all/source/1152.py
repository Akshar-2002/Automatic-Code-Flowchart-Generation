def assert_no_js_errors(self):
        """ Asserts that there are no JavaScript "SEVERE"-level page errors.
            Works ONLY for Chrome (non-headless) and Chrome-based browsers.
            Does NOT work on Firefox, Edge, IE, and some other browsers:
                * See https://github.com/SeleniumHQ/selenium/issues/1161
            Based on the following Stack Overflow solution:
                * https://stackoverflow.com/a/41150512/7058266 """
        try:
            browser_logs = self.driver.get_log('browser')
        except (ValueError, WebDriverException):
            # If unable to get browser logs, skip the assert and return.
            return

        messenger_library = "//cdnjs.cloudflare.com/ajax/libs/messenger"
        errors = []
        for entry in browser_logs:
            if entry['level'] == 'SEVERE':
                if messenger_library not in entry['message']:
                    # Add errors if not caused by SeleniumBase dependencies
                    errors.append(entry)
        if len(errors) > 0:
            current_url = self.get_current_url()
            raise Exception(
                "JavaScript errors found on %s => %s" % (current_url, errors))