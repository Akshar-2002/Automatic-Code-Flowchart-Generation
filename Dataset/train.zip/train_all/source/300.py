def _ls_print_listing(dir_: str, recursive: bool, all_: bool, long: bool) -> List[Tuple[str, dict, TrainingTrace]]:
    """
    Print names of the train dirs contained in the given dir.

    :param dir_: dir to be listed
    :param recursive: walk recursively in sub-directories, stop at train dirs (--recursive option)
    :param all_: include train dirs with no epochs done (--all option)
    :param long: list more details including model name, model and dataset classes,
                 age, duration and epochs done (--long option)
    :return: list of found training tuples (train_dir, configuration dict, trace)
    """
    all_trainings = []
    for root_dir, train_dirs in walk_train_dirs(dir_):
        if train_dirs:
            if recursive:
                print(root_dir + ':')
            trainings = [(train_dir,
                          load_config(path.join(train_dir, CXF_CONFIG_FILE), []),
                          TrainingTrace.from_file(path.join(train_dir, CXF_TRACE_FILE)))
                         for train_dir
                         in [os.path.join(root_dir, train_dir) for train_dir in train_dirs]]
            if not all_:
                trainings = [train_dir for train_dir in trainings if train_dir[2][TrainingTraceKeys.EPOCHS_DONE]]
            if long:
                print('total {}'.format(len(trainings)))
                _print_trainings_long(trainings)
            else:
                for train_dir, _, _ in trainings:
                    print(path.basename(train_dir))
            all_trainings.extend(trainings)
            if recursive:
                print()

        if not recursive:
            break
    return all_trainings