def convert(self, type_from, type_to, data):
        """Parsers data from with one format and composes with another.

        :param type_from: The unique name of the format to parse with
        :param type_to: The unique name of the format to compose with
        :param data: The text to convert
        """
        try:
            return self.compose(type_to, self.parse(type_from, data))
        except Exception as e:
            raise ValueError(
                "Couldn't convert '{from_}' to '{to}'. Possibly "
                "because the parser of '{from_}' generates a "
                "data structure incompatible with the composer "
                "of '{to}'. This is the original error: \n\n"
                "{error}: {message}".format(from_=type_from, to=type_to,
                                            error=e.__class__.__name__,
                                            message=e.message))