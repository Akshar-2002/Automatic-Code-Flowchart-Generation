def open_file(infile, verbose=True):
    """
    Open file and return a list of the file's lines.
    Try to use utf-8 encoding, and if that fails use Latin-1.

    Parameters
    ----------
    infile : str
        full path to file

    Returns
    ----------
    data: list
        all lines in the file
    """
    try:
        with codecs.open(infile, "r", "utf-8") as f:
            lines = list(f.readlines())
    # file might not exist
    except FileNotFoundError:
        if verbose:
            print(
                '-W- You are trying to open a file: {} that does not exist'.format(infile))
        return []
    # encoding might be wrong
    except UnicodeDecodeError:
        try:
            with codecs.open(infile, "r", "Latin-1") as f:
                print(
                    '-I- Using less strict decoding for {}, output may have formatting errors'.format(infile))
                lines = list(f.readlines())
        # if file exists, and encoding is correct, who knows what the problem is
        except Exception as ex:
            print("-W- ", type(ex), ex)
            return []
    except Exception as ex:
        print("-W- ", type(ex), ex)
        return []
    # don't leave a blank line at the end
    i = 0
    while i < 10:
        if not len(lines[-1].strip("\n").strip("\t")):
            lines = lines[:-1]
            i += 1
        else:
            i = 10
    return lines