def imshow(image, auto_subplot=False, **kwargs):
        """ Displays an image.
        Parameters
        ----------
        image : :obj:`perception.Image`
            image to display
        auto_subplot : bool
            whether or not to automatically subplot for multi-channel images e.g. rgbd
        """
        if isinstance(image, BinaryImage) or isinstance(image, GrayscaleImage):
            plt.imshow(image.data, cmap=plt.cm.gray, **kwargs)
        elif isinstance(image, ColorImage) or isinstance(image, SegmentationImage):
            plt.imshow(image.data, **kwargs)
        elif isinstance(image, DepthImage):
            plt.imshow(image.data, cmap=plt.cm.gray_r, **kwargs)
        elif isinstance(image, RgbdImage):
            if auto_subplot:
                plt.subplot(1,2,1)
                plt.imshow(image.color.data, **kwargs)
                plt.axis('off')
                plt.subplot(1,2,2)
                plt.imshow(image.depth.data, cmap=plt.cm.gray_r, **kwargs)
            else:
                plt.imshow(image.color.data, **kwargs)
        elif isinstance(image, GdImage):
            if auto_subplot:
                plt.subplot(1,2,1)
                plt.imshow(image.gray.data, cmap=plt.cm.gray, **kwargs)
                plt.axis('off')
                plt.subplot(1,2,2)
                plt.imshow(image.depth.data, cmap=plt.cm.gray_r, **kwargs)
            else:
                plt.imshow(image.gray.data, cmap=plt.cm.gray, **kwargs)
        plt.axis('off')