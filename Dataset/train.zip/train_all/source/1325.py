def do_open(self, args):
        """Open resource by number, resource name or alias: open 3"""

        if not args:
            print('A resource name must be specified.')
            return

        if self.current:
            print('You can only open one resource at a time. Please close the current one first.')
            return

        if args.isdigit():
            try:
                args = self.resources[int(args)][0]
            except IndexError:
                print('Not a valid resource number. Use the command "list".')
                return

        try:
            self.current = self.resource_manager.open_resource(args)
            print('{} has been opened.\n'
                  'You can talk to the device using "write", "read" or "query".\n'
                  'The default end of message is added to each message.'.format(args))

            self.py_attr = []
            self.vi_attr = []
            for attr in getattr(self.current, 'visa_attributes_classes', ()):
                if attr.py_name:
                    self.py_attr.append(attr.py_name)
                self.vi_attr.append(attr.visa_name)

            self.prompt = '(open) '
        except Exception as e:
            print(e)