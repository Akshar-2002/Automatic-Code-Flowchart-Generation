def correct_means(means, opt_t0s, combs):
    """Applies optimal t0s to gaussians means.

    Should be around zero afterwards.

    Parameters
    ----------
    means: numpy array of means of gaussians of all PMT combinations
    opt_t0s: numpy array of optimal t0 values for all PMTs
    combs: pmt combinations used to correct

    Returns
    -------
    corrected_means: numpy array of corrected gaussian means for all PMT combs

    """
    corrected_means = np.array([(opt_t0s[comb[1]] - opt_t0s[comb[0]]) - mean
                                for mean, comb in zip(means, combs)])
    return corrected_means