def lpc(blk, order=None):
  """
  Find the Linear Predictive Coding (LPC) coefficients as a ZFilter object,
  the analysis whitening filter. This implementation uses the autocorrelation
  method, using numpy.linalg.pinv as a linear system solver.

  Parameters
  ----------
  blk :
    An iterable with well-defined length. Don't use this function with Stream
    objects!
  order :
    The order of the resulting ZFilter object. Defaults to ``len(blk) - 1``.

  Returns
  -------
  A FIR filter, as a ZFilter object. The mean squared error over the given
  block is in its "error" attribute.

  Hint
  ----
  See ``lpc.kautocor`` example, which should apply equally for this strategy.

  See Also
  --------
  lpc.autocor:
    LPC coefficients by using one of the autocorrelation method strategies.
  lpc.kautocor:
    LPC coefficients obtained with Levinson-Durbin algorithm.

  """
  from numpy import matrix
  from numpy.linalg import pinv
  acdata = acorr(blk, order)
  coeffs = pinv(toeplitz(acdata[:-1])) * -matrix(acdata[1:]).T
  coeffs = coeffs.T.tolist()[0]
  filt = 1  + sum(ai * z ** -i for i, ai in enumerate(coeffs, 1))
  filt.error = acdata[0] + sum(a * c for a, c in xzip(acdata[1:], coeffs))
  return filt