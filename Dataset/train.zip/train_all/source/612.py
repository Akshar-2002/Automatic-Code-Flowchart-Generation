def create_widget(self):
        """ Create the underlying widget.

        """
        d = self.declaration
        self.widget = GridLayout(self.get_context(), None, d.style)