def connect(self, path="", headers=None, query=None, timeout=0, **kwargs):
        """
        make the actual connection to the websocket

        :param headers: dict, key/val pairs of any headers to add to connection, if
            you would like to override headers just pass in an empty value
        :param query: dict, any query string params you want to send up with the connection
            url
        :returns: Payload, this will return the CONNECT response from the websocket
        """
        ret = None
        ws_url = self.get_fetch_url(path, query)
        ws_headers = self.get_fetch_headers("GET", headers)
        ws_headers = ['{}: {}'.format(h[0], h[1]) for h in ws_headers.items() if h[1]]
        timeout = self.get_timeout(timeout=timeout, **kwargs)

        self.set_trace(kwargs.pop("trace", False))
        #pout.v(websocket_url, websocket_headers, self.query_kwargs, self.headers)

        try:
            logger.debug("{} connecting to {}".format(self.client_id, ws_url))
            self.ws = websocket.create_connection(
                ws_url,
                header=ws_headers,
                timeout=timeout,
                sslopt={'cert_reqs':ssl.CERT_NONE},
            )

            ret = self.recv_callback(callback=lambda r: r.uuid == "CONNECT")
            if ret.code >= 400:
                raise IOError("Failed to connect with code {}".format(ret.code))

#             self.headers = headers
#             self.query_kwargs = query_kwargs

        except websocket.WebSocketTimeoutException:
            raise IOError("Failed to connect within {} seconds".format(timeout))

        except websocket.WebSocketException as e:
            raise IOError("Failed to connect with error: {}".format(e))

        except socket.error as e:
            # this is an IOError, I just wanted to be aware of that, most common
            # problem is: [Errno 111] Connection refused
            raise

        return ret