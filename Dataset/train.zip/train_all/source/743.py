def clean(self):
        """
        Cleans/checks user has entered all required attributes. This might save
        some queries from being sent to server if they are totally wrong.
        """
        if not all([self._type, self._requested, self._value, self._action]):
            raise MalFormattedSource(
                "<type, requested, value, action> fields are required."
            )