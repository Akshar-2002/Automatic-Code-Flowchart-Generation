def _parse_reactome_association_file(
            self, file, limit=None, subject_prefix=None, object_prefix=None):
        """
        Parse ensembl gene to reactome pathway file
        :param file: file path (not handle)
        :param limit: limit (int, optional) limit the number of rows processed
        :return: None
        """
        eco_map = Reactome.get_eco_map(Reactome.map_files['eco_map'])
        count = 0
        with open(file, 'r') as tsvfile:
            reader = csv.reader(tsvfile, delimiter="\t")
            for row in reader:
                (component, pathway_id, pathway_iri, pathway_label, go_ecode,
                species_name) = row
                count += 1
                self._add_component_pathway_association(
                    eco_map, component, subject_prefix, pathway_id, object_prefix,
                    pathway_label, go_ecode)

                if limit is not None and count >= limit:
                    break

        return