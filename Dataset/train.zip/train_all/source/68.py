def download_ftp_url(source_url, target_uri, buffer_size=8192):
    """Uses urllib. thread safe?"""

    ensure_file_directory(target_uri)

    with urllib.request.urlopen(source_url) as source_file:
        with open(target_uri, 'wb') as target_file:
            shutil.copyfileobj(source_file, target_file, buffer_size)