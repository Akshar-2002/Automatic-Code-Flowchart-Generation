def setCurrentSchemaColumn(self, column):
        """
        Sets the current item based on the inputed column.
        
        :param      column | <orb.Column> || None
        """
        if column == self._column:
            self.treeWidget().setCurrentItem(self)
            return True
        
        for c in range(self.childCount()):
            if self.child(c).setCurrentSchemaColumn(column):
                self.setExpanded(True)
                return True
        return None