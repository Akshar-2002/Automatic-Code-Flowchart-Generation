def isNumber(self, value):
        """
        Validate whether a value is a number or not
        """
        try:
            str(value)
            float(value)
            return True

        except ValueError:
            return False