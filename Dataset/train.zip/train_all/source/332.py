def load(self):
        """
        Loads the children for this item.
        """
        if self._loaded:
            return
        
        self.setChildIndicatorPolicy(self.DontShowIndicatorWhenChildless)
        
        self._loaded = True
        column = self.schemaColumn()
        if not column.isReference():
            return
        
        ref = column.referenceModel()
        if not ref:
            return
        
        columns = sorted(ref.schema().columns(),
                         key=lambda x: x.name().strip('_'))
        for column in columns:
            XOrbColumnItem(self, column)