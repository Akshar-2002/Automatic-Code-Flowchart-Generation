def known_dists():
    '''Return a list of all Distributions exporting udata.* entrypoints'''
    return (
        dist for dist in pkg_resources.working_set
        if any(k in ENTRYPOINTS for k in dist.get_entry_map().keys())
    )