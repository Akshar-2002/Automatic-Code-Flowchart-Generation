def remove_html_tag(input_str='', tag=None):
    """
    Returns a string with the html tag and all its contents from a string
    """
    result = input_str
    if tag is not None:
        pattern = re.compile('<{tag}[\s\S]+?/{tag}>'.format(tag=tag))
        result = re.sub(pattern, '', str(input_str))

    return result