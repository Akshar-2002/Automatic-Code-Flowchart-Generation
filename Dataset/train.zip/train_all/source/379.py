def clear(self):
        """
        Remove all content from this paragraph. Paragraph properties are
        preserved. Content includes runs, line breaks, and fields.
        """
        for elm in self._element.content_children:
            self._element.remove(elm)
        return self