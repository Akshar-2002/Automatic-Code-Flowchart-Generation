def _backup_file(path):
    """
    Backup a file but never overwrite an existing backup file
    """
    backup_base = '/var/local/woven-backup'
    backup_path = ''.join([backup_base,path])
    if not exists(backup_path):
        directory = ''.join([backup_base,os.path.split(path)[0]])
        sudo('mkdir -p %s'% directory)
        sudo('cp %s %s'% (path,backup_path))