def list_components(self, dependency_order=True):
        """
        Lists the Components by dependency resolving.

        Usage::

            >>> manager = Manager(("./manager/tests/tests_manager/resources/components/core",))
            >>> manager.register_components()
            True
            >>> manager.list_components()
            [u'core.tests_component_a', u'core.tests_component_b']

        :param dependency_order: Components are returned by dependency order.
        :type dependency_order: bool
        """

        if dependency_order:
            return list(itertools.chain.from_iterable([sorted(list(batch)) for batch in
                                                       foundations.common.dependency_resolver(
                                                           dict((key, value.require) for (key, value) in self))]))
        else:
            return [key for (key, value) in self]