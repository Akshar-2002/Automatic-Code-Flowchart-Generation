def _get_expand_input(self, passed_settings):
        """
            If expand value is explicitliy passed, just return it.
            If parsing from request, ensure that the value complies with
            the "permitted_expands" list passed into the context from the
            FlexFieldsMixin.
        """
        value = passed_settings.get("expand")

        if len(value) > 0:
            return value

        if not self._can_access_request:
            return []

        expand = self._parse_request_list_value("expand")

        if "permitted_expands" in self.context:
            permitted_expands = self.context["permitted_expands"]

            if "~all" in expand or "*" in expand:
                return permitted_expands
            else:
                return list(set(expand) & set(permitted_expands))

        return expand