def get_bootdev(self):
        """Get current boot device override information.

        Provides the current requested boot device.  Be aware that not all IPMI
        devices support this.  Even in BMCs that claim to, occasionally the
        BIOS or UEFI fail to honor it. This is usually only applicable to the
        next reboot.

        :raises: IpmiException on an error.
        :returns: dict --The response will be provided in the return as a dict
        """
        response = self.raw_command(netfn=0, command=9, data=(5, 0, 0))
        # interpret response per 'get system boot options'
        if 'error' in response:
            raise exc.IpmiException(response['error'])
        # this should only be invoked for get system boot option complying to
        # ipmi spec and targeting the 'boot flags' parameter
        assert (response['command'] == 9 and
                response['netfn'] == 1 and
                response['data'][0] == 1 and
                (response['data'][1] & 0b1111111) == 5)
        if (response['data'][1] & 0b10000000 or
                not response['data'][2] & 0b10000000):
            return {'bootdev': 'default', 'persistent': True}
        else:  # will consult data2 of the boot flags parameter for the data
            persistent = False
            uefimode = False
            if response['data'][2] & 0b1000000:
                persistent = True
            if response['data'][2] & 0b100000:
                uefimode = True
            bootnum = (response['data'][3] & 0b111100) >> 2
            bootdev = boot_devices.get(bootnum)
            if bootdev:
                return {'bootdev': bootdev,
                        'persistent': persistent,
                        'uefimode': uefimode}
            else:
                return {'bootdev': bootnum,
                        'persistent': persistent,
                        'uefimode': uefimode}