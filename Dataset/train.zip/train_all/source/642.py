def new_keys(self):
        """
        Access the new_keys

        :returns: twilio.rest.api.v2010.account.new_key.NewKeyList
        :rtype: twilio.rest.api.v2010.account.new_key.NewKeyList
        """
        if self._new_keys is None:
            self._new_keys = NewKeyList(self._version, account_sid=self._solution['sid'], )
        return self._new_keys