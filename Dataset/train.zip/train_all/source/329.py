def fill(self, paths):
        """
        Initialise the tree.

        paths is a list of strings where each string is the relative path to some
        file.
        """
        for path in paths:
            tree = self.tree
            parts = tuple(path.split('/'))
            dir_parts = parts[:-1]
            built = ()
            for part in dir_parts:
                self.cache[built] = tree
                built += (part, )
                parent = tree
                tree = parent.folders.get(part, empty)
                if tree is empty:
                    tree = parent.folders[part] = TreeItem(name=built, folders={}, files=set(), parent=parent)

            self.cache[dir_parts] = tree
            tree.files.add(parts[-1])