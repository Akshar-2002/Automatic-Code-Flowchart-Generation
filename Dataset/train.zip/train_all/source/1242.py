def all_table_names_in_schema(self, schema, cache=False,
                                  cache_timeout=None, force=False):
        """Parameters need to be passed as keyword arguments.

        For unused parameters, they are referenced in
        cache_util.memoized_func decorator.

        :param schema: schema name
        :type schema: str
        :param cache: whether cache is enabled for the function
        :type cache: bool
        :param cache_timeout: timeout in seconds for the cache
        :type cache_timeout: int
        :param force: whether to force refresh the cache
        :type force: bool
        :return: table list
        :rtype: list
        """
        tables = []
        try:
            tables = self.db_engine_spec.get_table_names(
                inspector=self.inspector, schema=schema)
        except Exception as e:
            logging.exception(e)
        return tables