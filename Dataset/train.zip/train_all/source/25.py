def forward(self, X):
        """Forward function.

        :param X: The input (batch) of the model contains word sequences for lstm,
            features and feature weights.
        :type X: For word sequences: a list of torch.Tensor pair (word sequence
            and word mask) of shape (batch_size, sequence_length).
            For features: torch.Tensor of shape (batch_size, sparse_feature_size).
            For feature weights: torch.Tensor of shape
            (batch_size, sparse_feature_size).
        :return: The output of LSTM layer.
        :rtype: torch.Tensor of shape (batch_size, num_classes)
        """

        s = X[:-2]
        f = X[-2]
        w = X[-1]

        batch_size = len(f)

        # Generate lstm weight indices
        x_idx = self._cuda(
            torch.as_tensor(np.arange(1, self.settings["lstm_dim"] + 1)).repeat(
                batch_size, 1
            )
        )

        outputs = self._cuda(torch.Tensor([]))

        # Calculate textual features from LSTMs
        for i in range(len(s)):
            state_word = self.lstms[0].init_hidden(batch_size)
            output = self.lstms[0].forward(s[i][0], s[i][1], state_word)
            outputs = torch.cat((outputs, output), 1)

        # Concatenate textual features with multi-modal features
        feaures = torch.cat((x_idx, f), 1)
        weights = torch.cat((outputs, w), 1)

        return self.sparse_linear(feaures, weights)