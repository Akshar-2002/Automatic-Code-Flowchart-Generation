def make_job_details(self, row_idx):
        """Create a `JobDetails` from an `astropy.table.row.Row` """
        row = self._table[row_idx]
        job_details = JobDetails.create_from_row(row)
        job_details.get_file_paths(self._file_archive, self._table_id_array)
        self._cache[job_details.fullkey] = job_details
        return job_details