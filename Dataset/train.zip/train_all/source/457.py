def get(self, roleId):
        """Get a specific role information"""
        role = db.Role.find_one(Role.role_id == roleId)

        if not role:
            return self.make_response('No such role found', HTTP.NOT_FOUND)

        return self.make_response({'role': role})