def _get_candidates(self, v):
        """ Collect candidates from all buckets from all hashes """
        candidates = []
        for lshash in self.lshashes:
            for bucket_key in lshash.hash_vector(v, querying=True):
                bucket_content = self.storage.get_bucket(
                    lshash.hash_name,
                    bucket_key,
                )
                #print 'Bucket %s size %d' % (bucket_key, len(bucket_content))
                candidates.extend(bucket_content)
        return candidates