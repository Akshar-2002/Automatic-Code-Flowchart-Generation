def surfnm(a, b, c, point):
    """
    This routine computes the outward-pointing, unit normal vector
    from a point on the surface of an ellipsoid.

    http://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/cspice/surfnm_c.html

    :param a: Length of the ellisoid semi-axis along the x-axis.
    :type a: float
    :param b: Length of the ellisoid semi-axis along the y-axis.
    :type b: float
    :param c: Length of the ellisoid semi-axis along the z-axis.
    :type c: float
    :param point: Body-fixed coordinates of a point on the ellipsoid'
    :type point: 3-Element Array of floats
    :return: Outward pointing unit normal to ellipsoid at point.
    :rtype: 3-Element Array of floats
    """
    a = ctypes.c_double(a)
    b = ctypes.c_double(b)
    c = ctypes.c_double(c)
    point = stypes.toDoubleVector(point)
    normal = stypes.emptyDoubleVector(3)
    libspice.surfnm_c(a, b, c, point, normal)
    return stypes.cVectorToPython(normal)