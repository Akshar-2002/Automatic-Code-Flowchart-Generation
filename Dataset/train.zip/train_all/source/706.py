def importobject(module_name, object_name):
    """
    Imports the object with the given name from the inputted module.
    
    :param      module_name | <str>
                object_name | <str>
    
    :usage      |>>> import projex
                |>>> modname = 'projex.envmanager'
                |>>> attr = 'EnvManager'
                |>>> EnvManager = projex.importobject(modname, attr)
    
    :return     <object> || None
    """
    if module_name not in sys.modules:
        try:
            __import__(module_name)
        except ImportError:
            logger.debug(traceback.print_exc())
            logger.error('Could not import module: %s', module_name)
            return None

    module = sys.modules.get(module_name)
    if not module:
        logger.warning('No module %s found.' % module_name)
        return None

    if not hasattr(module, object_name):
        logger.warning('No object %s in %s.' % (object_name, module_name))
        return None

    return getattr(module, object_name)