def remove_redundant_verts(self, eps=1e-10):
        """Given verts and faces, this remove colocated vertices"""
        import numpy as np
        from scipy.spatial import cKDTree # FIXME pylint: disable=no-name-in-module
        fshape = self.f.shape
        tree = cKDTree(self.v)
        close_pairs = list(tree.query_pairs(eps))
        if close_pairs:
            close_pairs = np.sort(close_pairs, axis=1)
            # update faces to not refer to redundant vertices
            equivalent_verts = np.arange(self.v.shape[0])
            for v1, v2 in close_pairs:
                if equivalent_verts[v2] > v1:
                    equivalent_verts[v2] = v1
            self.f = equivalent_verts[self.f.flatten()].reshape((-1, 3))
            # get rid of unused verts, and update faces accordingly
            vertidxs_left = np.unique(self.f)
            repl = np.arange(np.max(self.f)+1)
            repl[vertidxs_left] = np.arange(len(vertidxs_left))
            self.v = self.v[vertidxs_left]
            self.f = repl[self.f].reshape((-1, fshape[1]))