def operators(self, ignore=0):
        """
        Returns a list of operators for this plugin.
        
        :return     <str>
        """
        return [k for k, v in self._operatorMap.items() if not v.flags & ignore]