def check_sensor(self, helper):
        """
        check the status of the specified sensor
        """
        try:
            sensor_name, sensor_state, sensor_type = self.sess.get_oids(
                self.oids['oid_sensor_name'], self.oids['oid_sensor_state'], self.oids['oid_sensor_type'])
        except health_monitoring_plugins.SnmpException as e:
            helper.exit(summary=str(e), exit_code=unknown, perfdata='')

        try:
            sensor_state_string = states[int(sensor_state)]
        except KeyError as e:
            helper.exit(summary="Invalid sensor response " + sensor_state, exit_code=unknown, perfdata='')
        sensor_unit = "" # if it's a onOff Sensor or something like that, we need an empty string for the summary
        sensor_unit_string = ""
        sensor_value = ""
        sensor_digit = ""
        real_sensor_value = ""
        sensor_warning_upper = ""
        sensor_critical_upper = ""
        sensor_warning_lower = ""
        sensor_critical_lower = ""

        if int(sensor_type) not in [14, 16, 17, 18, 19, 20]:
            # for all sensors except these, we want to calculate the real value and show the metric.
            # 14: onOff
            # 16: vibration
            # 17: waterDetection
            # 18: smokeDetection
            # 19: binary
            # 20: contact
            try:
                sensor_unit, sensor_digit, sensor_warning_upper, sensor_critical_upper, sensor_warning_lower, sensor_critical_lower, sensor_value = self.sess.get_oids(
                    self.oids['oid_sensor_unit'], self.oids['oid_sensor_digit'],
                    self.oids['oid_sensor_warning_upper'], self.oids['oid_sensor_critical_upper'],
                    self.oids['oid_sensor_warning_lower'], self.oids['oid_sensor_critical_lower'],
                    self.oids['oid_sensor_value'])
            except health_monitoring_plugins.SnmpException as e:
                helper.exit(summary=str(e), exit_code=unknown, perfdata='')

            sensor_unit_string          = units[int(sensor_unit)]
            real_sensor_value           = real_value(int(sensor_value), sensor_digit)
            real_sensor_warning_upper   = real_value(sensor_warning_upper, sensor_digit)
            real_sensor_critical_upper  = real_value(sensor_critical_upper, sensor_digit)
            real_sensor_warning_lower   = real_value(sensor_warning_lower, sensor_digit)
            real_sensor_critical_lower  = real_value(sensor_critical_lower, sensor_digit)
            # metrics are only possible for these sensors
            helper.add_metric(sensor_name + " -%s- " % sensor_unit_string, real_sensor_value,
                              real_sensor_warning_lower +\
                              ":" + real_sensor_warning_upper, real_sensor_critical_lower +\
                              ":" + real_sensor_critical_upper, "", "", "")

        # "OK" state
        if sensor_state_string in ["closed", "normal", "on", "notDetected", "ok", "yes", "one", "two", "inSync"]:
            helper.status(ok)

        # "WARNING" state
        elif sensor_state_string in ["open", "belowLowerWarning", "aboveUpperWarning", "marginal", "standby"]:
            helper.status(warning)

        # "CRITICAL" state
        elif sensor_state_string in ["belowLowerCritical", "aboveUpperCritical", "off", "detected", "alarmed", "fail", "no", "outOfSync"]:
            helper.status(critical)

        # "UNKOWN" state    
        elif sensor_state_string in ["unavailable"]:
            helper.status(unknown)

        # received an undefined state    
        else:
            helper.exit(summary="Something went wrong - received undefined state", exit_code=unknown, perfdata='')

        # summary is shown for all sensors
        helper.add_summary("Sensor %s - '%s' %s%s is: %s" % (self.number, sensor_name, real_sensor_value, sensor_unit_string, sensor_state_string))