def measure(self, v, rf, off=None):
        """Create/convert a measure using the frame state set on the measures
        server instance (via :meth:`do_frame`)

        :param v: The measure to convert

        :param rf: The frame reference to convert to

        :param off: The optional offset for the measure

        """
        if off is None:
            off = {}
        keys = ["m0", "m1", "m2"]
        for key in keys:
            if key in v:
                if dq.is_quantity(v[key]):
                    v[key] = v[key].to_dict()
        return _measures.measure(self, v, rf, off)