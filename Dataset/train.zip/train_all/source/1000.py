def forge_relationship(self, left_id, left_type, right_id, right_type,
                           rel_type='Related To', rel_date=None,
                           rel_confidence='high', rel_reason=''):
        """
        Forges a relationship between two TLOs.

        Args:
            left_id: The CRITs ID of the first indicator
            left_type: The CRITs TLO type of the first indicator
            right_id: The CRITs ID of the second indicator
            right_type: The CRITs TLO type of the second indicator
            rel_type: The relationships type ("Related To", etc)
            rel_date: datetime.datetime object for the date of the
                relationship. If left blank, it will be datetime.datetime.now()
            rel_confidence: The relationship confidence (high, medium, low)
            rel_reason: Reason for the relationship.
        Returns:
            True if the relationship was created. False otherwise.
        """
        if not rel_date:
            rel_date = datetime.datetime.now()
        type_trans = self._type_translation(left_type)
        submit_url = '{}/{}/{}/'.format(self.url, type_trans, left_id)

        params = {
            'api_key': self.api_key,
            'username': self.username,
            }

        data = {
            'action': 'forge_relationship',
            'right_type': right_type,
            'right_id': right_id,
            'rel_type': rel_type,
            'rel_date': rel_date,
            'rel_confidence': rel_confidence,
            'rel_reason': rel_reason
        }

        r = requests.patch(submit_url, params=params, data=data,
                           proxies=self.proxies, verify=self.verify)
        if r.status_code == 200:
            log.debug('Relationship built successfully: {0} <-> '
                      '{1}'.format(left_id, right_id))
            return True
        else:
            log.error('Error with status code {0} and message {1} between '
                      'these indicators: {2} <-> '
                      '{3}'.format(r.status_code, r.text, left_id, right_id))
            return False