def get_field_min_max(self, name, **query_dict):
        """Returns the minimum and maximum values of the specified field. This requires
        two search calls to the service, each requesting a single value of a single
        field.

        @param name(string) Name of the field
        @param q(string) Query identifying range of records for min and max values
        @param fq(string) Filter restricting range of query

        @return list of [min, max]

        """
        param_dict = query_dict.copy()
        param_dict.update({'rows': 1, 'fl': name, 'sort': '%s asc' % name})
        try:
            min_resp_dict = self._post_query(**param_dict)
            param_dict['sort'] = '%s desc' % name
            max_resp_dict = self._post_query(**param_dict)
            return (
                min_resp_dict['response']['docs'][0][name],
                max_resp_dict['response']['docs'][0][name],
            )
        except Exception:
            self._log.exception('Exception')
            raise