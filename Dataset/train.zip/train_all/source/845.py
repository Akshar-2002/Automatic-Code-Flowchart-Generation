def process_messages(self):
        """
        Read from the incoming_message_mailbox and report to the storage backend
        based on the first message found there.
        Returns: None
        """
        try:
            msg = self.msgbackend.pop(self.incoming_message_mailbox)
            self.handle_incoming_message(msg)
        except queue.Empty:
            logger.debug("Worker message queue currently empty.")