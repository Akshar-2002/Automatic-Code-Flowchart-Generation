def _add_header_client_encryption_hmac(request_bytes, key, iv, custom_headers):
    """
    :type request_bytes: bytes
    :type key: bytes
    :type iv: bytes
    :type custom_headers: dict[str, str]

    :rtype: None
    """

    hashed = hmac.new(key, iv + request_bytes, sha1)
    hashed_base64 = base64.b64encode(hashed.digest()).decode()
    custom_headers[_HEADER_CLIENT_ENCRYPTION_HMAC] = hashed_base64