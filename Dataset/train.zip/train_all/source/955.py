def fromimporterror(cls, bundle, importerid, rsid, exception, endpoint):
        # type: (Bundle, Tuple[str, str], Tuple[Tuple[str, str], int], Optional[Tuple[Any, Any, Any]], EndpointDescription) -> RemoteServiceAdminEvent
        """
        Creates a RemoteServiceAdminEvent object from an import error
        """
        return RemoteServiceAdminEvent(
            RemoteServiceAdminEvent.IMPORT_ERROR,
            bundle,
            importerid,
            rsid,
            None,
            None,
            exception,
            endpoint,
        )