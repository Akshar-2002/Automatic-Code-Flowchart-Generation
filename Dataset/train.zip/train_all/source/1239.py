def printed_out(self, name):
        """
        Create a string representation of the action
        """
        opt = self.variables().optional_namestring()
        req = self.variables().required_namestring()
        out = ''
        out += '|   |\n'
        out += '|   |---{}({}{})\n'.format(name, req, opt)
        if self.description:
            out += '|   |       {}\n'.format(self.description)
        return out