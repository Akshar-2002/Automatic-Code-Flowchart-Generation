def load_bytecode_definitions(*, path=None) -> dict:
    """Load bytecode definitions from JSON file.

    If no path is provided the default bytecode.json will be loaded.

    :param path: Either None or a path to a JSON file to load containing
                 bytecode definitions.
    """
    if path is not None:
        with open(path, 'rb') as file_in:
            j = json.load(file_in)
    else:
        try:
            j = json.loads(pkgutil.get_data('jawa.util', 'bytecode.json'))
        except json.JSONDecodeError:
            # Unfortunately our best way to handle missing/malformed/empty
            # bytecode.json files since it may not actually be backed by a
            # "real" file.
            return {}

    for definition in j.values():
        # If the entry has any operands take the text labels and convert
        # them into pre-cached struct objects and operand types.
        operands = definition['operands']
        if operands:
            definition['operands'] = [
                [getattr(OperandFmts, oo[0]), OperandTypes[oo[1]]]
                for oo in operands
            ]

    # Return one dict that contains both mnemonic keys and opcode keys.
    return {**j, **{v['op']: v for v in j.values()}}