def open(self, options=None, mimetype='application/octet-stream'):
        """
        open: return a file like object for self.
        The method can be used with the 'with' statment.
        """
        return self.connection.open(self, options, mimetype)