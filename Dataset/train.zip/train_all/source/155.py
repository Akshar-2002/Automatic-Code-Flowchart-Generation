def task(self):
        """
        Find the task for this build.

        Wraps the getTaskInfo RPC.

        :returns: deferred that when fired returns the Task object, or None if
                  we could not determine the task for this build.
        """
        # If we have no .task_id, this is a no-op to return None.
        if not self.task_id:
            return defer.succeed(None)
        return self.connection.getTaskInfo(self.task_id)