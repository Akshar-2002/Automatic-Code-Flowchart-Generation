def make_paginated_list(json, client, cls, parent_id=None, page_url=None,
            filters=None):
        """
        Returns a PaginatedList populated with the first page of data provided,
        and the ability to load additional pages.  This should not be called
        outside of the :any:`LinodeClient` class.

        :param json: The JSON list to use as the first page
        :param client: A LinodeClient to use to load additional pages
        :param parent_id: The parent ID for derived objects
        :param page_url: The URL to use when loading more pages
        :param cls: The class to instantiate for objects
        :param filters: The filters used when making the call that generated
                        this list.  If not provided, this will fail when
                        loading additional pages.

        :returns: An instance of PaginatedList that will represent the entire
                  collection whose first page is json
        """
        l = PaginatedList.make_list(json["data"], client, cls, parent_id=parent_id)
        p = PaginatedList(client, page_url, page=l, max_pages=json['pages'],
                total_items=json['results'], parent_id=parent_id, filters=filters)
        return p