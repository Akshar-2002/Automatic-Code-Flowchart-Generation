def remove_child(self, index):
        """
        Removes child at given index from the Node children.

        Usage::

            >>> node_a = AbstractCompositeNode("MyNodeA")
            >>> node_b = AbstractCompositeNode("MyNodeB", node_a)
            >>> node_c = AbstractCompositeNode("MyNodeC", node_a)
            >>> node_a.remove_child(1)
            True
            >>> [child.name for child in node_a.children]
            [u'MyNodeB']

        :param index: Node index.
        :type index: int
        :return: Removed child.
        :rtype: AbstractNode or AbstractCompositeNode or Object
        """

        if index < 0 or index > len(self.__children):
            return

        child = self.__children.pop(index)
        child.parent = None
        return child