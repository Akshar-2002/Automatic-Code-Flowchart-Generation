def sendtoaddress(self, recv_addr, amount, comment=""):
        """send ammount to address, with optional comment. Returns txid.
        sendtoaddress(ADDRESS, AMMOUNT, COMMENT)"""
        return self.req("sendtoaddress", [recv_addr, amount, comment])