def runExperiment4B(dirName):
  """
  This runs the second experiment in the section "Simulations with Pure Temporal
  Sequences". Here we check accuracy of the L2/L4 networks in classifying the
  sequences. This experiment averages over many parameter combinations and could
  take several minutes.
  """
  # Results are put into a pkl file which can be used to generate the plots.
  # dirName is the absolute path where the pkl file will be placed.
  resultsName = os.path.join(dirName, "sequence_batch_high_dec_normal_features.pkl")

  numTrials = 10
  featureRange = [10, 50, 100, 200]
  seqRange = [50]
  locationRange = [10, 100, 200, 300, 400, 500]

  runExperimentPool(
    numSequences=seqRange,
    numFeatures=featureRange,
    numLocations=locationRange,
    numObjects=[0],
    seqLength=10,
    nTrials=numTrials,
    numWorkers=cpu_count()-1,
    basalPredictedSegmentDecrement=[0.005],
    resultsName=resultsName)