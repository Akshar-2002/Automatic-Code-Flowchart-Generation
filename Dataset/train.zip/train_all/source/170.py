def split_lists(d, split_keys, new_name='split',
                check_length=True, deepcopy=True):
    """split_lists key:list pairs into dicts for each item in the lists
    NB: will only split if all split_keys are present

    Parameters
    ----------
    d : dict
    split_keys : list
        keys to split
    new_name : str
        top level key for split items
    check_length : bool
        if true, raise error if any lists are of a different length
    deepcopy: bool
        deepcopy values

    Examples
    --------

    >>> from pprint import pprint

    >>> d = {'path_key':{'x':[1,2],'y':[3,4],'a':1}}
    >>> new_d = split_lists(d,['x','y'])
    >>> pprint(new_d)
    {'path_key': {'a': 1, 'split': [{'x': 1, 'y': 3}, {'x': 2, 'y': 4}]}}

    >>> split_lists(d,['x','a'])
    Traceback (most recent call last):
    ...
    ValueError: "a" data at the following path is not a list ('path_key',)

    >>> d2 = {'path_key':{'x':[1,7],'y':[3,4,5]}}
    >>> split_lists(d2,['x','y'])
    Traceback (most recent call last):
    ...
    ValueError: lists at the following path do not have the same size ('path_key',)


    """  # noqa: E501
    flattened = flatten2d(d)

    new_d = {}
    for key, value in flattened.items():
        if set(split_keys).issubset(value.keys()):
            # combine_d = {}
            combine_d = []
            sub_d = {}
            length = None
            for subkey, subvalue in value.items():
                if subkey in split_keys:
                    if not isinstance(subvalue, list):
                        raise ValueError(
                            '"{0}" data at the following path is not a list '
                            '{1}'.format(subkey, key))

                    if check_length and length is not None:
                        if len(subvalue) != length:
                            raise ValueError(
                                'lists at the following path '
                                'do not have the same size {0}'.format(key))
                    if length is None:
                        combine_d = [{subkey: v} for v in subvalue]
                    else:
                        for item, val in zip(combine_d, subvalue):
                            item[subkey] = val

                    length = len(subvalue)
                    # new_combine = {k:{subkey:v}
                    # for k,v in enumerate(subvalue)}
                    # combine_d = merge([combine_d,new_combine])
                else:
                    sub_d[subkey] = subvalue
                try:
                    new_d[key] = merge([sub_d, {new_name: combine_d}])
                except ValueError:
                    raise ValueError(
                        'split data key: {0}, already exists at '
                        'this level for {1}'.format(new_name, key))
        else:
            new_d[key] = value

    return unflatten(new_d, deepcopy=deepcopy)