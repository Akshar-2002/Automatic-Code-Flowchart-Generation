def get_user_info(self):
        """
        Get information on the authenticated user.

        :rtype: .UserInfo
        """
        response = self.get_proto(path='/user')
        message = yamcsManagement_pb2.UserInfo()
        message.ParseFromString(response.content)
        return UserInfo(message)