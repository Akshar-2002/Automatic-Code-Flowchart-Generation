def predict(self, data):
        """
        Predict new values by running data through the fit model.

        Parameters
        ----------
        data : pandas.DataFrame
            Table with columns corresponding to the RHS of `model_expression`.

        Returns
        -------
        predicted : ndarray
            Array of predicted values.

        """
        with log_start_finish('_FakeRegressionResults prediction', logger):
            model_design = dmatrix(
                self._rhs, data=data, return_type='dataframe')
            return model_design.dot(self.params).values