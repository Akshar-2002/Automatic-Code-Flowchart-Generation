def find_args(self, text, start=None):
        """implementation details"""
        if start is None:
            start = 0
        first_occurance = text.find(self.__begin, start)
        if first_occurance == -1:
            return self.NOT_FOUND
        previous_found, found = first_occurance + 1, 0
        while True:
            found = self.__find_args_separator(text, previous_found)
            if found == -1:
                return self.NOT_FOUND
            elif text[found] == self.__end:
                return first_occurance, found
            else:
                previous_found = found + 1