def set_source(self, propname, pores):
        r"""
        Applies a given source term to the specified pores

        Parameters
        ----------
        propname : string
            The property name of the source term model to be applied

        pores : array_like
            The pore indices where the source term should be applied

        Notes
        -----
        Source terms cannot be applied in pores where boundary conditions have
        already been set. Attempting to do so will result in an error being
        raised.
        """
        locs = self.tomask(pores=pores)

        if (not np.all(np.isnan(self['pore.bc_value'][locs]))) or \
           (not np.all(np.isnan(self['pore.bc_rate'][locs]))):
            raise Exception('Boundary conditions already present in given ' +
                            'pores, cannot also assign source terms')
        self[propname] = locs
        self.settings['sources'].append(propname)