def CheckEmail(self, email, checkTypo=False):
        '''Checks a Single email if it is correct'''
        contents = email.split('@')
        if len(contents) == 2:
            if contents[1] in self.valid:
                return True
        return False