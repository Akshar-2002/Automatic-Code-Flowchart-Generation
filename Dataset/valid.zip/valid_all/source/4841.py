def remove_prefix(self, prefix):
        """Removes prefix from this set.  This is a no-op if the prefix
        doesn't exist in it.
        """
        if prefix not in self.__prefix_map:
            return

        ni = self.__lookup_prefix(prefix)
        ni.prefixes.discard(prefix)
        del self.__prefix_map[prefix]

        # If we removed the preferred prefix, find a new one.
        if ni.preferred_prefix == prefix:
            ni.preferred_prefix = next(iter(ni.prefixes), None)