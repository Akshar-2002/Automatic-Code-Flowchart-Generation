def join(delim, items, quotes=False):
		"""
		Joins the supplied list of strings after removing any empty strings from the list
		"""
		transform = lambda s: s
		if quotes == True:
			transform = lambda s: s if ' ' not in s else '"{}"'.format(s)
		
		stripped = list([transform(i) for i in items if len(i) > 0])
		if len(stripped) > 0:
			return delim.join(stripped)
		return ''