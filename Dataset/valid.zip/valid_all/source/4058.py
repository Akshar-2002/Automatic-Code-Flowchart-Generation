def prior(self):
        """
        Model prior for particular model.

        Product of eclipse probability (``self.prob``),
        the fraction of scenario that is allowed by the various
        constraints (``self.selectfrac``), and all additional
        factors in ``self.priorfactors``.

        """
        prior = self.prob * self.selectfrac
        for f in self.priorfactors:
            prior *= self.priorfactors[f]
        return prior