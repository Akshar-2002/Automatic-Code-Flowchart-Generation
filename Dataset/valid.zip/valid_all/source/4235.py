def WriteOutput(title, locations, limit, f):
  """Write html to f for up to limit trips between locations.

  Args:
    title: String used in html title
    locations: list of (lat, lng) tuples
    limit: maximum number of queries in the html
    f: a file object
  """
  output_prefix = """
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>%(title)s</title>
</head>
<body>
Random queries for %(title)s<p>
This list of random queries should speed up important manual testing. Here are
some things to check when looking at the results of a query.
<ul>
  <li> Check the agency attribution under the trip results:
  <ul>
    <li> has correct name and spelling of the agency
    <li> opens a page with general information about the service
  </ul>
  <li> For each alternate trip check that each of these is reasonable:
  <ul>
    <li> the total time of the trip
    <li> the time for each leg. Bad data frequently results in a leg going a long
    way in a few minutes.
    <li> the icons and mode names (Tram, Bus, etc) are correct for each leg
    <li> the route names and headsigns are correctly formatted and not
    redundant.
    For a good example see <a
    href="https://developers.google.com/transit/gtfs/examples/display-to-users">
    the screenshots in the Google Transit Feed Specification</a>.
    <li> the shape line on the map looks correct. Make sure the polyline does
    not zig-zag, loop, skip stops or jump far away unless the trip does the
    same thing.
    <li> the route is active on the day the trip planner returns
  </ul>
</ul>
If you find a problem be sure to save the URL. This file is generated randomly.
<ol>
""" % locals()

  output_suffix = """
</ol>
</body>
</html>
""" % locals()

  f.write(transitfeed.EncodeUnicode(output_prefix))
  for source, destination in zip(locations[0:limit], locations[1:limit + 1]):
    f.write(transitfeed.EncodeUnicode("<li>%s\n" %
                                      LatLngsToGoogleLink(source, destination)))
  f.write(transitfeed.EncodeUnicode(output_suffix))