def model_counts_spectrum(self, name, logemin, logemax, weighted=False):
        """Return the model counts spectrum of a source.

        Parameters
        ----------
        name : str
           Source name.

        """
        # EAC, we need this b/c older version of the ST don't have the right signature
        try:
            cs = np.array(self.like.logLike.modelCountsSpectrum(
                str(name), weighted))
        except (TypeError, NotImplementedError):
            cs = np.array(self.like.logLike.modelCountsSpectrum(str(name)))
        imin = utils.val_to_edge(self.log_energies, logemin)[0]
        imax = utils.val_to_edge(self.log_energies, logemax)[0]
        if imax <= imin:
            raise Exception('Invalid energy range.')
        return cs[imin:imax]