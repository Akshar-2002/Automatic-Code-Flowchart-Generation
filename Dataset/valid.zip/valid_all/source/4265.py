def b58encode(b, errors='strict'):
    "Encode bytes to a base58-encoded string."
    len_ = len(b)

    # Convert big-endian bytes to integer
    n = BigInteger.deserialize(BytesIO(b), len_)

    # Divide that integer into base58
    res = []
    while n > 0:
        n, r = divmod (n, 58)
        res.append(b58digits[r])
    res = ''.join(res[::-1])

    # Encode leading zeros as base58 zeros
    pad = 0
    for c in b:
        if c == six.int2byte(0): pad += 1
        else: break
    return (b58digits[0] * pad + res, len_)