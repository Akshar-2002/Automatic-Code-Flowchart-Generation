def prepare_namespace(self, func):
        """
        Prepares the function to be run after deserializing it.
        Re-associates any previously bound variables and modules from the closure

        Returns:
            callable: ready-to-call function
        """
        if self.is_imethod:
            to_run = getattr(self.obj, self.imethod_name)
        else:
            to_run = func

        for varname, modulename in self.global_modules.items():
            to_run.__globals__[varname] = __import__(modulename)
        if self.global_closure:
            to_run.__globals__.update(self.global_closure)
        if self.global_functions:
            to_run.__globals__.update(self.global_functions)
        return to_run