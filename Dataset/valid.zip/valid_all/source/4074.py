def update_placeholders(self, format_string, placeholders):
        """
        Update a format string renaming placeholders.
        """
        # Tokenize the format string and process them
        output = []
        for token in self.tokens(format_string):
            if token.group("key") in placeholders:
                output.append(
                    "{%s%s}" % (placeholders[token.group("key")], token.group("format"))
                )
                continue
            elif token.group("command"):
                # update any placeholders used in commands
                commands = parse_qsl(token.group("command"), keep_blank_values=True)
                # placeholders only used in `if`
                if "if" in [x[0] for x in commands]:
                    items = []
                    for key, value in commands:
                        if key == "if":
                            # we have to rebuild from the parts we have
                            condition = Condition(value)
                            variable = condition.variable
                            if variable in placeholders:
                                variable = placeholders[variable]
                                # negation via `!`
                                not_ = "!" if not condition.default else ""
                                condition_ = condition.condition or ""
                                # if there is no condition then there is no
                                # value
                                if condition_:
                                    value_ = condition.value
                                else:
                                    value_ = ""
                                value = "{}{}{}{}".format(
                                    not_, variable, condition_, value_
                                )
                        if value:
                            items.append("{}={}".format(key, value))
                        else:
                            items.append(key)

                    # we cannot use urlencode because it will escape things
                    # like `!`
                    output.append(r"\?{} ".format("&".join(items)))
                    continue
            value = token.group(0)
            output.append(value)
        return u"".join(output)