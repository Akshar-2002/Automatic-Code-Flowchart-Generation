def vn_info(call=None, kwargs=None):
    '''
    Retrieves information for the virtual network.

    .. versionadded:: 2016.3.0

    name
        The name of the virtual network for which to gather information. Can be
        used instead of ``vn_id``.

    vn_id
        The ID of the virtual network for which to gather information. Can be
        used instead of ``name``.

    CLI Example:

    .. code-block:: bash

        salt-cloud -f vn_info opennebula vn_id=3
        salt-cloud --function vn_info opennebula name=public
    '''
    if call != 'function':
        raise SaltCloudSystemExit(
            'The vn_info function must be called with -f or --function.'
        )

    if kwargs is None:
        kwargs = {}

    name = kwargs.get('name', None)
    vn_id = kwargs.get('vn_id', None)

    if vn_id:
        if name:
            log.warning(
                'Both the \'vn_id\' and \'name\' arguments were provided. '
                '\'vn_id\' will take precedence.'
            )
    elif name:
        vn_id = get_vn_id(kwargs={'name': name})
    else:
        raise SaltCloudSystemExit(
            'The vn_info function requires either a \'name\' or a \'vn_id\' '
            'to be provided.'
        )

    server, user, password = _get_xml_rpc()
    auth = ':'.join([user, password])
    response = server.one.vn.info(auth, int(vn_id))

    if response[0] is False:
        return response[1]
    else:
        info = {}
        tree = _get_xml(response[1])
        info[tree.find('NAME').text] = _xml_to_dict(tree)
        return info