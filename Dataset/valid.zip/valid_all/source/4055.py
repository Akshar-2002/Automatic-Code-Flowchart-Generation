def get_library_state_copy_instance(self, lib_os_path):
        """ A method to get a state copy of the library specified via the lib_os_path.

        :param lib_os_path: the location of the library to get a copy for
        :return:
        """

        # originally libraries were called like this; DO NOT DELETE; interesting for performance tests
        # state_machine = storage.load_state_machine_from_path(lib_os_path)
        # return state_machine.version, state_machine.root_state

        # TODO observe changes on file system and update data
        if lib_os_path in self._loaded_libraries:
            # this list can also be taken to open library state machines TODO -> implement it -> because faster
            state_machine = self._loaded_libraries[lib_os_path]
            # logger.info("Take copy of {0}".format(lib_os_path))
            # as long as the a library state root state is never edited so the state first has to be copied here
            state_copy = copy.deepcopy(state_machine.root_state)
            return state_machine.version, state_copy
        else:
            state_machine = storage.load_state_machine_from_path(lib_os_path)
            self._loaded_libraries[lib_os_path] = state_machine
            if config.global_config.get_config_value("NO_PROGRAMMATIC_CHANGE_OF_LIBRARY_STATES_PERFORMED", False):
                return state_machine.version, state_machine.root_state
            else:
                state_copy = copy.deepcopy(state_machine.root_state)
                return state_machine.version, state_copy