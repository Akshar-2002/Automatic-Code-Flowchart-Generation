def rss_create(channel, articles):
    """Create RSS xml feed.

    :param channel: channel info [title, link, description, language]
    :type channel: dict(str, str)
    :param articles: list of articles, an article is a dictionary with some \
    required fields [title, description, link] and any optional, which will \
    result to `<dict_key>dict_value</dict_key>`
    :type articles: list(dict(str,str))
    :return: root element
    :rtype: ElementTree.Element
    """
    channel = channel.copy()

    # TODO use deepcopy
    # list will not clone the dictionaries in the list and `elemen_from_dict`
    # pops items from them
    articles = list(articles)

    rss = ET.Element('rss')
    rss.set('version', '2.0')

    channel_node = ET.SubElement(rss, 'channel')

    element_from_dict(channel_node, channel, 'title')
    element_from_dict(channel_node, channel, 'link')
    element_from_dict(channel_node, channel, 'description')
    element_from_dict(channel_node, channel, 'language')

    for article in articles:
        item = ET.SubElement(channel_node, 'item')

        element_from_dict(item, article, 'title')
        element_from_dict(item, article, 'description')
        element_from_dict(item, article, 'link')

        for key in article:
            complex_el_from_dict(item, article, key)

    return ET.ElementTree(rss)