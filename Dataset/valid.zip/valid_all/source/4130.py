def set_config(self, **config):
        """Shadow all the current config."""
        reinit = False
        if 'stdopt' in config:
            stdopt = config.pop('stdopt')
            reinit = (stdopt != self.stdopt)
            self.stdopt = stdopt
        if 'attachopt' in config:
            attachopt = config.pop('attachopt')
            reinit = reinit or (attachopt != self.attachopt)
            self.attachopt = attachopt
        if 'attachvalue' in config:
            attachvalue = config.pop('attachvalue')
            reinit = reinit or (attachvalue != self.attachvalue)
            self.attachvalue = attachvalue
        if 'auto2dashes' in config:
            self.auto2dashes = config.pop('auto2dashes')
        if 'name' in config:
            name = config.pop('name')
            reinit = reinit or (name != self.name)
            self.name = name
        if 'help' in config:
            self.help = config.pop('help')
            self._set_or_remove_extra_handler(
                self.help, ('--help', '-h'), self.help_handler)
        if 'version' in config:
            self.version = config.pop('version')
            self._set_or_remove_extra_handler(
                self.version is not None,
                ('--version', '-v'),
                self.version_handler)
        if 'case_sensitive' in config:
            case_sensitive = config.pop('case_sensitive')
            reinit = reinit or (case_sensitive != self.case_sensitive)
            self.case_sensitive = case_sensitive
        if 'optionsfirst' in config:
            self.options_first = config.pop('optionsfirst')
        if 'appearedonly' in config:
            self.appeared_only = config.pop('appearedonly')
        if 'namedoptions' in config:
            namedoptions = config.pop('namedoptions')
            reinit = reinit or (namedoptions != self.namedoptions)
            self.namedoptions = namedoptions
        if 'extra' in config:
            self.extra.update(self._formal_extra(config.pop('extra')))

        if config:  # should be empty
            raise ValueError(
                '`%s` %s not accepted key argument%s' % (
                    '`, `'.join(config),
                    'is' if len(config) == 1 else 'are',
                    '' if len(config) == 1 else 's'
                ))

        if self.doc is not None and reinit:
            logger.warning(
                'You changed the config that requires re-initialized'
                ' `Docpie` object. Create a new one instead'
            )
            self._init()