def _compare_replication(current, desired, region, key, keyid, profile):
    '''
    Replication accepts a non-ARN role name, but always returns an ARN
    '''
    if desired is not None and desired.get('Role'):
        desired = copy.deepcopy(desired)
        desired['Role'] = _get_role_arn(desired['Role'],
                                 region=region, key=key, keyid=keyid, profile=profile)
    return __utils__['boto3.json_objs_equal'](current, desired)