def stopProducing(self):
        """
        Stop producing messages and disconnect from the server.
        Returns:
            Deferred: fired when the production is stopped.
        """
        _legacy_twisted_log.msg("Disconnecting from the AMQP broker")
        yield self.pauseProducing()
        yield self.close()
        self._consumers = {}
        self._channel = None