def get(self, sid):
        """
        Constructs a TaskChannelContext

        :param sid: The sid

        :returns: twilio.rest.taskrouter.v1.workspace.task_channel.TaskChannelContext
        :rtype: twilio.rest.taskrouter.v1.workspace.task_channel.TaskChannelContext
        """
        return TaskChannelContext(self._version, workspace_sid=self._solution['workspace_sid'], sid=sid, )