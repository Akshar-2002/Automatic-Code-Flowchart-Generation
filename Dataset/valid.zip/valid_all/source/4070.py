def urlunsplit (urlparts):
    """Same as urlparse.urlunsplit but with extra UNC path handling
    for Windows OS."""
    res = urlparse.urlunsplit(urlparts)
    if os.name == 'nt' and urlparts[0] == 'file' and '|' not in urlparts[2]:
        # UNC paths must have 4 slashes: 'file:////server/path'
        # Depending on the path in urlparts[2], urlparse.urlunsplit()
        # left only two or three slashes. This is fixed below
        repl = 'file://' if urlparts[2].startswith('//') else 'file:/'
        res = res.replace('file:', repl)
    return res