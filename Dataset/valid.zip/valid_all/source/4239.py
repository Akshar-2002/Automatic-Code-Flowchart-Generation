def _iop(self, operation, other, *allowed):
		"""An iterative operation operating on multiple values.
		
		Consumes iterators to construct a concrete list at time of execution.
		"""
		
		f = self._field
		
		if self._combining:  # We are a field-compound query fragment, e.g. (Foo.bar & Foo.baz).
			return reduce(self._combining,
					(q._iop(operation, other, *allowed) for q in f))  # pylint:disable=protected-access
		
		# Optimize this away in production; diagnosic aide.
		if __debug__ and _complex_safety_check(f, {operation} | set(allowed)):  # pragma: no cover
			raise NotImplementedError("{self!r} does not allow {op} comparison.".format(
					self=self, op=operation))
		
		def _t(o):
			for value in o:
				yield None if value is None else f.transformer.foreign(value, (f, self._document))
		
		other = other if len(other) > 1 else other[0]
		values = list(_t(other))
		
		return Filter({self._name: {operation: values}})