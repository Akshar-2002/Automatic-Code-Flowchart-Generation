def mission_request_partial_list_encode(self, target_system, target_component, start_index, end_index):
                '''
                Request a partial list of mission items from the system/component.
                http://qgroundcontrol.org/mavlink/waypoint_protocol.
                If start and end index are the same, just send one
                waypoint.

                target_system             : System ID (uint8_t)
                target_component          : Component ID (uint8_t)
                start_index               : Start index, 0 by default (int16_t)
                end_index                 : End index, -1 by default (-1: send list to end). Else a valid index of the list (int16_t)

                '''
                return MAVLink_mission_request_partial_list_message(target_system, target_component, start_index, end_index)