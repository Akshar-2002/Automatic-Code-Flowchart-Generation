def get_ascii(pid=None, name=None, pokemons=None, return_pokemons=False, message=None):
    '''get_ascii will return ascii art for a pokemon based on a name or pid.
    :param pid: the pokemon ID to return
    :param name: the pokemon name to return
    :param return_pokemons: return catches (default False)
    :param message: add a message to the ascii
    '''
    pokemon = get_pokemon(name=name,pid=pid,pokemons=pokemons)
    printme = message
    if len(pokemon) > 0:
        for pid,data in pokemon.items():
            if message == None:
                printme = data["name"].capitalize()
            print("%s\n\n%s" % (data['ascii'],printme))
          
    if return_pokemons == True:
        return pokemon