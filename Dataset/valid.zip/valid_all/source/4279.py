def temporal_firing_rate(self,time_dimension=0,resolution=1.0,units=None,
                             min_t=None,max_t=None,weight_function=None,normalize_time=False,
                             normalize_n=False,start_units_with_0=True,cell_dimension='N'):
        """
            Outputs a time histogram of spikes.

            `bins`: number of bins (default is 1ms bins from 0 to t_max)
            `weight_function`: if set, computes a weighted histogram, dependent on the (index, time) tuples of each spike

                    weight_function = lambda x: weight_map.flatten()[array(x[:,0],dtype=int)]

            `normalize_time`
            `normalize_n`:  normalize by the length of time (such that normal output is Hz) and/or number of units (such that output is Hz/unit, determined with unique values in cell_dimension)
                            Generally does not make sense when using a weight_function other than 'count'.

            `start_units_with_0`: starts indizes from 0 instead from the actual index
        """
        units = self._default_units(units)
        if self.data_format == 'spike_times':
            converted_dimension,st = self.spike_times.get_converted(0,units)
            if min_t is None:
                min_t = converted_dimension.min
            if max_t is None:
                max_t = converted_dimension.max
            st = st[(st>=min_t)*(st<max_t)]
            bins = converted_dimension.linspace_by_resolution(resolution,end_at_end=True,extra_bins=0)
            H,edg = np.histogram(st,bins=bins)
            if normalize_time:
                H = H/(convert_time(resolution,from_units=units,to_units='s')) # make it Hertz
            if normalize_n:
                H = H/(len(np.unique(self.spike_times[cell_dimension])))
            return H,edg