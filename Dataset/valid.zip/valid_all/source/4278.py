def update_instance_extent(self, instance, module, operation):
        """Updates a new instance that was added to a module to be complete
        if the end token is present in any remaining, overlapping operations.
        """
        #Essentially, we want to look in the rest of the statements that are
        #part of the current operation to see how many more of them pertain 
        #to the new instance that was added.

        #New signatures only result in instances being added if mode is "insert"
        #or "replace". In both cases, the important code is in the buffered
        #statements, *not* the cached version. Iterate the remaining statements
        #in the buffer and look for the end_token for the instance. If we don't
        #find it, check for overlap between the operations' index specifiers.
        instance.end -= operation.curlength
        end_token = instance.end_token
        (ibuffer, length) = self._find_end_token(end_token, operation)
        cum_length = length
        
        opstack = [operation]
        while ibuffer is None and opstack[-1].index + 1 < len(self._operations):
            #We didn't find a natural termination to the new instance. Look for
            #overlap in the operations
            noperation = self._operations[opstack[-1].index + 1]
            #We only want to check the next operation if it is a neighbor
            #in line numbers in the buffer.
            if noperation.ibuffer[0] - opstack[-1].ibuffer[1] == 1:
                (ibuffer, length) = self._find_end_token(end_token, noperation)
                cum_length += length
                opstack.append(noperation)
            else:
                break
            
        if ibuffer is not None:
            instance.incomplete = False
            instance.end += cum_length
            for op in opstack:
                op.bar_extent = True
                op.set_element(instance)
        else:
            #We set the element for the current operation to be the new instance
            #for the rest of statements in its set.
            operation.set_element(instance)