def setup_ui(self, ):
        """Setup the ui

        :returns: None
        :rtype: None
        :raises: None
        """
        labels = self.reftrack.get_option_labels()
        self.browser = ComboBoxBrowser(len(labels), headers=labels)
        self.browser_vbox.addWidget(self.browser)