def static_uint8_variable_for_data(variable_name, data, max_line_length=120, comment="", indent=2):
    r"""
    >>> static_uint8_variable_for_data("v", "abc")
    'static uint8_t v[3] = {\n  0x61, 0x62, 0x63,\n}; // v'
    >>> static_uint8_variable_for_data("v", "abc", comment="hi")
    'static uint8_t v[3] = { // hi\n  0x61, 0x62, 0x63,\n}; // v'
    >>> static_uint8_variable_for_data("v", "abc", indent=4)
    'static uint8_t v[3] = {\n    0x61, 0x62, 0x63,\n}; // v'
    >>> static_uint8_variable_for_data("v", "abcabcabcabc", max_line_length=20)
    'static uint8_t v[12] = {\n  0x61, 0x62, 0x63,\n  0x61, 0x62, 0x63,\n  0x61, 0x62, 0x63,\n  0x61, 0x62, 0x63,\n}; // v'
    """
    hex_components = []
    for byte in data:
        byte_as_hex = "0x{u:02X}".format(u=ord(byte))
        hex_components.append(byte_as_hex)

    chunk_size = (max_line_length - indent + 2 - 1) // 6  # 6 is len("0xAA, "); +2 for the last element's ", "; -1 for the trailing comma

    array_lines = []
    for chunk_offset in xrange(0, len(hex_components), chunk_size):
        chunk = hex_components[chunk_offset:chunk_offset + chunk_size]
        array_lines.append(" " * indent + ", ".join(chunk) + ",")

    array_data = "\n".join(array_lines)

    if comment != "":
        comment = " // " + comment

    substitutions = {"v": variable_name,
                     "l": len(hex_components),
                     "d": array_data,
                     "c": comment}
    declaration = "static uint8_t {v}[{l}] = {{{c}\n{d}\n}}; // {v}".format(**substitutions)
    return declaration