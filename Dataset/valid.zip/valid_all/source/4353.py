def resource_show(resource_id, extra_args=None, cibfile=None):
    '''
    Show a resource via pcs command

    resource_id
        name of the resource
    extra_args
        additional options for the pcs command
    cibfile
        use cibfile instead of the live CIB

    CLI Example:

    .. code-block:: bash

        salt '*' pcs.resource_show resource_id='galera' cibfile='/tmp/cib_for_galera.cib'
    '''
    return item_show(item='resource', item_id=resource_id, extra_args=extra_args, cibfile=cibfile)