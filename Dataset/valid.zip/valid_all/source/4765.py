def validate(self, value):
        """
        Accepts: str, unicode, bool
        Returns: bool
        """
        if isinstance(value, bool):
            return value
        if isinstance(value, (str, unicode)):
            if value.lower() == "true":
                value = True
            elif value.lower() == "false":
                value = False
            else:
                raise ValueError("Not a boolean: %r" % (value, ))
        value = super(Boolean, self).validate(value)
        if not isinstance(value, bool):
            raise ValueError("Not a boolean: %r" % (value, ))
        return value