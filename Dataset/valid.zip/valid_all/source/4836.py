def check_api_version(self):
        """
        Self check that the client expects the api version used by the
        server. /status/ is available without authentication so it
        will not interfere with hello.
        """
        url = self.base_url + "/status/"
        juicer.utils.Log.log_debug("[REST:GET:%s]", url)

        _r = requests.get(url, auth=self.auth, headers=self.headers,
                          verify=False)

        if _r.status_code == Constants.PULP_GET_OK:  # server is up, cool.
            version = juicer.utils.load_json_str(_r.content)['api_version'].strip()
            if version != Constants.EXPECTED_SERVER_VERSION:  # we done goofed
                raise JuicerPulpError("Client expects %s and got %s -- you should probably update!" \
                                      % (Constants.EXPECTED_SERVER_VERSION, version))
        return True