def minimum_multivariate_ess(nmr_params, alpha=0.05, epsilon=0.05):
    r"""Calculate the minimum multivariate Effective Sample Size you will need to obtain the desired precision.

    This implements the inequality from Vats et al. (2016):

    .. math::

        \widehat{ESS} \geq \frac{2^{2/p}\pi}{(p\Gamma(p/2))^{2/p}} \frac{\chi^{2}_{1-\alpha,p}}{\epsilon^{2}}

    Where :math:`p` is the number of free parameters.

    Args:
        nmr_params (int): the number of free parameters in the model
        alpha (float): the level of confidence of the confidence region. For example, an alpha of 0.05 means
            that we want to be in a 95% confidence region.
        epsilon (float): the level of precision in our multivariate ESS estimate.
            An epsilon of 0.05 means that we expect that the Monte Carlo error is 5% of the uncertainty in
            the target distribution.

    Returns:
        float: the minimum multivariate Effective Sample Size that one should aim for in MCMC sample to
            obtain the desired confidence region with the desired precision.

    References:
        Vats D, Flegal J, Jones G (2016). Multivariate Output Analysis for Markov Chain Monte Carlo.
        arXiv:1512.07713v2 [math.ST]
    """
    tmp = 2.0 / nmr_params
    log_min_ess = tmp * np.log(2) + np.log(np.pi) - tmp * (np.log(nmr_params) + gammaln(nmr_params / 2)) \
                  + np.log(chi2.ppf(1 - alpha, nmr_params)) - 2 * np.log(epsilon)
    return int(round(np.exp(log_min_ess)))