def add_package(
    self, target=None, package_manager=None, 
    package=None, type_option=None, version_option=None,
    node_paths=None, workunit_name=None, workunit_labels=None):
    """Add an additional package using requested package_manager."""
    package_manager = package_manager or self.get_package_manager(target=target)
    command = package_manager.add_package(
      package,
      type_option=type_option,
      version_option=version_option,
      node_paths=node_paths,
    )
    return self._execute_command(
      command, workunit_name=workunit_name, workunit_labels=workunit_labels)