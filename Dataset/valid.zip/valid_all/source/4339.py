def do_raise(self, arg):
        """Raise the last exception caught."""
        self.do_continue(arg)

        # Annotating the exception for a continual re-raise
        _, exc_value, _ = self.exc_info
        exc_value._ipdbugger_let_raise = True

        raise_(*self.exc_info)