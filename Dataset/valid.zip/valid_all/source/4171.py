def edit(self, name, color, description=github.GithubObject.NotSet):
        """
        :calls: `PATCH /repos/:owner/:repo/labels/:name <http://developer.github.com/v3/issues/labels>`_
        :param name: string
        :param color: string
        :param description: string
        :rtype: None
        """
        assert isinstance(name, (str, unicode)), name
        assert isinstance(color, (str, unicode)), color
        assert description is github.GithubObject.NotSet or isinstance(description, (str, unicode)), description
        post_parameters = {
            "name": name,
            "color": color,
        }
        if description is not github.GithubObject.NotSet:
            post_parameters["description"] = description
        headers, data = self._requester.requestJsonAndCheck(
            "PATCH",
            self.url,
            input=post_parameters,
            headers={'Accept': Consts.mediaTypeLabelDescriptionSearchPreview}
        )
        self._useAttributes(data)