def _set_usb(self, v, load=False):
    """
    Setter method for usb, mapped from YANG variable /brocade_firmware_rpc/firmware_download/input/usb (container)
    If this variable is read-only (config: false) in the
    source YANG file, then _set_usb is considered as a private
    method. Backends looking to populate this variable should
    do so via calling thisObj._set_usb() directly.
    """
    if hasattr(v, "_utype"):
      v = v._utype(v)
    try:
      t = YANGDynClass(v,base=usb.usb, is_container='container', presence=False, yang_name="usb", rest_name="usb", parent=self, choice=(u'protocol-type', u'usb-protocol'), path_helper=self._path_helper, extmethods=self._extmethods, register_paths=False, extensions=None, namespace='urn:brocade.com:mgmt:brocade-firmware', defining_module='brocade-firmware', yang_type='container', is_config=True)
    except (TypeError, ValueError):
      raise ValueError({
          'error-string': """usb must be of a type compatible with container""",
          'defined-type': "container",
          'generated-type': """YANGDynClass(base=usb.usb, is_container='container', presence=False, yang_name="usb", rest_name="usb", parent=self, choice=(u'protocol-type', u'usb-protocol'), path_helper=self._path_helper, extmethods=self._extmethods, register_paths=False, extensions=None, namespace='urn:brocade.com:mgmt:brocade-firmware', defining_module='brocade-firmware', yang_type='container', is_config=True)""",
        })

    self.__usb = t
    if hasattr(self, '_set'):
      self._set()