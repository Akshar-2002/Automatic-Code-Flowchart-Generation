def search_user(self, user_name, quiet=False, limit=9):
        """Search user by user name.

        :params user_name: user name.
        :params quiet: automatically select the best one.
        :params limit: user count returned by weapi.
        :return: a User object.
        """

        result = self.search(user_name, search_type=1002, limit=limit)

        if result['result']['userprofileCount'] <= 0:
            LOG.warning('User %s not existed!', user_name)
            raise SearchNotFound('user {} not existed'.format(user_name))
        else:
            users = result['result']['userprofiles']
            if quiet:
                user_id, user_name = users[0]['userId'], users[0]['nickname']
                user = User(user_id, user_name)
                return user
            else:
                return self.display.select_one_user(users)