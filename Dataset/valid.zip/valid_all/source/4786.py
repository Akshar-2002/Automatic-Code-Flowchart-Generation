def benchmark_forward(self):
        """Benchmark forward execution.
        """
        self._setup()

        def f():
            self._forward()
            self.mod_ext.synchronize(**self.ext_kwargs)
        f()  # Ignore first
        self.forward_stat = self._calc_benchmark_stat(f)