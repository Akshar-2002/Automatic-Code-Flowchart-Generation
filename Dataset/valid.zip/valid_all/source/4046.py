def save(self):
        '''
        Save an instance of a Union object
        '''
        client = self._new_api_client()
        params = {'id': self.id} if hasattr(self, 'id') else {}
        action =  'patch' if hasattr(self, 'id') else 'post'
        saved_model = client.make_request(self, action, url_params=params, post_data=self._to_json)
        self.__init__(**saved_model._to_dict)