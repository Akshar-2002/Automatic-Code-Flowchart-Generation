def receivetime_delay(self, tid, days, session):
        '''taobao.trade.receivetime.delay 延长交易收货时间
        
        延长交易收货时间'''
        request = TOPRequest('taobao.trade.receivetime.delay')
        request['tid'] = tid
        request['days'] = days
        self.create(self.execute(request, session)['trade'])
        return self