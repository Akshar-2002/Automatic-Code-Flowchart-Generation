def add_pool(arg, opts, shell_opts):
    """ Add a pool.
    """

    p = Pool()
    p.name = opts.get('name')
    p.description = opts.get('description')
    p.default_type = opts.get('default-type')
    p.ipv4_default_prefix_length = opts.get('ipv4_default_prefix_length')
    p.ipv6_default_prefix_length = opts.get('ipv6_default_prefix_length')

    if 'tags' in opts:
        tags = list(csv.reader([opts.get('tags', '')], escapechar='\\'))[0]
        p.tags = {}
        for tag_name in tags:
            tag = Tag()
            tag.name = tag_name
            p.tags[tag_name] = tag

    for avp in opts.get('extra-attribute', []):
        try:
            key, value = avp.split('=', 1)
        except ValueError:
            print("ERROR: Incorrect extra-attribute: %s. Accepted form: 'key=value'\n" % avp, file=sys.stderr)
            return
        p.avps[key] = value

    try:
        p.save()
    except pynipap.NipapError as exc:
        print("Could not add pool to NIPAP: %s" % str(exc), file=sys.stderr)
        sys.exit(1)

    print("Pool '%s' created." % (p.name))