def extract_named_group(text, named_group, matchers, return_presence=False):
    ''' Return ``named_group`` match from ``text`` reached
        by using a matcher from ``matchers``.

        It also supports matching without a ``named_group`` in a matcher,
        which sets ``presence=True``.

        ``presence`` is only returned if ``return_presence=True``.

    '''
    presence = False

    for matcher in matchers:
        if isinstance(matcher, str):
            v = re.search(matcher, text, flags=re.DOTALL)
            if v:
                dict_result = v.groupdict()
                try:
                    return dict_result[named_group]
                except KeyError:
                    if dict_result:
                        # It's other named group matching, discard
                        continue
                    else:
                        # It's a matcher without named_group
                        # but we can't return it until every matcher pass
                        # because a following matcher could have a named group
                        presence = True
        elif callable(matcher):
            v = matcher(text)
            if v:
                return v

    if return_presence and presence:
        return 'presence'

    return None