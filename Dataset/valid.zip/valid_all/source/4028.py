def resize(self, logical_size):
        """Starts resizing this medium. This means that the nominal size of the
        medium is set to the new value. Both increasing and decreasing the
        size is possible, and there are no safety checks, since VirtualBox
        does not make any assumptions about the medium contents.
        
        Resizing usually needs additional disk space, and possibly also
        some temporary disk space. Note that resize does not create a full
        temporary copy of the medium, so the additional disk space requirement
        is usually much lower than using the clone operation.
        
        This medium will be placed to :py:attr:`MediumState.locked_write` 
        state for the duration of this operation.
        
        Please note that the results can be either returned straight away,
        or later as the result of the background operation via the object
        returned via the @a progress parameter.

        in logical_size of type int
            New nominal capacity of the medium in bytes.

        return progress of type :class:`IProgress`
            Progress object to track the operation completion.

        raises :class:`VBoxErrorNotSupported`
            Medium format does not support resizing.
        
        """
        if not isinstance(logical_size, baseinteger):
            raise TypeError("logical_size can only be an instance of type baseinteger")
        progress = self._call("resize",
                     in_p=[logical_size])
        progress = IProgress(progress)
        return progress