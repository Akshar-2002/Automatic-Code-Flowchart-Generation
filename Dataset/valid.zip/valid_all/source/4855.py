def _delete(self, _file_path, _method_title, _record_key):

        '''
            a helper method for non-blocking deletion of files
            
        :param _file_path: string with path to file to remove 
        :param _method_title: string with name of method calling _delete
        :param _record_key: string with name of record key to delete
        :return: None
        '''

        import os
        from time import sleep

        current_dir = os.path.split(_file_path)[0]
        count = 0
        retry_count = 10
        while True:
            try:
                os.remove(_file_path)
                while current_dir != self.collection_folder:
                    if not os.listdir(current_dir):
                        os.rmdir(current_dir)
                        current_dir = os.path.split(current_dir)[0]
                    else:
                        break
                break
            except PermissionError:
                sleep(.05)
                count += 1
                if count > retry_count:
                    raise Exception('%s failed to delete %s' % (_method_title, _record_key))

        os._exit(0)