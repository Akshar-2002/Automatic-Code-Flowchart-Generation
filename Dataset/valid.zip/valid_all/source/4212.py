def transport_jsonrpc(self):
        """
        Installs the JSON-RPC transport bundles and instantiates components
        """
        # Install the bundle
        self.context.install_bundle("pelix.remote.json_rpc").start()

        with use_waiting_list(self.context) as ipopo:
            # Instantiate the discovery
            ipopo.add(
                rs.FACTORY_TRANSPORT_JSONRPC_EXPORTER, "pelix-jsonrpc-exporter"
            )
            ipopo.add(
                rs.FACTORY_TRANSPORT_JSONRPC_IMPORTER, "pelix-jsonrpc-importer"
            )