def add_word(self, word, value):
		"""
		Adds word and associated value.

		If word already exists, its value is replaced.
		"""
		if not word:
			return

		node = self.root
		for c in word:
			try:
				node = node.children[c]
			except KeyError:
				n = TrieNode(c)
				node.children[c] = n
				node = n

		node.output = value