def set_level(self, val):
        """Set the device ON LEVEL."""
        if val == 0:
            self.off()
        elif val == 255:
            self.on()
        else:
            setlevel = 255
            if val < 1:
                setlevel = val * 255
            elif val <= 0xff:
                setlevel = val
            change = setlevel - self._value
            increment = 255 / self._steps
            steps = round(abs(change) / increment)
            print('Steps: ', steps)
            if change > 0:
                method = self.brighten
                self._value += round(steps * increment)
                self._value = min(255, self._value)
            else:
                method = self.dim
                self._value -= round(steps * increment)
                self._value = max(0, self._value)
            # pylint: disable=unused-variable
            for step in range(0, steps):
                method(True)
            self._update_subscribers(self._value)