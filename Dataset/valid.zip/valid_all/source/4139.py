def get_all(self):
        """
        Gets all component references registered in this reference map.

        :return: a list with component references.
        """
        components = []
        
        self._lock.acquire()
        try:
            for reference in self._references:
                components.append(reference.get_component())
        finally:
            self._lock.release()

        return components