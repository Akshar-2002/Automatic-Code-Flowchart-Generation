def get_occurrence_times_for_event(event):
    """
    Return a tuple with two sets containing the (start, end) *naive* datetimes
    of an Event's Occurrences, or the original start datetime if an
    Occurrence's start was modified by a user.
    """
    occurrences_starts = set()
    occurrences_ends = set()
    for o in event.occurrence_list:
        occurrences_starts.add(
            coerce_naive(o.original_start or o.start)
        )
        occurrences_ends.add(
            coerce_naive(o.original_end or o.end)
        )
    return occurrences_starts, occurrences_ends