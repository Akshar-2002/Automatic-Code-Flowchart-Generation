def glue(self, pos):
        """Calculates the distance between the given position and the port

        :param (float, float) pos: Distance to this position is calculated
        :return: Distance to port
        :rtype: float
        """
        # Distance between border of rectangle and point
        # Equation from http://stackoverflow.com/a/18157551/3568069
        dx = max(self.point.x - self.width / 2. - pos[0], 0, pos[0] - (self.point.x + self.width / 2.))
        dy = max(self.point.y - self.height / 2. - pos[1], 0, pos[1] - (self.point.y + self.height / 2.))
        dist = sqrt(dx*dx + dy*dy)
        return self.point, dist