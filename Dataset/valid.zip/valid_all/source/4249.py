def get_by_name(self, name, style_type = None):
        """Find style by it's descriptive name.

        :Returns:
          Returns found style of type :class:`ooxml.doc.Style`.
        """
        for st in self.styles.values():
            if st:
                if st.name == name:
                    return st

        if style_type and not st:
            st = self.styles.get(self.default_styles[style_type], None)            
        return st