def draw_polygon(
            self,
            *pts,
            close_path=True,
            stroke=None,
            stroke_width=1,
            stroke_dash=None,
            fill=None
            ) -> None:
        """Draws the given polygon."""
        c = self.c
        c.saveState()

        if stroke is not None:
            c.setStrokeColorRGB(*stroke)
            c.setLineWidth(stroke_width)
            c.setDash(stroke_dash)
        if fill is not None:
            c.setFillColorRGB(*fill)

        p = c.beginPath()
        fn = p.moveTo
        for x,y in zip(*[iter(pts)]*2):
            fn(x, y)
            fn = p.lineTo
        if close_path:
            p.close()

        c.drawPath(p, stroke=(stroke is not None), fill=(fill is not None))
        c.restoreState()