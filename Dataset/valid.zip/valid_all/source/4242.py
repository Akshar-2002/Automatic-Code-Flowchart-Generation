def _add_dominance_relation(self, source, target):
        """add a dominance relation to this docgraph"""
        # TODO: fix #39, so we don't need to add nodes by hand
        self.add_node(target, layers={self.ns, self.ns+':unit'})
        self.add_edge(source, target,
                      layers={self.ns, self.ns+':discourse'},
                      edge_type=EdgeTypes.dominance_relation)