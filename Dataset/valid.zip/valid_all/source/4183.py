def duplicate(self):
        """Duplicates the matcher to others."""
        other = Matcher(self.loc, self.check_var, self.checkdefs, self.names, self.var_index)
        other.insert_check(0, "not " + self.check_var)
        self.others.append(other)
        return other