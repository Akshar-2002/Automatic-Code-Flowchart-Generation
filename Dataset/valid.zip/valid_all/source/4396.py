def _file_read(path):
    '''
    Read a file and return content
    '''
    content = False
    if os.path.exists(path):
        with salt.utils.files.fopen(path, 'r+') as fp_:
            content = salt.utils.stringutils.to_unicode(fp_.read())
        fp_.close()
    return content