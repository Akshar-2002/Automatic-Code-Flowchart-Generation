def page_for_in(self, leaderboard_name, member,
                    page_size=DEFAULT_PAGE_SIZE):
        '''
        Determine the page where a member falls in the named leaderboard.

        @param leaderboard [String] Name of the leaderboard.
        @param member [String] Member name.
        @param page_size [int] Page size to be used in determining page location.
        @return the page where a member falls in the leaderboard.
        '''
        rank_for_member = None
        if self.order == self.ASC:
            rank_for_member = self.redis_connection.zrank(
                leaderboard_name,
                member)
        else:
            rank_for_member = self.redis_connection.zrevrank(
                leaderboard_name,
                member)

        if rank_for_member is None:
            rank_for_member = 0
        else:
            rank_for_member += 1

        return int(math.ceil(float(rank_for_member) / float(page_size)))