def yaml_force_unicode():
        """
        Force pyyaml to return unicode values.
        """
        #/
        ## modified from |http://stackoverflow.com/a/2967461|
        if sys.version_info[0] == 2:
            def construct_func(self, node):
                return self.construct_scalar(node)
            yaml.Loader.add_constructor(U('tag:yaml.org,2002:str'), construct_func)
            yaml.SafeLoader.add_constructor(U('tag:yaml.org,2002:str'), construct_func)