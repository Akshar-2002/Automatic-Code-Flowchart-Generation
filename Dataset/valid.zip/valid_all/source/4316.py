def __vciFormatError(library_instance, function, HRESULT):
    """ Format a VCI error and attach failed function and decoded HRESULT
        :param CLibrary library_instance:
            Mapped instance of IXXAT vcinpl library
        :param callable function:
            Failed function
        :param HRESULT HRESULT:
            HRESULT returned by vcinpl call
        :return:
            Formatted string
    """
    buf = ctypes.create_string_buffer(constants.VCI_MAX_ERRSTRLEN)
    ctypes.memset(buf, 0, constants.VCI_MAX_ERRSTRLEN)
    library_instance.vciFormatError(HRESULT, buf, constants.VCI_MAX_ERRSTRLEN)
    return "function {} failed ({})".format(function._name, buf.value.decode('utf-8', 'replace'))