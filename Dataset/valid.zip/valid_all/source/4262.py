def list(self, **kwargs):
        """ https://api.slack.com/methods/groups.list
        """
        if kwargs:
            self.params.update(kwargs)
        return FromUrl('https://slack.com/api/groups.list', self._requests)(data=self.params).get()