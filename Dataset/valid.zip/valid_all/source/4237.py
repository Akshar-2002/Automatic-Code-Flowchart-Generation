def update(self, new_data: Dict[Text, Dict[Text, Text]]):
        """
        Receive an update from a loader.

        :param new_data: New translation data from the loader
        """

        for locale, data in new_data.items():
            if locale not in self.dict:
                self.dict[locale] = {}

            self.dict[locale].update(data)