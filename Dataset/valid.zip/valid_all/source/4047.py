def WriteUInt256(self, value):
        """
        Write a UInt256 type to the stream.

        Args:
            value (UInt256):

        Raises:
            Exception: when `value` is not of neocore.UInt256 type.
        """
        if type(value) is UInt256:
            value.Serialize(self)
        else:
            raise Exception("Cannot write value that is not UInt256")