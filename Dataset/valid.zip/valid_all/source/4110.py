def get_composition(self, composition_id):
        """Gets the ``Composition`` specified by its ``Id``.

        arg:    composition_id (osid.id.Id): ``Id`` of the
                ``Composiiton``
        return: (osid.repository.Composition) - the composition
        raise:  NotFound - ``composition_id`` not found
        raise:  NullArgument - ``composition_id`` is ``null``
        raise:  OperationFailed - unable to complete request
        raise:  PermissionDenied - authorization failure
        *compliance: mandatory -- This method is must be implemented.*

        """
        # Implemented from template for
        # osid.resource.ResourceLookupSession.get_resource
        # NOTE: This implementation currently ignores plenary view
        collection = JSONClientValidated('repository',
                                         collection='Composition',
                                         runtime=self._runtime)
        result = collection.find_one(
            dict({'_id': ObjectId(self._get_id(composition_id, 'repository').get_identifier())},
                 **self._view_filter()))
        return objects.Composition(osid_object_map=result, runtime=self._runtime, proxy=self._proxy)