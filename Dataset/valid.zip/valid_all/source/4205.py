def backendStatus(self, *args, **kwargs):
        """
        Backend Status

        This endpoint is used to show when the last time the provisioner
        has checked in.  A check in is done through the deadman's snitch
        api.  It is done at the conclusion of a provisioning iteration
        and used to tell if the background provisioning process is still
        running.

        **Warning** this api end-point is **not stable**.

        This method gives output: ``http://schemas.taskcluster.net/aws-provisioner/v1/backend-status-response.json#``

        This method is ``experimental``
        """

        return self._makeApiCall(self.funcinfo["backendStatus"], *args, **kwargs)