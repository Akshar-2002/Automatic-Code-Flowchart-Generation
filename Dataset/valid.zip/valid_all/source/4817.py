def add_property(self, prop, objects=()):
        """Add a property to the definition and add ``objects`` as related."""
        self._properties.add(prop)
        self._objects |= objects
        self._pairs.update((o, prop) for o in objects)