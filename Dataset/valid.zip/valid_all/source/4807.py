def strptime(cls, date_string, fmt):
        """
        This is opposite of the :py:meth:`khayyam.JalaliDate.strftime`,
        and used to parse date strings into date object.

        `ValueError` is raised if the date_string and format can’t be
        parsed by time.strptime() or if it returns a value which isn’t a time tuple. For a
        complete list of formatting directives, see :doc:`/directives`.


        :param date_string:
        :param fmt:
        :return: A :py:class:`khayyam.JalaliDate` corresponding to date_string, parsed according to format
        :rtype: :py:class:`khayyam.JalaiDate`
        """
        # noinspection PyUnresolvedReferences
        result = cls.formatterfactory(fmt).parse(date_string)
        result = {k: v for k, v in result.items() if k in ('year', 'month', 'day')}
        return cls(**result)