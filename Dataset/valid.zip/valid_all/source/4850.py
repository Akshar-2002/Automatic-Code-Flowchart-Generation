def create_media_assetfile(access_token, parent_asset_id, name, is_primary="false", \
is_encrypted="false", encryption_scheme="None", encryptionkey_id="None"):
    '''Create Media Service Asset File.

    Args:
        access_token (str): A valid Azure authentication token.
        parent_asset_id (str): Media Service Parent Asset ID.
        name (str): Media Service Asset Name.
        is_primary (str): Media Service Primary Flag.
        is_encrypted (str): Media Service Encryption Flag.
        encryption_scheme (str): Media Service Encryption Scheme.
        encryptionkey_id (str): Media Service Encryption Key ID.

    Returns:
        HTTP response. JSON body.
    '''
    path = '/Files'
    endpoint = ''.join([ams_rest_endpoint, path])
    if encryption_scheme == "StorageEncryption":
        body = '{ \
			"IsEncrypted": "' + is_encrypted + '", \
			"EncryptionScheme": "' + encryption_scheme + '", \
			"EncryptionVersion": "' + "1.0" + '", \
			"EncryptionKeyId": "' + encryptionkey_id + '", \
			"IsPrimary": "' + is_primary + '", \
			"MimeType": "video/mp4", \
			"Name": "' + name + '", \
			"ParentAssetId": "' + parent_asset_id + '" \
		}'
    else:
        body = '{ \
			"IsPrimary": "' + is_primary + '", \
			"MimeType": "video/mp4", \
			"Name": "' + name + '", \
			"ParentAssetId": "' + parent_asset_id + '" \
		}'
    return do_ams_post(endpoint, path, body, access_token)