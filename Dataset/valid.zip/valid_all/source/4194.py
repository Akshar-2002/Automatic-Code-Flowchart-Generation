def batting_avg(self, benchmark):
        """Percentage of periods when `self` outperformed `benchmark`.

        Parameters
        ----------
        benchmark : {pd.Series, TSeries, 1d np.ndarray}
            The benchmark security to which `self` is compared.

        Returns
        -------
        float
        """

        diff = self.excess_ret(benchmark)
        return np.count_nonzero(diff > 0.0) / diff.count()