def pi_zoom_origin(self, viewer, event, msg=True):
        """Like pi_zoom(), but pans the image as well to keep the
        coordinate under the cursor in that same position relative
        to the window.
        """
        origin = (event.data_x, event.data_y)
        return self._pinch_zoom_rotate(viewer, event.state, event.rot_deg,
                                       event.scale, msg=msg, origin=origin)