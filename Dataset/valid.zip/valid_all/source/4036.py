def class_name(self) -> str:
        """
        Makes the fist letter big, keep the rest of the camelCaseApiName.
        """
        if not self.api_name:  # empty string
            return self.api_name
        # end if
        return self.api_name[0].upper() + self.api_name[1:]