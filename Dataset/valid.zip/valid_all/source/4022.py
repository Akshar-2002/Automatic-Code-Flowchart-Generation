def vote_up_idea(self, *args, **kwargs):
        """ :allowed_param: 'ideaId', 'myVote' (optional)
        """
        kwargs.update({'headers': {'content-type':'application/json'}})
        return bind_api(
            api=self,
            path='/ideas/{ideaId}/vote/up',
            method='POST',
            payload_type='vote',
            allowed_param=['ideaId'],
            post_param=['myVote']
        )(*args, **kwargs)