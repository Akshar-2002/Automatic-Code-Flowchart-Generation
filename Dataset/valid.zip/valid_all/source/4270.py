def lyap_e_len(**kwargs):
  """
  Helper function that calculates the minimum number of data points required
  to use lyap_e.

  Note that none of the required parameters may be set to None.

  Kwargs:
    kwargs(dict):
      arguments used for lyap_e (required: emb_dim, matrix_dim, min_nb
      and min_tsep)

  Returns:
    minimum number of data points required to call lyap_e with the given
    parameters
  """
  m = (kwargs['emb_dim'] - 1) // (kwargs['matrix_dim'] - 1)
  # minimum length required to find single orbit vector
  min_len = kwargs['emb_dim']
  # we need to follow each starting point of an orbit vector for m more steps
  min_len += m
  # we need min_tsep * 2 + 1 orbit vectors to find neighbors for each
  min_len += kwargs['min_tsep'] * 2
  # we need at least min_nb neighbors for each orbit vector
  min_len += kwargs['min_nb']
  return min_len