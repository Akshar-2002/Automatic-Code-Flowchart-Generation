def generate_ulid_as_uuid(timestamp=None, monotonic=False):
    """
    Generate an ULID, but expressed as an UUID.

    :param timestamp: An optional timestamp override.
                      If `None`, the current time is used.
    :type timestamp: int|float|datetime.datetime|None
    :param monotonic: Attempt to ensure ULIDs are monotonically increasing.
                      Monotonic behavior is not guaranteed when used from multiple threads.
    :type monotonic: bool
    :return: UUID containing ULID data.
    :rtype: uuid.UUID
    """
    return uuid.UUID(bytes=generate_binary_ulid(timestamp, monotonic=monotonic))