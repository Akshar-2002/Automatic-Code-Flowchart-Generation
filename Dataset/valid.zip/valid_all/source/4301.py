def upgrade():
    """Upgrade database."""
    op.create_index(op.f('ix_access_actionsroles_role_id'),
                    'access_actionsroles', ['role_id'], unique=False)
    op.drop_constraint(u'fk_access_actionsroles_role_id_accounts_role',
                       'access_actionsroles', type_='foreignkey')
    op.create_foreign_key(op.f('fk_access_actionsroles_role_id_accounts_role'),
                          'access_actionsroles', 'accounts_role', ['role_id'],
                          ['id'], ondelete='CASCADE')
    op.create_index(op.f('ix_access_actionsusers_user_id'),
                    'access_actionsusers', ['user_id'], unique=False)
    op.drop_constraint(u'fk_access_actionsusers_user_id_accounts_user',
                       'access_actionsusers', type_='foreignkey')
    op.create_foreign_key(op.f('fk_access_actionsusers_user_id_accounts_user'),
                          'access_actionsusers', 'accounts_user', ['user_id'],
                          ['id'], ondelete='CASCADE')