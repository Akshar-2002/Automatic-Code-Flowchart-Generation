def _resolved_objects(pdf, xobject):
        """Retrieve rotatation info."""
        return [pdf.getPage(i).get(xobject) for i in range(pdf.getNumPages())][0]