def fileName(self):
        """
        Returns the filename.
        
        :return     <str>
        """
        if self._filename:
            return self._filename
        
        filename = nativestring(super(XSettings, self).fileName())
        if self._customFormat:
            filename, ext = os.path.splitext(filename)
            filename += '.' + self._customFormat.extension()
        return filename