def _getAlias(self, auth_level_uri):
        """Return the alias for the specified auth level URI.

        @raises KeyError: if no alias is defined
        """
        for (alias, existing_uri) in self.auth_level_aliases.iteritems():
            if auth_level_uri == existing_uri:
                return alias

        raise KeyError(auth_level_uri)