def set_atoms(self, a):
        """Assign an atoms object."""
        for c in self.calcs:
            if hasattr(c, "set_atoms"):
                c.set_atoms(a)