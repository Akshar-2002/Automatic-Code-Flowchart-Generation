def confirm(self, tid, out_sid, session):
        '''taobao.logistics.online.confirm 确认发货通知接口
        
        确认发货的目的是让交易流程继承走下去，确认发货后交易状态会由【买家已付款】变为【卖家已发货】，然后买家才可以确认收货，货款打入卖家账号。货到付款的订单除外'''
        request = TOPRequest('taobao.logistics.online.confirm')
        request['tid'] = tid
        request['out_sid'] = out_sid
        self.create(self.execute(request, session), fields = ['shipping',], models = {'shipping':Shipping})
        return self.shipping