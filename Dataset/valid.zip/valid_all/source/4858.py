def valid_config_exists(config_path=CONFIG_PATH):
    """Verify that a valid config file exists.

    Args:
        config_path (str): Path to the config file.

    Returns:
        boolean: True if there is a valid config file, false if not.
    """
    if os.path.isfile(config_path):
        try:
            config = read_config(config_path)
            check_config(config)
        except (ConfigurationError, IOError):
            return False
    else:
        return False
    return True