def update_aliases(aliases,aonly,x):
    "helper for ctor. takes AliasX or string as second arg"
    if isinstance(x,basestring): aliases[x]=x
    elif isinstance(x,sqparse2.AliasX):
      if not isinstance(x.alias,basestring): raise TypeError('alias not string',type(x.alias))
      if isinstance(x.name,sqparse2.NameX): aliases.update({x.alias:x.name.name,x.name.name:x.name.name})
      elif isinstance(x.name,sqparse2.SelectX):
        aliases.update({x.alias:x.alias})
        aonly[x.alias]=x.name
      else: raise TypeError('aliasx_unk_thing',type(x.name)) # pragma: no cover
    else: raise TypeError(type(x)) # pragma: no cover