def sender(self, func, routing=None, routing_re=None):
        """
        Registers a sender function
        """
        if routing and not isinstance(routing, list):
            routing = [routing]

        if routing_re:
            if not isinstance(routing_re, list):
                routing_re = [routing_re]
            routing_re[:] = [re.compile(r) for r in routing_re]

        self.senders.append((func, routing, routing_re))