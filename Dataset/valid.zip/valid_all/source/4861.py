def get_configuration(self):
        """Returns a mapping of UID -> configuration
        """
        mapping = {}
        settings = self.get_settings()
        for record in self.context.getAnalyses():
            uid = record.get("service_uid")
            setting = settings.get(uid, {})
            config = {
                "partition": record.get("partition"),
                "hidden": setting.get("hidden", False),
            }
            mapping[uid] = config
        return mapping