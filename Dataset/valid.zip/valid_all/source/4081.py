def get(self, *args, **kwargs):
        """Handle reading of the model

        :param args:
        :param kwargs:

        """
        # Create the model and fetch its data
        self.model = self.get_model(kwargs.get('id'))
        result = yield self.model.fetch()

        # If model is not found, return 404
        if not result:
            LOGGER.debug('Not found')
            self.not_found()
            return

        # Stub to check for read permissions
        if not self.has_read_permission():
            LOGGER.debug('Permission denied')
            self.permission_denied()
            return

        # Add the headers and return the content as JSON
        self.add_headers()
        self.finish(self.model_json())