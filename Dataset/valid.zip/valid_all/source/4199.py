def get_multi_temperature_data(kt0=1.0, kt1=5.0, length0=10000, length1=10000, n0=10, n1=10):
    """
    Continuous MCMC process in an asymmetric double well potential at multiple temperatures.

    Parameters
    ----------
    kt0: double, optional, default=1.0
        Temperature in kT for the first thermodynamic state.
    kt1: double, optional, default=5.0
        Temperature in kT for the second thermodynamic state.
    length0: int, optional, default=10000
        Trajectory length in steps for the first thermodynamic state.
    length1: int, optional, default=10000
        Trajectory length in steps for the second thermodynamic state.
    n0: int, optional, default=10
        Number of trajectories in the first thermodynamic state.
    n1: int, optional, default=10
        Number of trajectories in the second thermodynamic state.

    Returns
    -------
    dict - keys shown below in brackets
        Trajectory (trajs), energy (energy_trajs), and temperature (temp_trajs) data from the MCMC
        runs as well as the discretised version (dtrajs + centers). Energies and temperatures are
        given in kT, lengths in arbitrary units.
    """
    dws = _DWS()
    mt_data = dws.mt_sample(
        kt0=kt0, kt1=kt1, length0=length0, length1=length1, n0=n0, n1=n1)
    mt_data.update(centers=dws.centers)
    return mt_data