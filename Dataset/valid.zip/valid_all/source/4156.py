def parse_coverage(self, f):
    """ Parse the contents of the Qualimap BamQC Coverage Histogram file """
    # Get the sample name from the parent parent directory
    # Typical path: <sample name>/raw_data_qualimapReport/coverage_histogram.txt
    s_name = self.get_s_name(f)

    d = dict()
    for l in f['f']:
        if l.startswith('#'):
            continue
        coverage, count = l.split(None, 1)
        coverage = int(round(float(coverage)))
        count = float(count)
        d[coverage] = count

    if len(d) == 0:
        log.debug("Couldn't parse contents of coverage histogram file {}".format(f['fn']))
        return None

    # Find median without importing anything to do it for us
    num_counts = sum(d.values())
    cum_counts = 0
    median_coverage = None
    for thiscov, thiscount in d.items():
        cum_counts += thiscount
        if cum_counts >= num_counts/2:
            median_coverage = thiscov
            break
    self.general_stats_data[s_name]['median_coverage'] = median_coverage

    # Save results
    if s_name in self.qualimap_bamqc_coverage_hist:
        log.debug("Duplicate coverage histogram sample name found! Overwriting: {}".format(s_name))
    self.qualimap_bamqc_coverage_hist[s_name] = d
    self.add_data_source(f, s_name=s_name, section='coverage_histogram')