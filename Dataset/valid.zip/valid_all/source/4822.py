def add_instruction (self, instr):
        """
        Adds the argument instruction in the list of instructions of this basic block.

        Also updates the variable lists (used_variables, defined_variables)
        """
        assert(isinstance(instr, Instruction))
        self.instruction_list.append(instr)
        if instr.lhs not in self.defined_variables:
            if isinstance(instr.lhs, Variable):
                self.defined_variables.append(instr.lhs)
        if isinstance(instr, EqInstruction):
            if isinstance(instr.rhs, Variable):
                if instr.rhs not in self.used_variables:
                    self.used_variables.append(instr.rhs)
        else:
            if isinstance(instr.rhs_1, Variable):
                if instr.rhs_1 not in self.used_variables:
                    self.used_variables.append(instr.rhs_1)
            if isinstance(instr.rhs_2, Variable):
                if instr.rhs_2 not in self.used_variables:
                    self.used_variables.append(instr.rhs_2)