def _register_external_service(self, plugin_name, plugin_instance):
        """
        Register an external service.

        :param plugin_name: Service name
        :param plugin_instance: PluginBase
        :return:
        """
        for attr in plugin_instance.get_external_services().keys():
            if attr in self._external_services:
                raise PluginException("External service with name {} already exists! Unable to add "
                                      "services from plugin {}.".format(attr, plugin_name))
            self._external_services[attr] = plugin_instance.get_external_services().get(attr)