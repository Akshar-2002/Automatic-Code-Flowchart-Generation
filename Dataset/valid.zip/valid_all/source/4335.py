def setup_catalogs(
        portal, catalogs_definition={},
        force_reindex=False, catalogs_extension={}, force_no_reindex=False):
    """
    Setup the given catalogs. Redefines the map between content types and
    catalogs and then checks the indexes and metacolumns, if one index/column
    doesn't exist in the catalog_definition any more it will be
    removed, otherwise, if a new index/column is found, it will be created.

    :param portal: The Plone's Portal object
    :param catalogs_definition: a dictionary with the following structure
        {
            CATALOG_ID: {
                'types':   ['ContentType', ...],
                'indexes': {
                    'UID': 'FieldIndex',
                    ...
                },
                'columns': [
                    'Title',
                    ...
                ]
            }
        }
    :type catalogs_definition: dict
    :param force_reindex: Force to reindex the catalogs even if there's no need
    :type force_reindex: bool
    :param force_no_reindex: Force reindexing NOT to happen.
    :param catalog_extensions: An extension for the primary catalogs definition
        Same dict structure as param catalogs_definition. Allows to add
        columns and indexes required by Bika-specific add-ons.
    :type catalog_extensions: dict
    """
    # If not given catalogs_definition, use the LIMS one
    if not catalogs_definition:
        catalogs_definition = getCatalogDefinitions()

    # Merge the catalogs definition of the extension with the primary
    # catalog definition
    definition = _merge_catalog_definitions(catalogs_definition,
                                            catalogs_extension)

    # Mapping content types in catalogs
    # This variable will be used to clean reindex the catalog. Saves the
    # catalogs ids
    archetype_tool = getToolByName(portal, 'archetype_tool')
    clean_and_rebuild = _map_content_types(archetype_tool, definition)

    # Indexing
    for cat_id in definition.keys():
        reindex = False
        reindex = _setup_catalog(
            portal, cat_id, definition.get(cat_id, {}))
        if (reindex or force_reindex) and (cat_id not in clean_and_rebuild):
            # add the catalog if it has not been added before
            clean_and_rebuild.append(cat_id)
    # Reindex the catalogs which needs it
    if not force_no_reindex:
        _cleanAndRebuildIfNeeded(portal, clean_and_rebuild)
    return clean_and_rebuild