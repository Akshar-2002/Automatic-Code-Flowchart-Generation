def _remove_unicode_keys(dictobj):
    """Convert keys from 'unicode' to 'str' type.

    workaround for <http://bugs.python.org/issue2646>
    """
    if sys.version_info[:2] >= (3, 0): return dictobj

    assert isinstance(dictobj, dict)

    newdict = {}
    for key, value in dictobj.items():
        if type(key) is unicode:
            key = key.encode('utf-8')
        newdict[key] = value
    return newdict