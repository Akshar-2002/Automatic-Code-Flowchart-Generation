def collect_results(self) -> Optional[Tuple[int, Dict[str, float]]]:
        """
        Returns the decoded checkpoint and the decoder metrics or None if the queue is empty.
        """
        self.wait_to_finish()
        if self.decoder_metric_queue.empty():
            if self._results_pending:
                self._any_process_died = True
            self._results_pending = False
            return None
        decoded_checkpoint, decoder_metrics = self.decoder_metric_queue.get()
        assert self.decoder_metric_queue.empty()
        self._results_pending = False
        logger.info("Decoder-%d finished: %s", decoded_checkpoint, decoder_metrics)
        return decoded_checkpoint, decoder_metrics