def mxmt(m1, m2):
    """
    Multiply a 3x3 matrix and the transpose of another 3x3 matrix.

    http://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/cspice/mxmt_c.html

    :param m1: 3x3 double precision matrix.
    :type m1: 3x3-Element Array of floats
    :param m2: 3x3 double precision matrix.
    :type m2: 3x3-Element Array of floats
    :return: The product m1 times m2 transpose.
    :rtype: float
    """
    m1 = stypes.toDoubleMatrix(m1)
    m2 = stypes.toDoubleMatrix(m2)
    mout = stypes.emptyDoubleMatrix()
    libspice.mxmt_c(m1, m2, mout)
    return stypes.cMatrixToNumpy(mout)