def read_vest_pickle(gname, score_dir):
    """Read in VEST scores for given gene.

    Parameters
    ----------
    gname : str
        name of gene
    score_dir : str
        directory containing vest scores

    Returns
    -------
    gene_vest : dict or None
        dict containing vest scores for gene. Returns None if not found.
    """
    vest_path = os.path.join(score_dir, gname+".vest.pickle")
    if os.path.exists(vest_path):
        if sys.version_info < (3,):
            with open(vest_path) as handle:
                gene_vest = pickle.load(handle)
        else:
            with open(vest_path, 'rb') as handle:
                gene_vest = pickle.load(handle, encoding='latin-1')
        return gene_vest
    else:
        return None