def _find_valid_block(self, table, worksheet, flags, units, used_cells, start_pos, end_pos):
        '''
        Searches for the next location where a valid block could reside and constructs the block
        object representing that location.
        '''
        for row_index in range(len(table)):
            if row_index < start_pos[0] or row_index > end_pos[0]:
                continue
            convRow = table[row_index]
            used_row = used_cells[row_index]
            for column_index, conv in enumerate(convRow):
                if (column_index < start_pos[1] or column_index > end_pos[1] or used_row[column_index]):
                    continue
                # Is non empty cell?
                if not is_empty_cell(conv):
                    block_start, block_end = self._find_block_bounds(table, used_cells,
                            (row_index, column_index), start_pos, end_pos)
                    if (block_end[0] > block_start[0] and
                        block_end[1] > block_start[1]):
                        try:
                            return TableBlock(table, used_cells, block_start, block_end, worksheet,
                                flags, units, self.assume_complete_blocks, self.max_title_rows)
                        except InvalidBlockError:
                            pass
                        # Prevent infinite loops if something goes wrong
                        used_cells[row_index][column_index] = True