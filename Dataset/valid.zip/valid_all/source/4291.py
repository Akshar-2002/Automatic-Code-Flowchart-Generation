def _read_data_type_none(self, length):
        """Read IPv6-Route unknown type data.

        Structure of IPv6-Route unknown type data [RFC 8200][RFC 5095]:
            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            |  Next Header  |  Hdr Ext Len  |  Routing Type | Segments Left |
            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
            |                                                               |
            .                                                               .
            .                       type-specific data                      .
            .                                                               .
            |                                                               |
            +-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+

            Octets      Bits        Name                    Description
              0           0     route.next              Next Header
              1           8     route.length            Header Extensive Length
              2          16     route.type              Routing Type
              3          24     route.seg_left          Segments Left
              4          32     route.data              Type-Specific Data

        """
        _data = self._read_fileng(length)

        data = dict(
            data=_data,
        )

        return data