def unfinished(finished_status,
               update_interval,
               table,
               status_column,
               edit_at_column):
    """
    Create text sql statement query for sqlalchemy that getting all unfinished task.

    :param finished_status: int, status code that less than this
        will be considered as unfinished.
    :param update_interval: int, the record will be updated every x seconds.

    :return: sqlalchemy text sql statement.


    **中文文档**

    状态码小于某个值, 或者, 现在距离更新时间已经超过一定阈值.
    """
    sql = select([table]).where(
        or_(*[
            status_column < finished_status,
            edit_at_column < x_seconds_before_now(update_interval)
        ])
    )
    return sql