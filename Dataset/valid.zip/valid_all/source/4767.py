def parse_with(self, node):
        """
        Parses <With>

        @param node: Node containing the <With> element
        @type node: xml.etree.Element
        """

        if 'instance' in node.lattrib:
            instance = node.lattrib['instance']
            list = None
            index = None
        elif 'list' in node.lattrib and 'index' in node.lattrib:
            instance = None
            list = node.lattrib['list']
            index = node.lattrib['index']
        else:
            self.raise_error('<With> must specify EITHER instance OR list & index')

        if 'as' in node.lattrib:
            as_ = node.lattrib['as']
        else:
            self.raise_error('<With> must specify a name for the '
                             'target instance')

        self.current_structure.add_with(With(instance, as_, list, index))