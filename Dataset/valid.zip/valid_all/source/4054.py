def get_path():
    '''
    Returns a list of items in the SYSTEM path

    CLI Example:

    .. code-block:: bash

        salt '*' win_path.get_path
    '''
    ret = salt.utils.stringutils.to_unicode(
        __utils__['reg.read_value'](
            'HKEY_LOCAL_MACHINE',
            'SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Environment',
            'PATH')['vdata']
    ).split(';')

    # Trim ending backslash
    return list(map(_normalize_dir, ret))