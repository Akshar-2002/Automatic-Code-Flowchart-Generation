def delete(self, lookup):
		"""
		If exactly one quote matches, delete it. Otherwise,
		raise a ValueError.
		"""
		lookup, num = self.split_num(lookup)
		if num:
			result = self.find_matches(lookup)[num - 1]
		else:
			result, = self.find_matches(lookup)
		self.db.delete_one(result)