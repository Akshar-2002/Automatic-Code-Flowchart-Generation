def alias_symbol(self,
                     alias_symbol=None,
                     is_previous_symbol=None,
                     hgnc_symbol=None,
                     hgnc_identifier=None,
                     limit=None,
                     as_df=False):
        """Method to query :class:`.models.AliasSymbol` objects in database

        :param alias_symbol: alias symbol(s)
        :type alias_symbol: str or tuple(str) or None

        :param is_previous_symbol: flag for 'is previous'
        :type is_previous_symbol: bool or tuple(bool) or None

        :param hgnc_symbol: HGNC symbol(s)
        :type hgnc_symbol: str or tuple(str) or None

        :param hgnc_identifier: identifiers(s) in :class:`.models.HGNC`
        :type hgnc_identifier: int or tuple(int) or None

        :param limit:
            - if `isinstance(limit,int)==True` -> limit
            - if `isinstance(limit,tuple)==True` -> format:= tuple(page_number, results_per_page)
            - if limit == None -> all results
        :type limit: int or tuple(int) or None

        :param bool as_df: if `True` results are returned as :class:`pandas.DataFrame`

        :return:
            - if `as_df == False` -> list(:class:`.models.AliasSymbol`)
            - if `as_df == True`  -> :class:`pandas.DataFrame`
        :rtype: list(:class:`.models.AliasSymbol`) or :class:`pandas.DataFrame`

        """
        q = self.session.query(models.AliasSymbol)

        model_queries_config = (
            (alias_symbol, models.AliasSymbol.alias_symbol),
            (is_previous_symbol, models.AliasSymbol.is_previous_symbol),
        )
        q = self.get_model_queries(q, model_queries_config)

        one_to_many_queries_config = (
            (hgnc_symbol, models.HGNC.symbol),
            (hgnc_identifier, models.HGNC.identifier)
        )
        q = self.get_one_to_many_queries(q, one_to_many_queries_config)

        return self._limit_and_df(q, limit, as_df)