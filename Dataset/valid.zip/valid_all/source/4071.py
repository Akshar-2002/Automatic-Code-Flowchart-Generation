def register(self, name, func):
        """
        Register a new callback.\
        When the name/id is not found\
        a new hook is created under its name,\
        meaning the hook is usually created by\
        the first registered callback

        :param str name: Hook name
        :param callable func: A func reference (callback)
        """
        try:
            templatehook = self._registry[name]
        except KeyError:
            templatehook = self._register(name)

        templatehook.register(func)