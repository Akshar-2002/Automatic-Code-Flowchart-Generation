async def get_data(self):
        """Retrieve the data."""
        url = '{}/{}'.format(self.url, 'all')

        try:
            with async_timeout.timeout(5, loop=self._loop):
                if self.password is None:
                    response = await self._session.get(url)
                else:
                    auth = aiohttp.BasicAuth(self.username, self.password)
                    response = await self._session.get(url, auth=auth)

            _LOGGER.debug("Response from Glances API: %s", response.status)
            print(response.status)
            print(response.text)
            self.data = await response.json()
            _LOGGER.debug(self.data)
        except (asyncio.TimeoutError, aiohttp.ClientError):
            _LOGGER.error("Can not load data from Glances API")
            raise exceptions.GlancesApiConnectionError()