def listFiletypes(targetfilename, directory):
    """Looks for all occurences of a specified filename in a directory and
    returns a list of all present file extensions of this filename.

    In this cas everything after the first dot is considered to be the file
    extension: ``"filename.txt" -> "txt"``, ``"filename.txt.zip" -> "txt.zip"``

    :param targetfilename: a filename without any extensions
    :param directory: only files present in this directory are compared
        to the targetfilename

    :returns: a list of file extensions (str)
    """
    targetextensions = list()
    for filename in os.listdir(directory):
        if not os.path.isfile(joinpath(directory, filename)):
            continue
        splitname = filename.split('.')
        basename = splitname[0]
        extension = '.'.join(splitname[1:])
        if basename == targetfilename:
            targetextensions.append(extension)
    return targetextensions