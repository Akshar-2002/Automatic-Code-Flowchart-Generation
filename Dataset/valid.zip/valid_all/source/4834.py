def reset(self):
        """ Re-initialises the environment.
        """
        logger.info("Reseting environment.")

        self._step = 0

        # Reset the set-point of each generator to its original value.
        gs = [g for g in self.case.online_generators if g.bus.type !=REFERENCE]
        for i, g in enumerate(gs):
            g.p = self._Pg0[i]

        # Apply load profile to the original demand at each bus.
        for i, b in enumerate([b for b in self.case.buses if b.type == PQ]):
            b.p_demand = self._Pd0[i] * self.profile[self._step]

        # Initialise the record of generator set-points.
        self._Pg = zeros((len(self.case.online_generators), len(self.profile)))

        # Apply the first load profile value.
#        self.step()

        self.case.reset()