def singularize(word):
    """
    Converts the inputted word to the single form of it.  This method works
    best if you use the inflect module, as it will just pass along the
    request to inflect.singular_noun.  If you do not have that module, then a 
    simpler and less impressive singularization technique will be used.
    
    :sa         https://pypi.python.org/pypi/inflect
    
    :param      word        <str>
    
    :return     <str>
    """
    word = toUtf8(word)
    if inflect_engine:
        result = inflect_engine.singular_noun(word)
        if result is False:
            return word
        return result

    # go through the different plural expressions, searching for the
    # proper replacement
    if word.endswith('ies'):
        return word[:-3] + 'y'
    elif word.endswith('IES'):
        return word[:-3] + 'Y'
    elif word.endswith('s') or word.endswith('S'):
        return word[:-1]

    return word