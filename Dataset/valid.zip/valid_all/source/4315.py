def fetch_access_token(self):
        """
        获取 access token
        详情请参考 https://open.weixin.qq.com/cgi-bin/showdocument?action=dir_list\
        &t=resource/res_list&verify=1&id=open1419318587&token=&lang=zh_CN

        这是内部刷新机制。请不要完全依赖！
        因为有可能在缓存期间没有对此公众号的操作，造成refresh_token失效。

        :return: 返回的 JSON 数据包
        """
        expires_in = 7200
        result = self.component.refresh_authorizer_token(
            self.appid, self.refresh_token)
        if 'expires_in' in result:
            expires_in = result['expires_in']
        self.session.set(
            self.access_token_key,
            result['authorizer_access_token'],
            expires_in
        )
        self.expires_at = int(time.time()) + expires_in
        return result