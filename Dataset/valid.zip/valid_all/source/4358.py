def get_key_field(ui, ui_option_name, default_val=0, default_is_number=True):
  """
    parse an option from a UI object as the name of a key field.

    If the named option is not set, return the default values for the tuple.

    :return: a tuple of two items, first is the value of the option, second is
             a boolean value that indicates whether the value is a column name
             or a column number (numbers start at 0).
  """
  key = default_val
  key_is_field_number = default_is_number
  if ui.optionIsSet(ui_option_name):
    key = ui.getValue(ui_option_name)
    try:
      key = int(key) - 1
      key_is_field_number = True
    except ValueError:
      key_is_field_number = False
  return key, key_is_field_number