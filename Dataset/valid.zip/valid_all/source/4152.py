def send_request_message(self, request_id, meta, body, _=None):
        """
        Receives a request from the client and handles and dispatches in in-thread. `message_expiry_in_seconds` is not
        supported. Messages do not expire, as the server handles the request immediately in the same thread before
        this method returns. This method blocks until the server has completed handling the request.
        """
        self._current_request = (request_id, meta, body)
        try:
            self.server.handle_next_request()
        finally:
            self._current_request = None