def update_slice(self, blob):
        """Update the slice proposal scale based on the relative
        size of the slices compared to our initial guess."""

        nexpand, ncontract = blob['nexpand'], blob['ncontract']
        self.scale *= nexpand / (2. * ncontract)