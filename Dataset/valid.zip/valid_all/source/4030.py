def metrics_for_mode(self, mode):
    """Metrics available for a given mode."""
    if mode not in self._values:
      logging.info("Mode %s not found", mode)
      return []
    return sorted(list(self._values[mode].keys()))