def dms2dd(degrees, minutes, seconds, direction):
    """convert degrees, minutes, seconds to dd
    :param string direction: one of N S W E
    """
    dd = (degrees + minutes/60.0) + (seconds/3600.0)           # 60.0 fraction for python 2+ compatibility
    return dd * -1 if direction == 'S' or direction == 'W' else dd