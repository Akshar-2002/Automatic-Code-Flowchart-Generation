def login(self, login, password, url=None):
        """login page
        """
        auth = self._auth(login, password)
        cherrypy.session['isadmin'] = auth['isadmin']
        cherrypy.session['connected'] = auth['connected']

        if auth['connected']:
            if auth['isadmin']:
                message = \
                    "login success for user '%(user)s' as administrator" % {
                        'user': login
                    }
            else:
                message = \
                    "login success for user '%(user)s' as normal user" % {
                        'user': login
                    }
            cherrypy.log.error(
                msg=message,
                severity=logging.INFO
            )
            cherrypy.session[SESSION_KEY] = cherrypy.request.login = login
            if url is None:
                redirect = "/"
            else:
                redirect = url
            raise cherrypy.HTTPRedirect(redirect)
        else:
            message = "login failed for user '%(user)s'" % {
                'user': login
            }
            cherrypy.log.error(
                msg=message,
                severity=logging.WARNING
            )
            if url is None:
                qs = ''
            else:
                qs = '?url=' + quote_plus(url)
            raise cherrypy.HTTPRedirect("/signin" + qs)