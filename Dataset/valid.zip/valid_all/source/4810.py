def rt_update(self, statement, linenum, mode, xparser):
        """Uses the specified line parser to parse the given line.

        :arg statement: a string of lines that are part of a single statement.
        :arg linenum: the line number of the first line in the list relative to
          the entire module contents.
        arg mode: either 'insert', 'replace' or 'delete'
        :arg xparser: an instance of the executable parser from the real
          time update module's line parser.
        """
        section = self.find_section(self.module.charindex(linenum, 1))

        if section == "body":
            xparser.parse_line(statement, self, mode)
        elif section == "signature":
            if mode == "insert":
                xparser.parse_signature(statement, self)