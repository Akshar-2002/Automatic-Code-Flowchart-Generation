def set_border(self, thickness, color="black"):
        """
        Sets the border thickness and color.

        :param int thickness:
            The thickenss of the border.

        :param str color:
            The color of the border.
        """
        self._set_tk_config("highlightthickness", thickness)
        self._set_tk_config("highlightbackground", utils.convert_color(color))