def managed_sans(self):
        """
        Gets the Managed SANs API client.

        Returns:
            ManagedSANs:
        """
        if not self.__managed_sans:
            self.__managed_sans = ManagedSANs(self.__connection)
        return self.__managed_sans