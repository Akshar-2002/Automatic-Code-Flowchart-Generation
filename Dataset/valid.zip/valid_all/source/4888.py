def insrtc(item, inset):
    """
    Insert an item into a character set.

    http://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/cspice/insrtc_c.html

    :param item: Item to be inserted.
    :type item: str or list of str
    :param inset: Insertion set.
    :type inset: spiceypy.utils.support_types.SpiceCell
    """
    assert isinstance(inset, stypes.SpiceCell)
    if isinstance(item, list):
        for c in item:
            libspice.insrtc_c(stypes.stringToCharP(c), ctypes.byref(inset))
    else:
        item = stypes.stringToCharP(item)
        libspice.insrtc_c(item, ctypes.byref(inset))