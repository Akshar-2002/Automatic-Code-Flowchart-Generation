def _flush_tile_queue_blits(self, surface):
        """ Blit the queued tiles and block until the tile queue is empty

        for pygame 1.9.4 +
        """
        tw, th = self.data.tile_size
        ltw = self._tile_view.left * tw
        tth = self._tile_view.top * th

        self.data.prepare_tiles(self._tile_view)

        blit_list = [(image, (x * tw - ltw, y * th - tth)) for x, y, l, image in self._tile_queue]
        surface.blits(blit_list)