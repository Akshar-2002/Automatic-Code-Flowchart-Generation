def c2ln(c,l1,l2,n):
    "char[n] to two unsigned long???"
    c = c + n
    l1, l2 = U32(0), U32(0)

    f = 0
    if n == 8:
        l2 = l2 | (U32(c[7]) << 24)
        f = 1
    if f or (n == 7):
        l2 = l2 | (U32(c[6]) << 16)
        f = 1
    if f or (n == 6):
        l2 = l2 | (U32(c[5]) << 8)
        f = 1
    if f or (n == 5):
        l2 = l2 | U32(c[4])
        f = 1
    if f or (n == 4):
        l1 = l1 | (U32(c[3]) << 24)
        f = 1
    if f or (n == 3):
        l1 = l1 | (U32(c[2]) << 16)
        f = 1
    if f or (n == 2):
        l1 = l1 | (U32(c[1]) << 8)
        f = 1
    if f or (n == 1):
        l1 = l1 | U32(c[0])
    return (l1, l2)