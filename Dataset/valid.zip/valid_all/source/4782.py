def send_notification(self, method, *args):
        """Send a JSON-RPC notification.

        The notification *method* is sent with positional arguments *args*.
        """
        message = self._version.create_request(method, args, notification=True)
        self.send_message(message)