def convex_hull_image(image):
    '''Given a binary image, return an image of the convex hull'''
    labels = image.astype(int)
    points, counts = convex_hull(labels, np.array([1]))
    output = np.zeros(image.shape, int)
    for i in range(counts[0]):
        inext = (i+1) % counts[0]
        draw_line(output, points[i,1:], points[inext,1:],1)
    output = fill_labeled_holes(output)
    return output == 1