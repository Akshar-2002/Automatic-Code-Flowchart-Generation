def start(self):
        """Public method for initiating connectivity with the emby server."""
        asyncio.ensure_future(self.register(), loop=self._event_loop)

        if self._own_loop:
            _LOGGER.info("Starting up our own event loop.")
            self._event_loop.run_forever()
            self._event_loop.close()
            _LOGGER.info("Connection shut down.")