def from_env(key: str, default: T = None) -> Union[str, Optional[T]]:
    """Shortcut for safely reading environment variable.

    :param key: Environment var key.
    :param default:
        Return default value if environment var not found by given key. By
        default: ``None``
    """
    return os.getenv(key, default)