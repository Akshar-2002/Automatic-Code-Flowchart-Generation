def _handle_files(self, data):
        """Handle new files being uploaded"""

        initial = data.get("set", False)
        files = data["files"]
        for f in files:
            try:
                fobj = File(
                    self.room,
                    self.conn,
                    f[0],
                    f[1],
                    type=f[2],
                    size=f[3],
                    expire_time=int(f[4]) / 1000,
                    uploader=f[6].get("nick") or f[6].get("user"),
                )
                self.room.filedict = fobj.fid, fobj
                if not initial:
                    self.conn.enqueue_data("file", fobj)
            except Exception:
                import pprint

                LOGGER.exception("bad file")
                pprint.pprint(f)
        if initial:
            self.conn.enqueue_data("initial_files", self.room.files)