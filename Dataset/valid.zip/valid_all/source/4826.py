def break_fiber(depth=0):
    """After calling break_fiber, get_state() will return None."""
    set_stack_var(SECTION_BOUNDARY_TAG, True, depth=depth+1)
    set_stack_var(SECTION_STATE_TAG, None, depth=depth+1)