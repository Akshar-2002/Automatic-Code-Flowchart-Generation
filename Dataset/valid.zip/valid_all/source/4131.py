def ckgpav(inst, sclkdp, tol, ref):
    """
    Get pointing (attitude) and angular velocity
    for a specified spacecraft clock time.

    http://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/cspice/ckgpav_c.html

    :param inst: NAIF ID of instrument, spacecraft, or structure.
    :type inst: int
    :param sclkdp: Encoded spacecraft clock time.
    :type sclkdp: float
    :param tol: Time tolerance.
    :type tol: float
    :param ref: Reference frame.
    :type ref: str
    :return:
            C-matrix pointing data,
            Angular velocity vector,
            Output encoded spacecraft clock time.
    :rtype: tuple
    """
    inst = ctypes.c_int(inst)
    sclkdp = ctypes.c_double(sclkdp)
    tol = ctypes.c_double(tol)
    ref = stypes.stringToCharP(ref)
    cmat = stypes.emptyDoubleMatrix()
    av = stypes.emptyDoubleVector(3)
    clkout = ctypes.c_double()
    found = ctypes.c_int()
    libspice.ckgpav_c(inst, sclkdp, tol, ref, cmat, av, ctypes.byref(clkout),
                      ctypes.byref(found))
    return stypes.cMatrixToNumpy(cmat), stypes.cVectorToPython(
            av), clkout.value, bool(found.value)