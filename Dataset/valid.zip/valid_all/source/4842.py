def create_network(batch_size, update_freq):
    """Create a linear regression network for performing SVRG optimization.
    :return: an instance of mx.io.NDArrayIter
    :return: an instance of mx.mod.svrgmodule for performing SVRG optimization
    """
    head = '%(asctime)-15s %(message)s'
    logging.basicConfig(level=logging.INFO, format=head)
    data = np.random.randint(1, 5, [1000, 2])

    #Test_Train data split
    n_train = int(data.shape[0] * 0.8)
    weights = np.array([1.0, 2.0])
    label = data.dot(weights)

    di = mx.io.NDArrayIter(data[:n_train, :], label[:n_train], batch_size=batch_size, shuffle=True, label_name='lin_reg_label')
    val_iter = mx.io.NDArrayIter(data[n_train:, :], label[n_train:], batch_size=batch_size)

    X = mx.sym.Variable('data')
    Y = mx.symbol.Variable('lin_reg_label')
    fully_connected_layer = mx.sym.FullyConnected(data=X, name='fc1', num_hidden=1)
    lro = mx.sym.LinearRegressionOutput(data=fully_connected_layer, label=Y, name="lro")

    mod = SVRGModule(
        symbol=lro,
        data_names=['data'],
        label_names=['lin_reg_label'], update_freq=update_freq, logger=logging)

    return di, val_iter, mod