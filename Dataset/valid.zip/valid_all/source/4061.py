def write_roi(self, outfile=None,
                  save_model_map=False, **kwargs):
        """Write current state of the analysis to a file.  This method
        writes an XML model definition, a ROI dictionary, and a FITS
        source catalog file.  A previously saved analysis state can be
        reloaded from the ROI dictionary file with the
        `~fermipy.gtanalysis.GTAnalysis.load_roi` method.

        Parameters
        ----------

        outfile : str
            String prefix of the output files.  The extension of this
            string will be stripped when generating the XML, YAML and
            npy filenames.

        make_plots : bool
            Generate diagnostic plots.

        save_model_map : bool
            Save the current counts model to a FITS file.

        """
        # extract the results in a convenient format

        make_plots = kwargs.get('make_plots', False)
        save_weight_map = kwargs.get('save_weight_map', False)

        if outfile is None:
            pathprefix = os.path.join(self.config['fileio']['workdir'],
                                      'results')
        elif not os.path.isabs(outfile):
            pathprefix = os.path.join(self.config['fileio']['workdir'],
                                      outfile)
        else:
            pathprefix = outfile

        pathprefix = utils.strip_suffix(pathprefix,
                                        ['fits', 'yaml', 'npy'])
#        pathprefix, ext = os.path.splitext(pathprefix)
        prefix = os.path.basename(pathprefix)

        xmlfile = pathprefix + '.xml'
        fitsfile = pathprefix + '.fits'
        npyfile = pathprefix + '.npy'

        self.write_xml(xmlfile)
        self.write_fits(fitsfile)

        if not self.config['gtlike']['use_external_srcmap']:
            for c in self.components:
                c.like.logLike.saveSourceMaps(str(c.files['srcmap']))

        if save_model_map:
            self.write_model_map(prefix)

        if save_weight_map:
            self.write_weight_map(prefix)

        o = {}
        o['roi'] = copy.deepcopy(self._roi_data)
        o['config'] = copy.deepcopy(self.config)
        o['version'] = fermipy.__version__
        o['stversion'] = fermipy.get_st_version()
        o['sources'] = {}

        for s in self.roi.sources:
            o['sources'][s.name] = copy.deepcopy(s.data)

        for i, c in enumerate(self.components):
            o['roi']['components'][i][
                'src_expscale'] = copy.deepcopy(c.src_expscale)

        self.logger.info('Writing %s...', npyfile)
        np.save(npyfile, o)

        if make_plots:
            self.make_plots(prefix, None,
                            **kwargs.get('plotting', {}))