def __CombineGlobalParams(self, global_params, default_params):
        """Combine the given params with the defaults."""
        util.Typecheck(global_params, (type(None), self.__client.params_type))
        result = self.__client.params_type()
        global_params = global_params or self.__client.params_type()
        for field in result.all_fields():
            value = global_params.get_assigned_value(field.name)
            if value is None:
                value = default_params.get_assigned_value(field.name)
            if value not in (None, [], ()):
                setattr(result, field.name, value)
        return result