def print_preview(self, print_area, print_data):
        """Launch print preview"""

        if cairo is None:
            return

        print_info = \
            self.main_window.interfaces.get_cairo_export_info("Print")

        if print_info is None:
            # Dialog has been canceled
            return

        printout_preview = Printout(self.grid, print_data, print_info)
        printout_printing = Printout(self.grid, print_data, print_info)

        preview = wx.PrintPreview(printout_preview, printout_printing,
                                  print_data)

        if not preview.Ok():
            # Printout preview failed
            return

        pfrm = wx.PreviewFrame(preview, self.main_window, _("Print preview"))

        pfrm.Initialize()
        pfrm.SetPosition(self.main_window.GetPosition())
        pfrm.SetSize(self.main_window.GetSize())
        pfrm.Show(True)