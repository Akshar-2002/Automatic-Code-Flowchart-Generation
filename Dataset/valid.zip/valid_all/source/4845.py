def make_gaussian_kernel(sigma, npix=501, cdelt=0.01, xpix=None, ypix=None):
    """Make kernel for a 2D gaussian.

    Parameters
    ----------

    sigma : float
      Standard deviation in degrees.
    """

    sigma /= cdelt

    def fn(t, s): return 1. / (2 * np.pi * s ** 2) * np.exp(
        -t ** 2 / (s ** 2 * 2.0))
    dxy = make_pixel_distance(npix, xpix, ypix)
    k = fn(dxy, sigma)
    k /= (np.sum(k) * np.radians(cdelt) ** 2)

    return k