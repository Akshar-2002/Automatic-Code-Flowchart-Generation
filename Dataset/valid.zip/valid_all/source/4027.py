def _create_repo(line, filename):
    '''
    Create repo
    '''
    repo = {}
    if line.startswith('#'):
        repo['enabled'] = False
        line = line[1:]
    else:
        repo['enabled'] = True
    cols = salt.utils.args.shlex_split(line.strip())
    repo['compressed'] = not cols[0] in 'src'
    repo['name'] = cols[1]
    repo['uri'] = cols[2]
    repo['file'] = os.path.join(OPKG_CONFDIR, filename)
    if len(cols) > 3:
        _set_repo_options(repo, cols[3:])
    return repo