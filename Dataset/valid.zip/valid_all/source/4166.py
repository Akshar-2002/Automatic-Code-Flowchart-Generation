def django_url(step, url=None):
    """
    The URL for a page from the test server.

    :param step: A Gherkin step
    :param url: If specified, the relative URL to append.
    """

    base_url = step.test.live_server_url

    if url:
        return urljoin(base_url, url)
    else:
        return base_url