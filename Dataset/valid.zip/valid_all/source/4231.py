def p_operation_definition4(self, p):
        """
        operation_definition : operation_type name selection_set
        """
        p[0] = self.operation_cls(p[1])(selections=p[3], name=p[2])