def request(self, method, path='/', url=None, ignore_codes=[], **kwargs):
        """
        Wrapper for the ._request method that verifies if we're logged into
        RightScale before making a call, and sanity checks the oauth expiration
        time.

        :param str method: An HTTP method (e.g. 'get', 'post', 'PUT', etc...)

        :param str path: A path component of the target URL.  This will be
            appended to the value of ``self.endpoint``.  If both :attr:`path`
            and :attr:`url` are specified, the value in :attr:`url` is used and
            the :attr:`path` is ignored.

        :param str url: The target URL (e.g.  ``http://server.tld/somepath/``).
            If both :attr:`path` and :attr:`url` are specified, the value in
            :attr:`url` is used and the :attr:`path` is ignored.

        :param ignore_codes: List of HTTP error codes (e.g.  404, 500) that
            should be ignored.  If an HTTP error occurs and it is *not* in
            :attr:`ignore_codes`, then an exception is raised.
        :type ignore_codes: list of int

        :param kwargs: Any other kwargs to pass to :meth:`requests.request()`.

        Returns a :class:`requests.Response` object.
        """
        # On every call, check if we're both logged in, and if the token is
        # expiring. If it is, we'll re-login with the information passed into
        # us at instantiation.
        if time.time() > self.auth_expires_at:
            self.login()

        # Now make the actual API call
        return self._request(method, path, url, ignore_codes, **kwargs)