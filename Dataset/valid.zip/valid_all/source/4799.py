def handle_heartbeat_response_22(msg):
    """Process an internal heartbeat response message."""
    if not msg.gateway.is_sensor(msg.node_id):
        return None
    msg.gateway.sensors[msg.node_id].heartbeat = msg.payload
    msg.gateway.alert(msg)
    return None