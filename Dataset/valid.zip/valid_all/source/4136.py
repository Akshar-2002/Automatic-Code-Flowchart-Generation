def get_upcoming_event_lists_for_the_remainder_of_the_month(self, year = None, month = None):
        '''Return the set of events as triple of (today's events, events for the remainder of the week, events for the remainder of the month).'''

        events = []
        if year == None and month == None:
            now = datetime.now(tz=self.timezone) # timezone?
        else:
            now = datetime(year=year, month=month, day=1, hour=0, minute=0, second=0, tzinfo=self.timezone)

        # Get today's events, including past events
        start_time = datetime(year=now.year, month=now.month, day=now.day, hour=0, minute=0, second=0, tzinfo=self.timezone)
        end_time = datetime(year = start_time.year, month = start_time.month, day = start_time.day, hour=23, minute=59, second=59, tzinfo=self.timezone)
        events.append(self.get_events(start_time.isoformat(), end_time.isoformat()))

        # Get this week's events
        if now.weekday() < 6:
            start_time = datetime(year=now.year, month=now.month, day=now.day + 1, hour=0, minute=0, second=0, tzinfo=self.timezone)
            end_time = start_time + timedelta(days = 6 - now.weekday())
            # We do still want to return events in the next month if they fall within this week. Otherwise
            #if end_time.month != now.month:
            #    end_time = end_time - timedelta(days = end_time.day)
            #    end_time = datetime(year = end_time.year, month = end_time.month, day = end_time.day, hour=23, minute=59, second=59, tzinfo=self.timezone)
            #else:
            end_time = end_time + timedelta(seconds = -1)
            #end_time = datetime(year = end_time.year, month = end_time.month, day = end_time.day - 1, hour=23, minute=59, second=59, tzinfo=self.timezone)
            events.append(self.get_events(start_time.isoformat(), end_time.isoformat()))
        else:
            events.append([])

        # Get this remaining events in the month
        start_time = end_time + timedelta(seconds = 1)
        if start_time.month == now.month:
            if now.month == 12:
                end_time = datetime(year = start_time.year, month = 12, day = 31, hour=23, minute=59, second=59, tzinfo=self.timezone)
            else:
                end_time = datetime(year = start_time.year, month = start_time.month + 1, day = 1, hour=0, minute=0, second=0, tzinfo=self.timezone)
                end_time = end_time - timedelta(seconds = 1)
            events.append(self.get_events(start_time.isoformat(), end_time.isoformat()))
        else:
            events.append([])

        return events