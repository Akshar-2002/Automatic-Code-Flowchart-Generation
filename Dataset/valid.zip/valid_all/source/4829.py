def main():
    """
    Set up the context and connectors
    """
    try:
        init()
    except custom_exceptions.NotConfigured:
        configure()
        init()
    # Adding this in case users are trying to run without adding a jira url.
    # I would like to take this out in a release or two.
    # TODO: REMOVE
    except (AttributeError, ConfigParser.NoOptionError):
        logging.error('It appears that your configuration is invalid, please reconfigure the app and try again.')
        configure()
        init()

    parser = argparse.ArgumentParser()

    # Now simply auto-discovering the methods listed in this module
    current_module = sys.modules[__name__]
    module_methods = [getattr(current_module, a, None) for a in dir(current_module)
                      if isinstance(getattr(current_module, a, None), types.FunctionType)
                      and a != 'main']
    argh.add_commands(parser, module_methods)

    # Putting the error logging after the app is initialized because
    # we want to adhere to the user's preferences
    try:
        argh.dispatch(parser)
    # We don't want to report keyboard interrupts to rollbar
    except (KeyboardInterrupt, SystemExit):
        raise
    except Exception as e:
        if isinstance(e, jira.exceptions.JIRAError) and "HTTP 400" in e:
            logging.warning('It appears that your authentication with {0} is invalid. Please re-configure jtime: `jtime configure` with the correct credentials'.format(configuration.load_config['jira'].get('url')))
        elif configured.get('jira').get('error_reporting', True):
            # Configure rollbar so that we report errors
            import rollbar
            from . import __version__ as version
            root_path = os.path.dirname(os.path.realpath(__file__))
            rollbar.init('7541b8e188044831b6728fa8475eab9f', 'v%s' % version, root=root_path)
            logging.error('Sorry. It appears that there was an error when handling your command. '
                          'This error has been reported to our error tracking system. To disable '
                          'this reporting, please re-configure the app: `jtime config`.')
            extra_data = {
                # grab the command that we're running
                'cmd': sys.argv[1],
                # we really don't want to see jtime in the args
                'args': sys.argv[2:],
                # lets grab anything useful, python version?
                'python': str(sys.version),
            }
            # We really shouldn't thit this line of code when running tests, so let's not cover it.
            rollbar.report_exc_info(extra_data=extra_data)  # pragma: no cover
        else:
            logging.error('It appears that there was an error when handling your command.')
            raise