def parse(self, data, extent):
        # type: (bytes, int) -> None
        '''
        Parse the passed in data into a UDF NSR Volume Structure.

        Parameters:
         data - The data to parse.
         extent - The extent that this descriptor currently lives at.
        Returns:
         Nothing.
        '''
        if self._initialized:
            raise pycdlibexception.PyCdlibInternalError('UDF NSR Volume Structure already initialized')

        (structure_type, self.standard_ident, structure_version,
         reserved_unused) = struct.unpack_from(self.FMT, data, 0)

        if structure_type != 0:
            raise pycdlibexception.PyCdlibInvalidISO('Invalid structure type')

        if self.standard_ident not in [b'NSR02', b'NSR03']:
            raise pycdlibexception.PyCdlibInvalidISO('Invalid standard identifier')

        if structure_version != 1:
            raise pycdlibexception.PyCdlibInvalidISO('Invalid structure version')

        self.orig_extent_loc = extent

        self._initialized = True