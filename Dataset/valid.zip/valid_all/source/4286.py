def get_supports(self):
        """Returns set of extension support strings referenced in this Registry

        :return: set of extension support strings
        """
        out = set()
        for ext in self.extensions.values():
            out.update(ext.get_supports())
        return out