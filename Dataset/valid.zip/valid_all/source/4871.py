def Set(self, value, fields=None):
    """Sets the metric's current value."""
    self._metric_values[_FieldsToKey(fields)] = self._value_type(value)