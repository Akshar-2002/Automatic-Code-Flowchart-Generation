def _unpack_content(raw_data, content_type=None):
        """Extract the correct structure for deserialization.

        If raw_data is a PipelineResponse, try to extract the result of RawDeserializer.
        if we can't, raise. Your Pipeline should have a RawDeserializer.

        If not a pipeline response and raw_data is bytes or string, use content-type
        to decode it. If no content-type, try JSON.

        If raw_data is something else, bypass all logic and return it directly.

        :param raw_data: Data to be processed.
        :param content_type: How to parse if raw_data is a string/bytes.
        :raises JSONDecodeError: If JSON is requested and parsing is impossible.
        :raises UnicodeDecodeError: If bytes is not UTF8
        """
        # This avoids a circular dependency. We might want to consider RawDesializer is more generic
        # than the pipeline concept, and put it in a toolbox, used both here and in pipeline. TBD.
        from .pipeline.universal import RawDeserializer

        # Assume this is enough to detect a Pipeline Response without importing it
        context = getattr(raw_data, "context", {})
        if context:
            if RawDeserializer.CONTEXT_NAME in context:
                return context[RawDeserializer.CONTEXT_NAME]
            raise ValueError("This pipeline didn't have the RawDeserializer policy; can't deserialize")

        #Assume this is enough to recognize universal_http.ClientResponse without importing it
        if hasattr(raw_data, "body"):
            return RawDeserializer.deserialize_from_http_generics(
                raw_data.text(),
                raw_data.headers
            )

        # Assume this enough to recognize requests.Response without importing it.
        if hasattr(raw_data, '_content_consumed'):
            return RawDeserializer.deserialize_from_http_generics(
                raw_data.text,
                raw_data.headers
            )

        if isinstance(raw_data, (basestring, bytes)) or hasattr(raw_data, 'read'):
            return RawDeserializer.deserialize_from_text(raw_data, content_type)
        return raw_data