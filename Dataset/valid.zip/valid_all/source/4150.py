def recover_info_from_exception(err: Exception) -> Dict:
    """
    Retrives the information added to an exception by
    :func:`add_info_to_exception`.
    """
    if len(err.args) < 1:
        return {}
    info = err.args[-1]
    if not isinstance(info, dict):
        return {}
    return info