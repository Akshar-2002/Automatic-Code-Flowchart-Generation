def columns(self, model=None):
        """
        Returns any columns used within this query.

        :return     [<orb.Column>, ..]
        """
        for query in self.__queries:
            for column in query.columns(model=model):
                yield column