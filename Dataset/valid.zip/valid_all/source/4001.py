def p_arr_access_expr(p):
    """ func_call : ARRAY_ID arg_list
    """  # This is an array access
    p[0] = make_call(p[1], p.lineno(1), p[2])
    if p[0] is None:
        return

    entry = SYMBOL_TABLE.access_call(p[1], p.lineno(1))
    entry.accessed = True