def transcript_names(self, contig=None, strand=None):
        """
        What are all the transcript names in the database
        (optionally, restrict to a given chromosome and/or strand)
        """
        return self._all_feature_values(
            column="transcript_name",
            feature="transcript",
            contig=contig,
            strand=strand)