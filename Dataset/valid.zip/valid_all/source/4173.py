def getLogger(name):
    """Create logger with custom exception() method
    """
    def exception(self, msg, *args, **kwargs):
        extra = kwargs.setdefault('extra', {})
        extra['exc_fullstack'] = self.isEnabledFor(logging.DEBUG)
        kwargs['exc_info'] = True
        self.log(logging.ERROR, msg, *args, **kwargs)

    logger = logging.getLogger(name)
    logger.exception = six.create_bound_method(exception, logger)
    return logger