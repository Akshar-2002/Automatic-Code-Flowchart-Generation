def event_params(segments, params, band=None, n_fft=None, slopes=None, 
                 prep=None, parent=None):
    """Compute event parameters.
    
    Parameters
    ----------
    segments : instance of wonambi.trans.select.Segments
        list of segments, with time series and metadata
    params : dict of bool, or str
        'dur', 'minamp', 'maxamp', 'ptp', 'rms', 'power', 'peakf', 'energy', 
        'peakef'. If 'all', a dict will be created with these keys and all 
        values as True, so that all parameters are returned.
    band : tuple of float
        band of interest for power and energy
    n_fft : int
        length of FFT. if shorter than input signal, signal is truncated; if 
        longer, signal is zero-padded to length
    slopes : dict of bool
        'avg_slope', 'max_slope', 'prep', 'invert'
    prep : dict of bool
        same keys as params. if True, segment['trans_data'] will be used as dat
    parent : QMainWindow
        for use with GUI only
        
    Returns
    -------
    list of dict
        list of segments, with time series, metadata and parameters
    """
    if parent is not None:
        progress = QProgressDialog('Computing parameters', 'Abort',
                                   0, len(segments) - 1, parent)
        progress.setWindowModality(Qt.ApplicationModal)

    param_keys = ['dur', 'minamp', 'maxamp', 'ptp', 'rms', 'power', 'peakpf', 
                  'energy', 'peakef']
    
    if params == 'all':
        params = {k: 1 for k in param_keys}
    if prep is None:
        prep = {k: 0 for k in param_keys}    
    if band is None:
        band = (None, None)

    params_out = []
    evt_output = False

    for i, seg in enumerate(segments):
        out = dict(seg)
        dat = seg['data']            

        if params['dur']:
            out['dur'] = float(dat.number_of('time')) / dat.s_freq
            evt_output = True

        if params['minamp']:
            dat1 = dat
            if prep['minamp']:
                dat1 = seg['trans_data']
            out['minamp'] = math(dat1, operator=_amin, axis='time')
            evt_output = True

        if params['maxamp']:
            dat1 = dat
            if prep['maxamp']:
                dat1 = seg['trans_data']
            out['maxamp'] = math(dat1, operator=_amax, axis='time')
            evt_output = True

        if params['ptp']:
            dat1 = dat
            if prep['ptp']:
                dat1 = seg['trans_data']
            out['ptp'] = math(dat1, operator=_ptp, axis='time')
            evt_output = True

        if params['rms']:
            dat1 = dat
            if prep['rms']:
                dat1 = seg['trans_data']
            out['rms'] = math(dat1, operator=(square, _mean, sqrt),
               axis='time')
            evt_output = True

        for pw, pk in [('power', 'peakpf'), ('energy', 'peakef')]:

            if params[pw] or params[pk]:
                evt_output = True

                if prep[pw] or prep[pk]:
                    prep_pw, prep_pk = band_power(seg['trans_data'], band,
                                                 scaling=pw, n_fft=n_fft)
                if not (prep[pw] and prep[pk]):
                    raw_pw, raw_pk = band_power(dat, band, 
                                                scaling=pw, n_fft=n_fft)

                if prep[pw]:
                    out[pw] = prep_pw
                else:
                    out[pw] = raw_pw

                if prep[pk]:
                    out[pk] = prep_pk
                else:
                    out[pk] = raw_pk

        if slopes:
            evt_output = True
            out['slope'] = {}
            dat1 = dat
            if slopes['prep']:
                dat1 = seg['trans_data']
            if slopes['invert']:
                dat1 = math(dat1, operator=negative, axis='time')

            if slopes['avg_slope'] and slopes['max_slope']:
                level = 'all'
            elif slopes['avg_slope']:
                level = 'average'
            else:
                level = 'maximum'

            for chan in dat1.axis['chan'][0]:
                d = dat1(chan=chan)[0]
                out['slope'][chan] = get_slopes(d, dat.s_freq, level=level)
                
        if evt_output:
            timeline = dat.axis['time'][0]
            out['start'] = timeline[0]
            out['end'] = timeline[-1]
            params_out.append(out)

        if parent:
            progress.setValue(i)
            if progress.wasCanceled():
                msg = 'Analysis canceled by user.'
                parent.statusBar().showMessage(msg)
                return

    if parent:
        progress.close()

    return params_out