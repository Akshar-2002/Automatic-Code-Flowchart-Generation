def get_user_metadata(
            self,
            bucket: str,
            key: str
    ) -> typing.Dict[str, str]:
        """
        Retrieves the user metadata for a given object in a given bucket.  If the platform has any mandatory prefixes or
        suffixes for the metadata keys, they should be stripped before being returned.
        :param bucket: the bucket the object resides in.
        :param key: the key of the object for which metadata is being
        retrieved.
        :return: a dictionary mapping metadata keys to metadata values.
        """
        try:
            response = self.get_all_metadata(bucket, key)
            metadata = response['Metadata'].copy()

            response = self.s3_client.get_object_tagging(
                Bucket=bucket,
                Key=key,
            )
            for tag in response['TagSet']:
                key, value = tag['Key'], tag['Value']
                metadata[key] = value

            return metadata
        except botocore.exceptions.ClientError as ex:
            if str(ex.response['Error']['Code']) == \
                    str(requests.codes.not_found):
                raise BlobNotFoundError(f"Could not find s3://{bucket}/{key}") from ex
            raise BlobStoreUnknownError(ex)