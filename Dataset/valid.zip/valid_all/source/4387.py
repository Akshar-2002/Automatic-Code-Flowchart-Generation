def run(self, collector, image, available_actions, tasks, **extras):
        """Run this task"""
        task_func = available_actions[self.action]
        configuration = collector.configuration.wrapped()

        if self.options:
            if image:
                configuration.update({"images": {image: self.options}})
            else:
                configuration.update(self.options)

        # args like --port and the like should override what's in the options
        # But themselves be overridden by the overrides
        configuration.update(configuration["args_dict"].as_dict(), source="<args_dict>")

        if self.overrides:
            overrides = {}
            for key, val in self.overrides.items():
                overrides[key] = val
                if isinstance(val, MergedOptions):
                    overrides[key] = dict(val.items())
            configuration.update(overrides)

        if task_func.needs_image:
            self.find_image(image, configuration)
            image = configuration["images"][image]
            image.find_missing_env()

        from harpoon.collector import Collector
        new_collector = Collector()
        new_collector.configuration = configuration
        new_collector.configuration_file = collector.configuration_file
        artifact = configuration["harpoon"].artifact
        return task_func(new_collector, image=image, tasks=tasks, artifact=artifact, **extras)