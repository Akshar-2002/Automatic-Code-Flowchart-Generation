def stream(identifier=None, priority=LOG_INFO, level_prefix=False):
    r"""Return a file object wrapping a stream to journal.

    Log messages written to this file as simple newline sepearted text strings
    are written to the journal.

    The file will be line buffered, so messages are actually sent after a
    newline character is written.

    >>> from systemd import journal
    >>> stream = journal.stream('myapp')                       # doctest: +SKIP
    >>> res = stream.write('message...\n')                     # doctest: +SKIP

    will produce the following message in the journal::

      PRIORITY=7
      SYSLOG_IDENTIFIER=myapp
      MESSAGE=message...

    If identifier is None, a suitable default based on sys.argv[0] will be used.

    This interface can be used conveniently with the print function:

    >>> from __future__ import print_function
    >>> stream = journal.stream()                              # doctest: +SKIP
    >>> print('message...', file=stream)                       # doctest: +SKIP

    priority is the syslog priority, one of `LOG_EMERG`, `LOG_ALERT`,
    `LOG_CRIT`, `LOG_ERR`, `LOG_WARNING`, `LOG_NOTICE`, `LOG_INFO`, `LOG_DEBUG`.

    level_prefix is a boolean. If true, kernel-style log priority level prefixes
    (such as '<1>') are interpreted. See sd-daemon(3) for more information.
    """

    if identifier is None:
        if not _sys.argv or not _sys.argv[0] or _sys.argv[0] == '-c':
            identifier = 'python'
        else:
            identifier = _sys.argv[0]

    fd = stream_fd(identifier, priority, level_prefix)
    return _os.fdopen(fd, 'w', 1)