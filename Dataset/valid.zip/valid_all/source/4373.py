def transfer(self, payment_id, data={}, **kwargs):
        """"
        Create Transfer for given Payment Id

        Args:
            payment_id : Id for which payment object has to be transfered

        Returns:
            Payment dict after getting transfered
        """
        url = "{}/{}/transfers".format(self.base_url, payment_id)
        return self.post_url(url, data, **kwargs)