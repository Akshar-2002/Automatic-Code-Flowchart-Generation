def get(cls, id):
        """ Get the pool with id 'id'.
        """

        # cached?
        if CACHE:
            if id in _cache['Pool']:
                log.debug('cache hit for pool %d' % id)
                return _cache['Pool'][id]
            log.debug('cache miss for pool %d' % id)

        try:
            pool = Pool.list({'id': id})[0]
        except (IndexError, KeyError):
            raise NipapNonExistentError('no pool with ID ' + str(id) + ' found')

        _cache['Pool'][id] = pool
        return pool