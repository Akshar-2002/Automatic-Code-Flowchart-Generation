def get_recordInfo(self, headers, zoneID, zone, records):
        """Get the information of the records."""
        if 'None' in records: #If ['None'] in record argument, query all.
            recordQueryEnpoint = '/' + zoneID + '/dns_records&per_page=100'
            recordUrl = self.BASE_URL + recordQueryEnpoint
            recordRequest = requests.get(recordUrl, headers=headers)
            recordResponse = recordRequest.json()['result']
            dev = []
            num = 0
            for value in recordResponse:
                recordName = recordResponse[num]['name']
                dev.append(recordName)
                num = num + 1
            records = dev
        updateRecords = []
        for record in records:
            if zone in record:
                recordFullname = record
            else:
                recordFullname = record + '.' + zone
            recordQuery = '/' + zoneID + '/dns_records?name=' + recordFullname
            recordUrl = self.BASE_URL + recordQuery
            recordInfoRequest = requests.get(recordUrl, headers=headers)
            recordInfoResponse = recordInfoRequest.json()['result'][0]
            recordID = recordInfoResponse['id']
            recordType = recordInfoResponse['type']
            recordProxy = str(recordInfoResponse['proxied'])
            recordContent = recordInfoResponse['content']
            if recordProxy == 'True':
                recordProxied = True
            else:
                recordProxied = False
            updateRecords.append([recordID, recordFullname, recordType,
                recordContent, recordProxied])
        return updateRecords