def verb_chain_texts(self):
        """The list of texts of ``verb_chains`` layer elements."""
        if not self.is_tagged(VERB_CHAINS):
            self.tag_verb_chains()
        return self.texts(VERB_CHAINS)