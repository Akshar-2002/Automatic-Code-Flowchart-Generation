def get_png_data_url(blob: Optional[bytes]) -> str:
    """
    Converts a PNG blob into a local URL encapsulating the PNG.
    """
    return BASE64_PNG_URL_PREFIX + base64.b64encode(blob).decode('ascii')