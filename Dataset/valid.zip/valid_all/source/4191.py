def delete_instance(self, instance_id):

        '''
            method for removing an instance from AWS EC2

        :param instance_id: string of instance id on AWS
        :return: string reporting state of instance
        '''

        title = '%s.delete_instance' % self.__class__.__name__

    # validate inputs
        input_fields = {
            'instance_id': instance_id
        }
        for key, value in input_fields.items():
            object_title = '%s(%s=%s)' % (title, key, str(value))
            self.fields.validate(value, '.%s' % key, object_title)

    # report query
        self.iam.printer('Removing instance %s from AWS region %s.' % (instance_id, self.iam.region_name))

    # retrieve state
        old_state = self.check_instance_state(instance_id)

    # discover tags associated with instance id
        tag_list = []
        try:
            response = self.connection.describe_tags(
                Filters=[ { 'Name': 'resource-id', 'Values': [ instance_id ] } ]
            )
            import re
            aws_tag_pattern = re.compile('aws:')
            for i in range(0, len(response['Tags'])):
                if not aws_tag_pattern.findall(response['Tags'][i]['Key']):
                    tag = {}
                    tag['Key'] = response['Tags'][i]['Key']
                    tag['Value'] = response['Tags'][i]['Value']
                    tag_list.append(tag)
        except:
            raise AWSConnectionError(title)

    # remove tags from instance
        try:
            self.connection.delete_tags(
                Resources=[ instance_id ],
                Tags=tag_list
            )
            self.iam.printer('Tags have been deleted from %s.' % instance_id)
        except:
            raise AWSConnectionError(title)

    # stop instance
        try:
            self.connection.stop_instances(
                InstanceIds=[ instance_id ]
            )
        except:
            raise AWSConnectionError(title)

    # terminate instance
        try:
            response = self.connection.terminate_instances(
                InstanceIds=[ instance_id ]
            )
            new_state = response['TerminatingInstances'][0]['CurrentState']['Name']
        except:
            raise AWSConnectionError(title)

    # report outcome and return true
        self.iam.printer('Instance %s was %s.' % (instance_id, old_state))
        self.iam.printer('Instance %s is %s.' % (instance_id, new_state))
        return new_state