def _load_version(cls, unpickler, version):
        """
        A function to load a previously saved SentenceSplitter instance.

        Parameters
        ----------
        unpickler : GLUnpickler
            A GLUnpickler file handler.

        version : int
            Version number maintained by the class writer.
        """
        state, _exclude, _features = unpickler.load()

        features = state['features']
        excluded_features = state['excluded_features']

        model = cls.__new__(cls)
        model._setup()
        model.__proxy__.update(state)
        model._exclude = _exclude
        model._features = _features

        return model