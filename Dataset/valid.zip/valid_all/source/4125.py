def lastmod(self, tag):
        """Return the last modification of the entry."""
        lastitems = EntryModel.objects.published().order_by('-modification_date').filter(tags=tag).only('modification_date')
        return lastitems[0].modification_date