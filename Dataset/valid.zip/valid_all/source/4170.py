def reg_add(self, reg, value):
        """
        Add a value to a register. The value can be another :class:`Register`,
        an :class:`Offset`, a :class:`Buffer`, an integer or ``None``.

        Arguments:
            reg(pwnypack.shellcode.types.Register): The register to add the
                value to.
            value: The value to add to the register.

        Returns:
            list: A list of mnemonics that will add ``value`` to ``reg``.
        """

        if value is None:
            return []

        elif isinstance(value, Register):
            return self.reg_add_reg(reg, value)

        elif isinstance(value, (Buffer, six.integer_types)):
            if isinstance(reg, Buffer):
                value = sum(len(v) for v in six.iterkeys(self.data)) + value.offset

            if not value:
                return []

            reg_width = self.REGISTER_WIDTH[reg]
            if value < -2 ** (reg_width-1):
                raise ValueError('%d does not fit %s' % (value, reg))
            elif value >= 2 ** reg_width:
                raise ValueError('%d does not fit %s' % (value, reg))

            if value > 0:
                return self.reg_add_imm(reg, value)
            else:
                return self.reg_sub_imm(reg, -value)

        else:
            raise ValueError('Invalid argument type "%s"' % repr(value))