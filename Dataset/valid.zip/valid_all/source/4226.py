def gen_keys(self, keydir=None, keyname=None, keysize=None, user=None):
        '''
        Generate minion RSA public keypair
        '''
        keydir, keyname, keysize, user = self._get_key_attrs(keydir, keyname,
                                                             keysize, user)
        salt.crypt.gen_keys(keydir, keyname, keysize, user, self.passphrase)
        return salt.utils.crypt.pem_finger(os.path.join(keydir, keyname + '.pub'))