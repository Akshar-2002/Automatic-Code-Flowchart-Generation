def _determine_heterogen_chain_type(residue_types):
        '''We distinguish three types of heterogen chain: i) all solution; ii) all ligand; or iii) other (a mix of solution, ligand, and/or ions).
           residue_types should be a Set of sequence identifers e.g. GTP, ZN, HOH.
        '''
        residue_type_id_lengths = set(map(len, residue_types))
        if (len(residue_types) > 0):
            if len(residue_types.difference(common_solution_ids)) == 0:
                return 'Solution'
            elif (len(residue_type_id_lengths) == 1) and (3 in residue_type_id_lengths) and (len(residue_types.difference(common_solution_ids)) > 0):
                # The last expression discounts chains which only contain solution molecules e.g. HOH
                return 'Ligand'
        return 'Heterogen'