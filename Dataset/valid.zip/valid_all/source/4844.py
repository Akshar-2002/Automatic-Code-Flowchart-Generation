def parse_stream(self, stream: BytesIO, context=None):
        """
        Parse some python object from the stream.

        :param stream: Stream from which the data is read and parsed.
        :param context: Optional context dictionary.
        """
        if context is None:
            context = Context()
        if not isinstance(context, Context):
            context = Context(context)
        try:
            return self._parse_stream(stream, context)
        except Error:
            raise
        except Exception as exc:
            raise ParsingError(str(exc))