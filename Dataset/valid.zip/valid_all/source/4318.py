def disconnect_entry_signals():
    """
    Disconnect all the signals on Entry model.
    """
    post_save.disconnect(
        sender=Entry,
        dispatch_uid=ENTRY_PS_PING_DIRECTORIES)
    post_save.disconnect(
        sender=Entry,
        dispatch_uid=ENTRY_PS_PING_EXTERNAL_URLS)
    post_save.disconnect(
        sender=Entry,
        dispatch_uid=ENTRY_PS_FLUSH_SIMILAR_CACHE)
    post_delete.disconnect(
        sender=Entry,
        dispatch_uid=ENTRY_PD_FLUSH_SIMILAR_CACHE)