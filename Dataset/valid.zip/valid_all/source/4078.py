def filter_unmanaged_physnets(query):
    """Filter ports managed by other ML2 plugins """
    config = cfg.CONF.ml2_arista
    managed_physnets = config['managed_physnets']

    # Filter out ports bound to segments on physnets that we're not
    # managing
    segment_model = segment_models.NetworkSegment
    if managed_physnets:
        query = (query
                 .join_if_necessary(segment_model)
                 .filter(segment_model.physical_network.in_(
                     managed_physnets)))
    return query