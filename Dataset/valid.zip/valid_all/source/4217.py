def get_epoch_namespace_prices( block_height, units ):
    """
    get the list of namespace prices by block height
    """
    assert units in ['BTC', TOKEN_TYPE_STACKS], 'Invalid unit {}'.format(units)

    epoch_config = get_epoch_config( block_height )

    if units == 'BTC':
        return epoch_config['namespace_prices']
    else:
        return epoch_config['namespace_prices_stacks']