def get_descriptions(self, description_type):
        """
        Gets the descriptions for specified type.
        When complete the callback is called with a list of descriptions
        """
        (desc_type, max_units) = description_type
        results = [None] * max_units
        self.elk._descriptions_in_progress[desc_type] = (max_units,
                                                         results,
                                                         self._got_desc)
        self.elk.send(sd_encode(desc_type=desc_type, unit=0))