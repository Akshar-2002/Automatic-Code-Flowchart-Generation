def diff_with_models(self):
        """
        Return a dict stating the differences between current state of models
        and the configuration itself.
        TODO: Detect fields that are in conf, but not in models
        """
        missing_from_conf = defaultdict(set)

        for model in get_models():
            db_tables_and_columns = get_db_tables_and_columns_of_model(model)
            for (table_name, columns) in db_tables_and_columns.items():
                model_strategy = self.strategy.get(table_name)
                for column in columns:
                    if not model_strategy or column not in model_strategy:
                        missing_from_conf[table_name].add(column)
        return missing_from_conf