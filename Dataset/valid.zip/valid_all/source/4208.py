def set_static_ip_address(self, payload):
        """Set static ip address for a VM."""

        # This request is received from CLI for setting ip address of an
        # instance.
        macaddr = payload.get('mac')
        ipaddr = payload.get('ip')

        # Find the entry associated with the mac in the database.
        req = dict(mac=macaddr)
        instances = self.get_vms_for_this_req(**req)
        for vm in instances:
            LOG.info('Updating IP address: %(ip)s %(mac)s.',
                     {'ip': ipaddr, 'mac': macaddr})
            # Send request to update the rule.
            try:
                rule_info = dict(ip=ipaddr, mac=macaddr,
                                 port=vm.port_id,
                                 status='up')
                self.neutron_event.update_ip_rule(str(vm.host),
                                                  str(rule_info))
            except (rpc.MessagingTimeout, rpc.RPCException,
                    rpc.RemoteError):
                LOG.error("RPC error: Failed to update rules.")
            else:
                # Update the database.
                params = dict(columns=dict(ip=ipaddr))
                self.update_vm_db(vm.port_id, **params)

                # Send update to the agent.
                vm_info = dict(status=vm.status, vm_mac=vm.mac,
                               segmentation_id=vm.segmentation_id,
                               host=vm.host, port_uuid=vm.port_id,
                               net_uuid=vm.network_id,
                               oui=dict(ip_addr=ipaddr,
                                        vm_name=vm.name,
                                        vm_uuid=vm.instance_id,
                                        gw_mac=vm.gw_mac,
                                        fwd_mod=vm.fwd_mod,
                                        oui_id='cisco'))
                try:
                    self.neutron_event.send_vm_info(vm.host,
                                                    str(vm_info))
                except (rpc.MessagingTimeout, rpc.RPCException,
                        rpc.RemoteError):
                    LOG.error('Failed to send VM info to agent.')