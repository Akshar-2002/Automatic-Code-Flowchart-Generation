def salt_api_acl_tool(username, request):
    '''
    ..versionadded:: 2016.3.0

    Verifies user requests against the API whitelist. (User/IP pair)
    in order to provide whitelisting for the API similar to the
    master, but over the API.

    ..code-block:: yaml

        rest_cherrypy:
            api_acl:
                users:
                    '*':
                        - 1.1.1.1
                        - 1.1.1.2
                    foo:
                        - 8.8.4.4
                    bar:
                        - '*'

    :param username: Username to check against the API.
    :type username: str
    :param request: Cherrypy request to check against the API.
    :type request: cherrypy.request
    '''
    failure_str = ("[api_acl] Authentication failed for "
                   "user %s from IP %s")
    success_str = ("[api_acl] Authentication sucessful for "
                   "user %s from IP %s")
    pass_str = ("[api_acl] Authentication not checked for "
                "user %s from IP %s")

    acl = None
    # Salt Configuration
    salt_config = cherrypy.config.get('saltopts', None)
    if salt_config:
        # Cherrypy Config.
        cherrypy_conf = salt_config.get('rest_cherrypy', None)
        if cherrypy_conf:
            # ACL Config.
            acl = cherrypy_conf.get('api_acl', None)

    ip = request.remote.ip
    if acl:
        users = acl.get('users', {})
        if users:
            if username in users:
                if ip in users[username] or '*' in users[username]:
                    logger.info(success_str, username, ip)
                    return True
                else:
                    logger.info(failure_str, username, ip)
                    return False
            elif username not in users and '*' in users:
                if ip in users['*'] or '*' in users['*']:
                    logger.info(success_str, username, ip)
                    return True
                else:
                    logger.info(failure_str, username, ip)
                    return False
            else:
                logger.info(failure_str, username, ip)
                return False
    else:
        logger.info(pass_str, username, ip)
        return True