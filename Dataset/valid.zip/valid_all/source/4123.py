def _view_interval(self, queue_type, queue_id):
        """Updates the queue interval in SharQ."""
        response = {
            'status': 'failure'
        }
        try:
            request_data = json.loads(request.data)
            interval = request_data['interval']
        except Exception, e:
            response['message'] = e.message
            return jsonify(**response), 400

        request_data = {
            'queue_type': queue_type,
            'queue_id': queue_id,
            'interval': interval
        }

        try:
            response = self.sq.interval(**request_data)
            if response['status'] == 'failure':
                return jsonify(**response), 404
        except Exception, e:
            response['message'] = e.message
            return jsonify(**response), 400

        return jsonify(**response)