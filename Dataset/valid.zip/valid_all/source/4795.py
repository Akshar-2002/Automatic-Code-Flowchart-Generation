def get_unique_fields(fld_lists):
    """Get unique namedtuple fields, despite potential duplicates in lists of fields."""
    flds = []
    fld_set = set([f for flst in fld_lists for f in flst])
    fld_seen = set()
    # Add unique fields to list of fields in order that they appear
    for fld_list in fld_lists:
        for fld in fld_list:
            # Add fields if the field has not yet been seen
            if fld not in fld_seen:
                flds.append(fld)
                fld_seen.add(fld)
    assert len(flds) == len(fld_set)
    return flds