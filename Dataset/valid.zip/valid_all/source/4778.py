def _coerce_consumer_group(consumer_group):
    """
    Ensure that the consumer group is a text string.

    :param consumer_group: :class:`bytes` or :class:`str` instance
    :raises TypeError: when `consumer_group` is not :class:`bytes`
        or :class:`str`
    """
    if not isinstance(consumer_group, string_types):
        raise TypeError('consumer_group={!r} must be text'.format(consumer_group))
    if not isinstance(consumer_group, text_type):
        consumer_group = consumer_group.decode('utf-8')
    return consumer_group