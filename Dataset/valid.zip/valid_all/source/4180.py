def _get_nest_stats(self):
        """Helper method to deal with nestedStats

        as json format changed in v12.x
        """
        for x in self.rdict:
            check = urlparse(x)
            if check.scheme:
                nested_dict = self.rdict[x]['nestedStats']
                tmp_dict = nested_dict['entries']
                return self._key_dot_replace(tmp_dict)

        return self._key_dot_replace(self.rdict)