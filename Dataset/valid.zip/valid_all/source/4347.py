def retry(self):
		""" Retry payment on this invoice if it isn't paid, closed, or forgiven."""

		if not self.paid and not self.forgiven and not self.closed:
			stripe_invoice = self.api_retrieve()
			updated_stripe_invoice = (
				stripe_invoice.pay()
			)  # pay() throws an exception if the charge is not successful.
			type(self).sync_from_stripe_data(updated_stripe_invoice)
			return True
		return False