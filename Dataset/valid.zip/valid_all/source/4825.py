def cache_infos(self, queryset):
        """
        Cache the number of entries published and the last
        modification date under each tag.
        """
        self.cache = {}
        for item in queryset:
            # If the sitemap is too slow, don't hesitate to do this :
            #   self.cache[item.pk] = (item.count, None)
            self.cache[item.pk] = (
                item.count, TaggedItem.objects.get_by_model(
                    self.entries_qs, item)[0].last_update)