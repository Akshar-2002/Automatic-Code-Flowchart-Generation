def load(self, fname):
        """ .. todo:: REPO.load docstring
        """

        # Imports
        import h5py as h5
        from ..error import RepoError

        # If repo not None, complain
        if not self._repo == None:
            raise RepoError(RepoError.STATUS,
                    "Repository already open",
                    "File: {0}".format(self.fname))
        ## end if

        # If string passed, try opening h5.File; otherwise complain
        if isinstance(fname, str):
            self.fname = fname
            self._repo = h5.File(fname)
        else:
            raise TypeError("Invalid filename type: {0}".format(type(fname)))