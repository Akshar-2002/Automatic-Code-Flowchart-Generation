def del_record(self, dns_record_type, host):
        """Remove a DNS record"""
        rec = self.get_record(dns_record_type, host)
        if rec:
            self._entries = list(set(self._entries) - set([rec]))
        return True