def favorite_remove(self, post_id):
        """Remove a post from favorites (Requires login).

        Parameters:
            post_id (int): Where post_id is the post id.
        """
        return self._get('favorites/{0}.json'.format(post_id), method='DELETE',
                         auth=True)