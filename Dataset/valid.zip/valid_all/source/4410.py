def initiate_migration(self):
        """
        Initiates a pending migration that is already scheduled for this Linode
        Instance
        """
        self._client.post('{}/migrate'.format(Instance.api_endpoint), model=self)