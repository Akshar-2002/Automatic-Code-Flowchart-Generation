def emit_node(self, node):
        """Emit a single node."""
        emit = getattr(self, "%s_emit" % node.kind, self.default_emit)
        return emit(node)