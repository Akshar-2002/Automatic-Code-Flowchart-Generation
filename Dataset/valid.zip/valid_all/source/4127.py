def construct_vdp_dict(self, mode, mgrid, typeid, typeid_ver, vsiid_frmt,
                           vsiid, filter_frmt, gid, mac, vlan, oui_id,
                           oui_data):
        """Constructs the VDP Message.

        Please refer http://www.ieee802.org/1/pages/802.1bg.html VDP
        Section for more detailed information
        :param mode: Associate or De-associate
        :param mgrid: MGR ID
        :param typeid: Type ID
        :param typeid_ver: Version of the Type ID
        :param vsiid_frmt: Format of the following VSI argument
        :param vsiid: VSI value
        :param filter_frmt: Filter Format
        :param gid: Group ID the vNIC belongs to
        :param mac: MAC Address of the vNIC
        :param vlan: VLAN of the vNIC
        :param oui_id: OUI Type
        :param oui_data: OUI Data
        :return vdp_keyword_str: Dictionary of VDP arguments and values
        """
        vdp_keyword_str = {}
        if mgrid is None:
            mgrid = self.vdp_opts.get('mgrid')
        mgrid_str = "mgrid2=%s" % mgrid
        if typeid is None:
            typeid = self.vdp_opts.get('typeid')
        typeid_str = "typeid=%s" % typeid
        if typeid_ver is None:
            typeid_ver = self.vdp_opts.get('typeidver')
        typeid_ver_str = "typeidver=%s" % typeid_ver
        if int(vsiid_frmt) == int(self.vdp_opts.get('vsiidfrmt')):
            vsiid_str = "uuid=%s" % vsiid
        else:
            # Only format supported for now
            LOG.error("Unsupported VSIID Format1")
            return vdp_keyword_str
        if vlan == constants.INVALID_VLAN:
            vlan = 0
        if int(filter_frmt) == vdp_const.VDP_FILTER_GIDMACVID:
            if not mac or gid == 0:
                LOG.error("Incorrect Filter Format Specified")
                return vdp_keyword_str
            else:
                f = "filter=%s-%s-%s"
                filter_str = f % (vlan, mac, gid)
        elif int(filter_frmt) == vdp_const.VDP_FILTER_GIDVID:
            if gid == 0:
                LOG.error("NULL GID Specified")
                return vdp_keyword_str
            else:
                filter_str = "filter=" + '%d' % vlan + "--" + '%ld' % gid
        elif int(filter_frmt) == vdp_const.VDP_FILTER_MACVID:
            if not mac:
                LOG.error("NULL MAC Specified")
                return vdp_keyword_str
            else:
                filter_str = "filter=" + '%d' % vlan + "-" + mac
        elif int(filter_frmt) == vdp_const.VDP_FILTER_VID:
            filter_str = "filter=" + '%d' % vlan
        else:
            LOG.error("Incorrect Filter Format Specified")
            return vdp_keyword_str
        oui_list = []
        if oui_id is not None and oui_data is not None:
            if oui_id is 'cisco':
                oui_list = self.gen_cisco_vdp_oui(oui_id, oui_data)
        mode_str = "mode=" + mode
        vdp_keyword_str = dict(mode=mode_str, mgrid=mgrid_str,
                               typeid=typeid_str, typeid_ver=typeid_ver_str,
                               vsiid=vsiid_str, filter=filter_str,
                               oui_list=oui_list)
        return vdp_keyword_str