def bin_remove(self):
        """Remove Slackware packages
        """
        packages = self.args[1:]
        options = [
            "-r",
            "--removepkg"
        ]
        additional_options = [
            "--deps",
            "--check-deps",
            "--tag",
            "--checklist"
        ]
        flag, extra = "", []
        flags = [
            "-warn",
            "-preserve",
            "-copy",
            "-keep"
        ]
        # merge --check-deps and --deps options
        if (additional_options[1] in self.args and
                additional_options[0] not in self.args):
            self.args.append(additional_options[0])
        if len(self.args) > 1 and self.args[0] in options:
            for additional in additional_options:
                if additional in self.args:
                    extra.append(additional)
                    self.args.remove(additional)
                packages = self.args[1:]
            for fl in flags:
                if fl in self.args:
                    flag = self.args[1]
                    packages = self.args[2:]
            PackageManager(packages).remove(flag, extra)
        else:
            usage("")