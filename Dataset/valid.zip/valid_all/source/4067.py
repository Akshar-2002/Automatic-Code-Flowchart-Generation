def get_user_attempts(request: AxesHttpRequest, credentials: dict = None) -> QuerySet:
    """
    Get valid user attempts that match the given request and credentials.
    """

    attempts = filter_user_attempts(request, credentials)

    if settings.AXES_COOLOFF_TIME is None:
        log.debug('AXES: Getting all access attempts from database because no AXES_COOLOFF_TIME is configured')
        return attempts

    threshold = get_cool_off_threshold(request.axes_attempt_time)
    log.debug('AXES: Getting access attempts that are newer than %s', threshold)
    return attempts.filter(attempt_time__gte=threshold)