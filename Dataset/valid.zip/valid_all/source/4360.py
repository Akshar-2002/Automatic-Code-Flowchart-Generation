def _get_entity_id(field_name, attrs):
    """Find the ID for a one to one relationship.

    The server may return JSON data in the following forms for a
    :class:`nailgun.entity_fields.OneToOneField`::

        'user': None
        'user': {'name': 'Alice Hayes', 'login': 'ahayes', 'id': 1}
        'user_id': 1
        'user_id': None

    Search ``attrs`` for a one to one ``field_name`` and return its ID.

    :param field_name: A string. The name of a field.
    :param attrs: A dict. A JSON payload as returned from a server.
    :returns: Either an entity ID or None.

    """
    field_name_id = field_name + '_id'
    if field_name in attrs:
        if attrs[field_name] is None:
            return None
        elif 'id' in attrs[field_name]:
            return attrs[field_name]['id']
    if field_name_id in attrs:
        return attrs[field_name_id]
    else:
        raise MissingValueError(
            'Cannot find a value for the "{0}" field. Searched for keys named '
            '{1}, but available keys are {2}.'
            .format(field_name, (field_name, field_name_id), attrs.keys())
        )