def newNodeEatName(self, name):
        """Creation of a new node element. @ns is optional (None). """
        ret = libxml2mod.xmlNewNodeEatName(self._o, name)
        if ret is None:raise treeError('xmlNewNodeEatName() failed')
        __tmp = xmlNode(_obj=ret)
        return __tmp