def get_default_property_values(self, classname):
        """Return a dict with default values for all properties declared on this class."""
        schema_element = self.get_element_by_class_name(classname)

        result = {
            property_name: property_descriptor.default
            for property_name, property_descriptor in six.iteritems(schema_element.properties)
        }

        if schema_element.is_edge:
            # Remove the source/destination properties for edges, if they exist.
            result.pop(EDGE_SOURCE_PROPERTY_NAME, None)
            result.pop(EDGE_DESTINATION_PROPERTY_NAME, None)

        return result