def add(self, error):
        """ Add an error to the tree.

        :param error: :class:`~cerberus.errors.ValidationError`
        """
        if not self._path_of_(error):
            self.errors.append(error)
            self.errors.sort()
        else:
            super(ErrorTree, self).add(error)