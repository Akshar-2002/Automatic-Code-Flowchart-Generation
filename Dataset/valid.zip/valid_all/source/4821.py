def create_org_smarthost(self, orgid, data):
        """Create an organization smarthost"""
        return self.api_call(
            ENDPOINTS['orgsmarthosts']['new'],
            dict(orgid=orgid),
            body=data)