def launch_host_event_handler(self, host):
        """Launch event handler for a service
        Format of the line that triggers function call::

        LAUNCH_HOST_EVENT_HANDLER;<host_name>

        :param host: host to execute the event handler
        :type host: alignak.objects.host.Host
        :return: None
        """
        host.get_event_handlers(self.hosts, self.daemon.macromodulations, self.daemon.timeperiods,
                                ext_cmd=True)