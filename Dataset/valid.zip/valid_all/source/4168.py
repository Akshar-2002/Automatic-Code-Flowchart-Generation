def SendUcsFirmware(self, path=None, dumpXml=False):
		"""
		Uploads a specific CCO Image on UCS.
		
		- path specifies the path of the image to be uploaded.
		"""
		from UcsBase import WriteUcsWarning, UcsUtils, ManagedObject, WriteObject, UcsUtils, UcsValidationException, \
			UcsException
		from Ucs import ConfigConfig
		from Mos import FirmwareDownloader

		if (self._transactionInProgress):
			raise UcsValidationException(
				"UCS transaction in progress. Cannot execute SendUcsFirmware. Complete or Undo UCS transaction.")
		# raise Exception("UCS transaction in progress. Cannot execute SendUcsFirmware. Complete or Undo UCS transaction.")

		if not path:
			raise UcsValidationException("path parameter is not provided.")
		# raise Exception("Please provide path")

		if not os.path.exists(path):
			raise UcsValidationException("Image not found <%s>" % (path))
		# raise Exception("Image not found <%s>" %(path))	

		dn = None
		filePath = path
		localFile = os.path.basename(filePath)

		# Exit if image already exist on UCSM 
		topSystem = ManagedObject(NamingId.TOP_SYSTEM)
		firmwareCatalogue = ManagedObject(NamingId.FIRMWARE_CATALOGUE)
		firmwareDistributable = ManagedObject(NamingId.FIRMWARE_DISTRIBUTABLE)
		firmwareDistributable.Name = localFile

		dn = UcsUtils.MakeDn([topSystem.MakeRn(), firmwareCatalogue.MakeRn(), firmwareDistributable.MakeRn()])
		crDn = self.ConfigResolveDn(dn, inHierarchical=YesOrNo.FALSE, dumpXml=dumpXml)

		if (crDn.OutConfig.GetChildCount() > 0):
			raise UcsValidationException("Image file <%s> already exist on FI." % (filePath))
		# raise Exception("Image file <%s> already exist on FI." %(filePath))

		# Create object of type <firmwareDownloader>
		firmwareDownloader = ManagedObject(NamingId.FIRMWARE_DOWNLOADER)
		firmwareDownloader.FileName = localFile
		dn = UcsUtils.MakeDn([topSystem.MakeRn(), firmwareCatalogue.MakeRn(), firmwareDownloader.MakeRn()])

		firmwareDownloader.Dn = dn
		firmwareDownloader.Status = Status.CREATED
		firmwareDownloader.FileName = localFile
		firmwareDownloader.Server = FirmwareDownloader.CONST_PROTOCOL_LOCAL
		firmwareDownloader.Protocol = FirmwareDownloader.CONST_PROTOCOL_LOCAL

		inConfig = ConfigConfig()
		inConfig.AddChild(firmwareDownloader)

		uri = "%s/operations/file-%s/image.txt" % (self.Uri(), localFile)

		progress = Progress()
		stream = file_with_callback(filePath, 'rb', progress.update, filePath)
		request = urllib2.Request(uri)
		request.add_header('Cookie', 'ucsm-cookie=%s' % (self._cookie))
		request.add_data(stream)

		response = urllib2.urlopen(request).read()
		if not response:
			raise UcsValidationException("Unable to upload properly.")
		# WriteUcsWarning("Unable to upload properly.")

		ccm = self.ConfigConfMo(dn=dn, inConfig=inConfig, inHierarchical=YesOrNo.FALSE, dumpXml=dumpXml)
		if (ccm.errorCode != 0):
			raise UcsException(ccm.errorCode, ccm.errorDescr)

		return ccm.OutConfig.GetChild()