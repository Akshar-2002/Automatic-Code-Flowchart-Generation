def read_wavefront(fname_obj):
    """Returns mesh dictionary along with their material dictionary from a wavefront (.obj and/or .mtl) file."""
    fname_mtl = ''
    geoms = read_objfile(fname_obj)
    for line in open(fname_obj):
        if line:
            split_line = line.strip().split(' ', 1)
            if len(split_line) < 2:
                continue

            prefix, data = split_line[0], split_line[1]
            if 'mtllib' in prefix:
                fname_mtl = data
                break

    if fname_mtl:
        materials = read_mtlfile(path.join(path.dirname(fname_obj), fname_mtl))

        for geom in geoms.values():
            geom['material'] = materials[geom['usemtl']]

    return geoms