def __split_genomic_interval_filename(fn):
  """
  Split a filename of the format chrom:start-end.ext or chrom.ext (full chrom).

  :return: tuple of (chrom, start, end) -- 'start' and 'end' are None if not
           present in the filename.
  """
  if fn is None or fn == "":
    raise ValueError("invalid filename: " + str(fn))
  fn = ".".join(fn.split(".")[:-1])
  parts = fn.split(":")
  if len(parts) == 1:
    return (parts[0].strip(), None, None)
  else:
    r_parts = parts[1].split("-")
    if len(r_parts) != 2:
      raise ValueError("Invalid filename: " + str(fn))
    return (parts[0].strip(), int(r_parts[0]), int(r_parts[1]))