def decorate_function(self, name, decorator):
        """
        Decorate function with given name with given decorator.

        :param str name: Name of the function.
        :param callable decorator: Decorator callback.
        """
        self.functions[name] = decorator(self.functions[name])