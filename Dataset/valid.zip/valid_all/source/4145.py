def create_subcommand_synopsis(self, parser):
        """ show usage with description for commands """
        self.add_usage(parser.usage, parser._get_positional_actions(),
                       None, prefix='')
        usage = self._format_usage(parser.usage, parser._get_positional_actions(),
                                   None, '')
        return self._bold(usage)