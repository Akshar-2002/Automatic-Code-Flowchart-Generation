def get_timestats_str(unixtime_list, newlines=1, full=True, isutc=True):
    r"""
    Args:
        unixtime_list (list):
        newlines (bool):

    Returns:
        str: timestat_str

    CommandLine:
        python -m utool.util_time --test-get_timestats_str

    Example:
        >>> # ENABLE_DOCTEST
        >>> from utool.util_time import *  # NOQA
        >>> import utool as ut
        >>> unixtime_list = [0, 0 + 60 * 60 * 5 , 10 + 60 * 60 * 5, 100 + 60 * 60 * 5, 1000 + 60 * 60 * 5]
        >>> newlines = 1
        >>> full = False
        >>> timestat_str = get_timestats_str(unixtime_list, newlines, full=full, isutc=True)
        >>> result = ut.align(str(timestat_str), ':')
        >>> print(result)
        {
            'max'  : '1970/01/01 05:16:40',
            'mean' : '1970/01/01 04:03:42',
            'min'  : '1970/01/01 00:00:00',
            'range': '5:16:40',
            'std'  : '2:02:01',
        }

    Example2:
        >>> # ENABLE_DOCTEST
        >>> from utool.util_time import *  # NOQA
        >>> import utool as ut
        >>> unixtime_list = [0, 0 + 60 * 60 * 5 , 10 + 60 * 60 * 5, 100 + 60 * 60 * 5, 1000 + 60 * 60 * 5, float('nan'), 0]
        >>> newlines = 1
        >>> timestat_str = get_timestats_str(unixtime_list, newlines, isutc=True)
        >>> result = ut.align(str(timestat_str), ':')
        >>> print(result)
        {
            'max'    : '1970/01/01 05:16:40',
            'mean'   : '1970/01/01 03:23:05',
            'min'    : '1970/01/01 00:00:00',
            'nMax'   : 1,
            'nMin'   : 2,
            'num_nan': 1,
            'range'  : '5:16:40',
            'shape'  : (7,),
            'std'    : '2:23:43',
        }

    """
    import utool as ut
    datetime_stats = get_timestats_dict(unixtime_list, full=full, isutc=isutc)
    timestat_str = ut.repr4(datetime_stats, newlines=newlines)
    return timestat_str