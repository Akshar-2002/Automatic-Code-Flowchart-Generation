def iscsi_settings(self):
        """Property to provide reference to iSCSI settings instance

        It is calculated once when the first time it is queried. On refresh,
        this property gets reset.
        """
        return ISCSISettings(
            self._conn, utils.get_subresource_path_by(
                self, ["@Redfish.Settings", "SettingsObject"]),
            redfish_version=self.redfish_version)