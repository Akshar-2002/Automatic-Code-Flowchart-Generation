def set_bool(self, location, value):
        """Set a boolean value.

        Casper booleans in XML are string literals of "true" or "false".
        This method sets the text value of "location" to the correct
        string representation of a boolean.

        Args:
            location: Element or a string path argument to find()
            value: Boolean or string value to set. (Accepts
            "true"/"True"/"TRUE"; all other strings are False).
        """
        element = self._handle_location(location)
        if isinstance(value, basestring):
            value = True if value.upper() == "TRUE" else False
        elif not isinstance(value, bool):
            raise ValueError
        if value is True:
            element.text = "true"
        else:
            element.text = "false"