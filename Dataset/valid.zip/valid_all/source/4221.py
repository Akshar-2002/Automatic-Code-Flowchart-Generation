def clear_further_steps(self):
        """Clear all further steps in order to properly calculate the prev step
        """
        self.parent.step_kw_hazard_category.lstHazardCategories.clear()
        self.parent.step_kw_subcategory.lstSubcategories.clear()
        self.parent.step_kw_layermode.lstLayerModes.clear()
        self.parent.step_kw_unit.lstUnits.clear()
        self.parent.step_kw_field.lstFields.clear()
        self.parent.step_kw_classification.lstClassifications.clear()
        self.parent.step_kw_threshold.classes.clear()

        self.parent.step_kw_multi_classifications.clear()
        self.parent.step_kw_inasafe_fields.clear()
        self.parent.step_kw_default_inasafe_fields.clear()
        self.parent.step_kw_inasafe_raster_default_values.clear()
        self.parent.step_kw_fields_mapping.clear()

        self.parent.step_kw_multi_classifications.clear()