def browse(self, folder, levels=None, prefix=None):
        """ Returns the directory tree of the global model.

            Directories are always JSON objects (map/dictionary), and files are
            always arrays of modification time and size. The first integer is
            the files modification time, and the second integer is the file
            size.

            Args:
                folder (str): The root folder to traverse.
                levels (int): How deep within the tree we want to dwell down.
                    (0 based, defaults to unlimited depth)
                prefix (str): Defines a prefix within the tree where to start
                    building the structure.

            Returns:
                dict
        """
        assert isinstance(levels, int) or levels is None
        assert isinstance(prefix, string_types) or prefix is None
        return self.get('browse', params={'folder': folder,
                                          'levels': levels,
                                          'prefix': prefix})