def alert_type(self, alert_type):
        """Sets the alert_type of this Alert.

        Alert type.  # noqa: E501

        :param alert_type: The alert_type of this Alert.  # noqa: E501
        :type: str
        """
        allowed_values = ["CLASSIC", "THRESHOLD"]  # noqa: E501
        if alert_type not in allowed_values:
            raise ValueError(
                "Invalid value for `alert_type` ({0}), must be one of {1}"  # noqa: E501
                .format(alert_type, allowed_values)
            )

        self._alert_type = alert_type