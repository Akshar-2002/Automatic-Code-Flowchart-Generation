def stop(self, free_resource=False):
        ''' send a stop transfer request to the Aspera sdk, can  be done for:
            cancel - stop an in progress transfer
            free_resource - request to the Aspera sdk free resouces related to trasnfer_id
        '''
        if not self.is_stopped():
            self._is_stopping = True
            try:
                if free_resource or self.is_running(False):
                    if not free_resource:
                        logger.info("StopTransfer called - %s" % self.get_transfer_id())
                    self._is_stopped = faspmanager2.stopTransfer(self.get_transfer_id())
                    if not free_resource:
                        logger.info("StopTransfer returned %s - %s" % (
                                    self._is_stopped, self.get_transfer_id()))
            except Exception as ex:
                self.notify_exception(ex)

            self._is_stopping = False

        return self.is_stopped(False)