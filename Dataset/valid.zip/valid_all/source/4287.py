def create_topic_rule(ruleName, sql, actions, description,
            ruleDisabled=False,
            region=None, key=None, keyid=None, profile=None):
    '''
    Given a valid config, create a topic rule.

    Returns {created: true} if the rule was created and returns
    {created: False} if the rule was not created.

    CLI Example:

    .. code-block:: bash

        salt myminion boto_iot.create_topic_rule my_rule "SELECT * FROM 'some/thing'" \\
            '[{"lambda":{"functionArn":"arn:::::something"}},{"sns":{\\
            "targetArn":"arn:::::something","roleArn":"arn:::::something"}}]'

    '''

    try:
        conn = _get_conn(region=region, key=key, keyid=keyid, profile=profile)
        conn.create_topic_rule(ruleName=ruleName,
                               topicRulePayload={
                                      'sql': sql,
                                      'description': description,
                                      'actions': actions,
                                      'ruleDisabled': ruleDisabled
                               })
        return {'created': True}
    except ClientError as e:
        return {'created': False, 'error': __utils__['boto3.get_error'](e)}