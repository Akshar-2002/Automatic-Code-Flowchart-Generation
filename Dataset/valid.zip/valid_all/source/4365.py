def get_interpolated_value(self, x):
        """
        Returns an interpolated y value for a particular x value.

        Args:
             x: x value to return the y value for

        Returns:
            Value of y at x
        """
        if len(self.ydim) == 1:
            return get_linear_interpolated_value(self.x, self.y, x)
        else:
            return [get_linear_interpolated_value(self.x, self.y[:, k], x)
                    for k in range(self.ydim[1])]