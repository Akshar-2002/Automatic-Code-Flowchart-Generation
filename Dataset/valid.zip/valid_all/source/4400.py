def cmyk_to_rgb(Class, c, m, y, k):
        """CMYK in % to RGB in 0-255
        based on https://www.openprocessing.org/sketch/46231#
        """
        c = float(c)/100.0
        m = float(m)/100.0
        y = float(y)/100.0
        k = float(k)/100.0

        nc = (c * (1-k)) + k
        nm = (m * (1-k)) + k
        ny = (y * (1-k)) + k

        r = int((1-nc) * 255)
        g = int((1-nm) * 255)
        b = int((1-ny) * 255)

        return dict(r=r, g=g, b=b)