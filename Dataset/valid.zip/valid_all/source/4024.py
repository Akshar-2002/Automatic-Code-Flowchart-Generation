def _contains_blinded_text(stats_xml):
    """ Heuristic to determine whether the treebank has blinded texts or not """
    tree = ET.parse(stats_xml)
    root = tree.getroot()
    total_tokens = int(root.find('size/total/tokens').text)
    unique_lemmas = int(root.find('lemmas').get('unique'))

    # assume the corpus is largely blinded when there are less than 1% unique tokens
    return (unique_lemmas / total_tokens) < 0.01