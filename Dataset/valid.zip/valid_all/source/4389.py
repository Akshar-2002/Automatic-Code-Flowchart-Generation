def symlink_exists(self, symlink):
        """Checks whether a symbolic link exists in the guest.

        in symlink of type str
            Path to the alleged symbolic link.  Guest path style.

        return exists of type bool
            Returns @c true if the symbolic link exists.  Returns @c false if it
            does not exist, if the file system object identified by the path is
            not a symbolic link, or if the object type is inaccessible to the
            user, or if the @a symlink argument is empty.

        raises :class:`OleErrorNotimpl`
            The method is not implemented yet.
        
        """
        if not isinstance(symlink, basestring):
            raise TypeError("symlink can only be an instance of type basestring")
        exists = self._call("symlinkExists",
                     in_p=[symlink])
        return exists