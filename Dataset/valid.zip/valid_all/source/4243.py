def parse_done(self, buf: memoryview) -> Tuple[bool, memoryview]:
        """Parse the continuation line sent by the client to end the ``IDLE``
        command.

        Args:
            buf: The continuation line to parse.

        """
        match = self._pattern.match(buf)
        if not match:
            raise NotParseable(buf)
        done = match.group(1).upper() == self.continuation
        buf = buf[match.end(0):]
        return done, buf