def _read_mptcp_dss(self, bits, size, kind):
        """Read Data Sequence Signal (Data ACK and Data Sequence Mapping) option.

        Positional arguments:
            * bits - str, 4-bit data
            * size - int, length of option
            * kind - int, 30 (Multipath TCP)

        Returns:
            * dict -- extracted Data Sequence Signal (DSS) option

        Structure of DSS [RFC 6824]:
                                 1                   2                   3
             0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
            +---------------+---------------+-------+----------------------+
            |     Kind      |    Length     |Subtype| (reserved) |F|m|M|a|A|
            +---------------+---------------+-------+----------------------+
            |           Data ACK (4 or 8 octets, depending on flags)       |
            +--------------------------------------------------------------+
            |   Data sequence number (4 or 8 octets, depending on flags)   |
            +--------------------------------------------------------------+
            |              Subflow Sequence Number (4 octets)              |
            +-------------------------------+------------------------------+
            |  Data-Level Length (2 octets) |      Checksum (2 octets)     |
            +-------------------------------+------------------------------+

                                1                   2                   3
             0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1 2 3 4 5 6 7 8 9 0 1
            +--------------------------------------------------------------+
            |                                                              |
            |                Data Sequence Number (8 octets)               |
            |                                                              |
            +--------------------------------------------------------------+
            |              Subflow Sequence Number (4 octets)              |
            +-------------------------------+------------------------------+
            |  Data-Level Length (2 octets) |        Zeros (2 octets)      |
            +-------------------------------+------------------------------+

            Octets      Bits        Name                        Description
              0           0     tcp.mp.kind                 Kind (30)
              1           8     tcp.mp.length               Length
              2          16     tcp.mp.subtype              Subtype (2)
              2          20     -                           Reserved (must be zero)
              3          27     tcp.mp.dss.flags.fin        DATA_FIN (F)
              3          28     tcp.mp.dss.flags.dsn_len    DSN Length (m)
              3          29     tcp.mp.dss.flags.data_pre   DSN, SSN, Data-Level Length, CHKSUM Present (M)
              3          30     tcp.mp.dss.flags.ack_len    ACK Length (a)
              3          31     tcp.mp.dss.flags.ack_pre    Data ACK Present (A)
              4          32     tcp.mp.dss.ack              Data ACK (4/8 octets)
              8-12    64-96     tcp.mp.dss.dsn              DSN (4/8 octets)
              12-20  48-160     tcp.mp.dss.ssn              Subflow Sequence Number
              16-24 128-192     tcp.mp.dss.dl_len           Data-Level Length
              18-26 144-208     tcp.mp.dss.checksum         Checksum

        """
        bits = self._read_binary(1)
        mflg = 8 if int(bits[4]) else 4
        Mflg = True if int(bits[5]) else False
        aflg = 8 if int(bits[6]) else 4
        Aflg = True if int(bits[7]) else False
        ack_ = self._read_fileng(aflg) if Aflg else None
        dsn_ = self._read_unpack(mflg) if Mflg else None
        ssn_ = self._read_unpack(4) if Mflg else None
        dll_ = self._read_unpack(2) if Mflg else None
        chk_ = self._read_fileng(2) if Mflg else None

        data = dict(
            kind=kind,
            length=size + 1,
            subtype='DSS',
            dss=dict(
                flags=dict(
                    fin=True if int(bits[3]) else False,
                    dsn_len=mflg,
                    data_pre=Mflg,
                    ack_len=aflg,
                    ack_pre=Aflg,
                ),
                ack=ack_,
                dsn=dsn_,
                ssn=ssn_,
                dl_len=dll_,
                checksum=chk_,
            ),
        )

        return data