def emitRecordClicked(self, item):
        """
        Emits the record clicked signal for the given item, provided the
        signals are not currently blocked.
        
        :param      item | <QTreeWidgetItem>
        """
        # load the next page
        if isinstance(item, XBatchItem):
            item.startLoading()
            self.clearSelection()
            
        # emit that the record has been clicked
        if isinstance(item, XOrbRecordItem) and not self.signalsBlocked():
            self.recordClicked.emit(item.record())