def getRemainingCredits(self):
        """
        Returns the remaining credits for the license key used after the request was made

        :return:
            String with remaining credits
        """

        if 'status' in self._response.keys():
            if (self._response['status'] is not None) and ('remaining_credits' in self._response['status'].keys()):
                if self._response['status']['remaining_credits'] is not None:
                    return self._response['status']['remaining_credits']
                else:
                    return ''
            else:
                print("Not remaining credits field\n")
        else:
            return None