def add(self, path):
        """Add a path to the overlay filesytem.

        Any filesystem operation involving the this path or any sub-paths
        of it will be transparently redirected to temporary root dir.

        @path: An absolute path string.
        """
        if not path.startswith(os.sep):
            raise ValueError("Non-absolute path '{}'".format(path))
        path = path.rstrip(os.sep)
        while True:
            self._paths[path] = None
            path, _ = os.path.split(path)
            if path == os.sep:
                break