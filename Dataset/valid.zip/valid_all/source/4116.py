def validate(self):
        """
        validates the feature configuration, and returns a list of errors (empty list if no error)

        validate should:

        * required variables
        * warn on unused variables

        errors should either be reported via self._log_error(), or raise an exception
        """
        if self.target:
            for k in self.target.keys():
                if k in self.deprecated_options:
                    self.logger.warn(
                        self.deprecated_options[k].format(option=k, feature=self.feature_name))
                elif (k not in self.valid_options and k not in self.required_options and
                      '*' not in self.valid_options):
                    self.logger.warn("Unused option %s in %s!" % (k, self.feature_name))
            for k in self.required_options:
                if not self.target.has(k):
                    self._log_error(
                        "Required option %s not present in feature %s!" % (k, self.feature_name))