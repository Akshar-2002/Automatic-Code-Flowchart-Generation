def send(self, jsonstr):
        """
        Send jsonstr to the UDP collector

        >>> logger = UDPLogger()
        >>> logger.send('{"key": "value"}')
        """
        udp_sock = socket(AF_INET, SOCK_DGRAM)
        udp_sock.sendto(jsonstr.encode('utf-8'), self.addr)