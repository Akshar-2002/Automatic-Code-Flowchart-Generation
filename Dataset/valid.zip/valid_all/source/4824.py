def parse_function(
        name: str,
        target: typing.Callable
) -> typing.Union[None, dict]:
    """
    Parses the documentation for a function, which is specified by the name of
    the function and the function itself.

    :param name:
        Name of the function to parse
    :param target:
        The function to parse into documentation
    :return:
        A dictionary containing documentation for the specified function, or
        None if the target was not a function.
    """

    if not hasattr(target, '__code__'):
        return None

    lines = get_doc_entries(target)
    docs = ' '.join(filter(lambda line: not line.startswith(':'), lines))
    params = parse_params(target, lines)
    returns = parse_returns(target, lines)

    return dict(
        name=getattr(target, '__name__'),
        doc=docs,
        params=params,
        returns=returns
    )