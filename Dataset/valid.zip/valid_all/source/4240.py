def protocol(self):
        """The iperf3 instance protocol

        valid protocols are 'tcp' and 'udp'

        :rtype: str
        """
        proto_id = self.lib.iperf_get_test_protocol_id(self._test)

        if proto_id == SOCK_STREAM:
            self._protocol = 'tcp'
        elif proto_id == SOCK_DGRAM:
            self._protocol = 'udp'

        return self._protocol