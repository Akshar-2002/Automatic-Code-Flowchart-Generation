def setDictionary(self, data):
		"""
		Overwrites the entire dictionary
		"""
		
		# Create the directory containing the JSON file if it doesn't already exist
		jsonDir = os.path.dirname(self.jsonFile)
		if os.path.exists(jsonDir) == False:
			os.makedirs(jsonDir)
		
		# Store the dictionary
		Utility.writeFile(self.jsonFile, json.dumps(data))