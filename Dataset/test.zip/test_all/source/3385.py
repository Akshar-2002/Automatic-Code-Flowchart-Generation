def start(users, hosts, func, only_authenticate=False, **kwargs):
    """
    Like run(), but automatically logs into the host before passing
    the host to the callback function.

    :type  users: Account|list[Account]
    :param users: The account(s) to use for logging in.
    :type  hosts: Host|list[Host]
    :param hosts: A list of Host objects.
    :type  func: function
    :param func: The callback function.
    :type  only_authenticate: bool
    :param only_authenticate: don't authorize, just authenticate?
    :type  kwargs: dict
    :param kwargs: Passed to the Exscript.Queue constructor.
    """
    if only_authenticate:
        run(users, hosts, autoauthenticate()(func), **kwargs)
    else:
        run(users, hosts, autologin()(func), **kwargs)