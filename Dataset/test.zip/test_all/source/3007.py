def list_all(self):
        """All items"""
        return list(set(
            item for items in self._routes.values() for item in items
        ))