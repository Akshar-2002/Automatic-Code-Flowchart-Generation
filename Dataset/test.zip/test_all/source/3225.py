def deserialized_objects(self):
        """Returns a generator of deserialized objects.
        """
        if not self._deserialized_objects:
            json_text = self.read()
            self._deserialized_objects = self.deserialize(json_text=json_text)
        return self._deserialized_objects