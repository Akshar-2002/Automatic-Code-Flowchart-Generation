def create(filename: str, layers: Union[np.ndarray, Dict[str, np.ndarray], loompy.LayerManager], row_attrs: Union[loompy.AttributeManager, Dict[str, np.ndarray]], col_attrs: Union[loompy.AttributeManager, Dict[str, np.ndarray]], *, file_attrs: Dict[str, str] = None) -> None:
	"""
	Create a new Loom file from the given data.

	Args:
		filename (str):         The filename (typically using a ``.loom`` file extension)
		layers:					One of the following:

								* Two-dimensional (N-by-M) numpy ndarray of float values
								* Sparse matrix (e.g. :class:`scipy.sparse.csr_matrix`)
								* Dictionary of named layers, each an N-by-M ndarray or sparse matrix
								* A :class:`.LayerManager`, with each layer an N-by-M ndarray
		row_attrs (dict):       Row attributes, where keys are attribute names and values
								are numpy arrays (float or string) of length N
		col_attrs (dict):       Column attributes, where keys are attribute names and
								values are numpy arrays (float or string) of length M
		file_attrs (dict):      Global attributes, where keys are attribute names and
								values are strings
	Returns:
		Nothing

	Remarks:
		If the file exists, it will be overwritten.
	"""

	if isinstance(row_attrs, loompy.AttributeManager):
		row_attrs = {k: v[:] for k, v in row_attrs.items()}
	if isinstance(col_attrs, loompy.AttributeManager):
		col_attrs = {k: v[:] for k, v in col_attrs.items()}

	if isinstance(layers, np.ndarray) or scipy.sparse.issparse(layers):
		layers = {"": layers}
	elif isinstance(layers, loompy.LayerManager):
		layers = {k: v[:, :] for k, v in layers.items()}
	if "" not in layers:
		raise ValueError("Data for default layer must be provided")

	# Sanity checks
	shape = layers[""].shape  # type: ignore
	if shape[0] == 0 or shape[1] == 0:
		raise ValueError("Main matrix cannot be empty")
	for name, layer in layers.items():
		if layer.shape != shape:  # type: ignore
			raise ValueError(f"Layer '{name}' is not the same shape as the main matrix")
	for name, ra in row_attrs.items():
		if ra.shape[0] != shape[0]:
			raise ValueError(f"Row attribute '{name}' is not the same length ({ra.shape[0]}) as number of rows in main matrix ({shape[0]})")
	for name, ca in col_attrs.items():
		if ca.shape[0] != shape[1]:
			raise ValueError(f"Column attribute '{name}' is not the same length ({ca.shape[0]}) as number of columns in main matrix ({shape[1]})")

	try:
		with new(filename, file_attrs=file_attrs) as ds:
			for key, vals in layers.items():
				ds.layer[key] = vals

			for key, vals in row_attrs.items():
				ds.ra[key] = vals

			for key, vals in col_attrs.items():
				ds.ca[key] = vals

	except ValueError as ve:
		#ds.close(suppress_warning=True) # ds does not exist here
		if os.path.exists(filename):
			os.remove(filename)
		raise ve