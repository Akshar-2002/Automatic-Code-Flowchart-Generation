def save_formatted_data(self, data):
        """
        This will save the formatted data as a repr object (see returns.py)
        :param data: dict of the return data
        :return: None
        """
        self.data = data
        self._timestamps['process'] = time.time()
        self._stage = STAGE_DONE_DATA_FORMATTED