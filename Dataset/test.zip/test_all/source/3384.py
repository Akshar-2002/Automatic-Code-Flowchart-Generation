def launch(self, args, unknown):
        """Launch something according to the provided arguments

        :param args: arguments from the launch parser
        :type args: Namespace
        :param unknown: list of unknown arguments
        :type unknown: list
        :returns: None
        :rtype: None
        :raises: SystemExit
        """
        pm = plugins.PluginManager.get()
        addon = pm.get_plugin(args.addon)
        isgui = isinstance(addon, plugins.JB_StandaloneGuiPlugin)
        if isgui:
            gui.main.init_gui()
        print "Launching %s..." % args.addon
        addon.run()
        if isgui:
            app = gui.main.get_qapp()
            sys.exit(app.exec_())