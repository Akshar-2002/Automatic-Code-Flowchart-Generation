def ekacld(handle, segno, column, dvals, entszs, nlflgs, rcptrs, wkindx):
    """
    Add an entire double precision column to an EK segment.

    http://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/cspice/ekacld_c.html

    :param handle: EK file handle.
    :type handle: int
    :param segno: Number of segment to add column to.
    :type segno: int
    :param column: Column name.
    :type column: str
    :param dvals: Double precision values to add to column.
    :type dvals: Array of floats
    :param entszs: Array of sizes of column entries.
    :type entszs: Array of ints
    :param nlflgs: Array of null flags for column entries.
    :type nlflgs: Array of bools
    :param rcptrs: Record pointers for segment.
    :type rcptrs: Array of ints
    :param wkindx: Work space for column index.
    :type wkindx: Array of ints
    :return: Work space for column index.
    :rtype: Array of ints
    """
    handle = ctypes.c_int(handle)
    segno = ctypes.c_int(segno)
    column = stypes.stringToCharP(column)
    dvals = stypes.toDoubleVector(dvals)
    entszs = stypes.toIntVector(entszs)
    nlflgs = stypes.toIntVector(nlflgs)
    rcptrs = stypes.toIntVector(rcptrs)
    wkindx = stypes.toIntVector(wkindx)
    libspice.ekacld_c(handle, segno, column, dvals, entszs, nlflgs, rcptrs,
                      wkindx)
    return stypes.cVectorToPython(wkindx)