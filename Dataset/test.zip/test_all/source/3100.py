def rotate_around_vector_v3(v, angle_rad, norm_vec):
    """ rotate v around norm_vec by angle_rad."""
    cos_val = math.cos(angle_rad)
    sin_val = math.sin(angle_rad)
    ## (v * cosVal) +
    ## ((normVec * v) * (1.0 - cosVal)) * normVec +
    ## (v ^ normVec) * sinVal)
    #line1: scaleV3(v,cosVal)
    #line2: dotV3( scaleV3( dotV3(normVec,v), 1.0-cosVal), normVec)
    #line3: scaleV3( crossV3( v,normVec), sinVal)
    #a = scaleV3(v,cosVal)
    #b = scaleV3( normVec, dotV3(normVec,v) * (1.0-cosVal))
    #c = scaleV3( crossV3( v,normVec), sinVal)
    return add_v3(
        add_v3(scale_v3(v, cos_val),
               scale_v3(norm_vec, dot_v3(norm_vec, v) * (1.0 - cos_val))),
        scale_v3(cross_v3(v, norm_vec), sin_val)
    )