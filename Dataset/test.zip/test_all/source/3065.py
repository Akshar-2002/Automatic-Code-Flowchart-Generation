def getAsKmlPngAnimation(self, session, projectFile=None, path=None, documentName=None, colorRamp=None, alpha=1.0,
                              noDataValue=0, drawOrder=0, cellSize=None, resampleMethod='NearestNeighbour'):
        """
        Retrieve the WMS dataset as a PNG time stamped KMZ

        Args:
            session (:mod:`sqlalchemy.orm.session.Session`): SQLAlchemy session object bound to PostGIS enabled database.
            projectFile(:class:`gsshapy.orm.ProjectFile`): Project file object for the GSSHA project to which the WMS dataset belongs.
            path (str, optional): Path to file where KML file will be written. Defaults to None.
            documentName (str, optional): Name of the KML document. This will be the name that appears in the legend.
                Defaults to 'Stream Network'.
            colorRamp (:mod:`mapkit.ColorRampGenerator.ColorRampEnum` or dict, optional): Use ColorRampEnum to select a
                default color ramp or a dictionary with keys 'colors' and 'interpolatedPoints' to specify a custom color
                ramp. The 'colors' key must be a list of RGB integer tuples (e.g.: (255, 0, 0)) and the
                'interpolatedPoints' must be an integer representing the number of points to interpolate between each
                color given in the colors list.
            alpha (float, optional): Set transparency of visualization. Value between 0.0 and 1.0 where 1.0 is 100%
                opaque and 0.0 is 100% transparent. Defaults to 1.0.
            noDataValue (float, optional): The value to treat as no data when generating visualizations of rasters.
                Defaults to 0.0.
            drawOrder (int, optional): Set the draw order of the images. Defaults to 0.
            cellSize (float, optional): Define the cell size in the units of the project projection at which to resample
                the raster to generate the PNG. Defaults to None which will cause the PNG to be generated with the
                original raster cell size. It is generally better to set this to a size smaller than the original cell
                size to obtain a higher resolution image. However, computation time increases exponentially as the cell
                size is decreased.
            resampleMethod (str, optional): If cellSize is set, this method will be used to resample the raster. Valid
                values include: NearestNeighbour, Bilinear, Cubic, CubicSpline, and Lanczos. Defaults to
                NearestNeighbour.

        Returns:
            (str, list): Returns a KML string and a list of binary strings that are the PNG images.
        """
        # Prepare rasters
        timeStampedRasters = self._assembleRasterParams(projectFile, self.rasters)

        # Make sure the raster field is valid
        converter = RasterConverter(sqlAlchemyEngineOrSession=session)

        # Configure color ramp
        if isinstance(colorRamp, dict):
            converter.setCustomColorRamp(colorRamp['colors'], colorRamp['interpolatedPoints'])
        else:
            converter.setDefaultColorRamp(colorRamp)

        if documentName is None:
            documentName = self.fileExtension

        kmlString, binaryPngStrings = converter.getAsKmlPngAnimation(tableName=WMSDatasetRaster.tableName,
                                                                     timeStampedRasters=timeStampedRasters,
                                                                     rasterIdFieldName='id',
                                                                     rasterFieldName='raster',
                                                                     documentName=documentName,
                                                                     alpha=alpha,
                                                                     drawOrder=drawOrder,
                                                                     cellSize=cellSize,
                                                                     noDataValue=noDataValue,
                                                                     resampleMethod=resampleMethod)

        if path:
            directory = os.path.dirname(path)
            archiveName = (os.path.split(path)[1]).split('.')[0]
            kmzPath = os.path.join(directory, (archiveName + '.kmz'))

            with ZipFile(kmzPath, 'w') as kmz:
                kmz.writestr(archiveName + '.kml', kmlString)

                for index, binaryPngString in enumerate(binaryPngStrings):
                    kmz.writestr('raster{0}.png'.format(index), binaryPngString)

        return kmlString, binaryPngStrings