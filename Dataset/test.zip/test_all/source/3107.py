def copy(self):
        """Return a "clean" copy of this instance.

        Return:
            (instance): A clean copy of this instance.
        """
        resource = copy.copy(self)

        # workaround for bytes/str issue in Py3 with copy of instance
        # TypeError: a bytes-like object is required, not 'str' (ssl.py)
        resource._request = self.tcex.request(self.tcex.session)

        # reset properties of resource
        resource.copy_reset()

        # Preserve settings
        resource.http_method = self.http_method
        if self._request.payload.get('owner') is not None:
            resource.owner = self._request.payload.get('owner')

        # future bcs - these should not need to be reset. correct?
        # resource._request_entity = self._api_entity
        # resource._request_uri = self._api_uri
        return resource