def item_afdeling_adapter(obj, request):
    """
    Adapter for rendering an object of
    :class: `crabpy.gateway.capakey.Afdeling` to json.
    """
    return {
        'id': obj.id,
        'naam': obj.naam,
        'gemeente': {
            'id': obj.gemeente.id,
            'naam': obj.gemeente.naam
        },
        'centroid': obj.centroid,
        'bounding_box': obj.bounding_box
    }