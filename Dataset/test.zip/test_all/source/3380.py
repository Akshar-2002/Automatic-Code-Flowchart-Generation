def _free_up_space(self, size, this_rel_path=None):
        '''If there are not size bytes of space left, delete files
        until there is

        Args:
            size: size of the current file
            this_rel_path: rel_pat to the current file, so we don't delete it.

        '''

        # Amount of space we are over ( bytes ) for next put
        space = self.size + size - self.maxsize

        if space <= 0:
            return

        removes = []

        for row in self.database.execute("SELECT path, size, time FROM files ORDER BY time ASC"):

            if space > 0:
                removes.append(row[0])
                space -= row[1]
            else:
                break

        for rel_path in removes:
            if rel_path != this_rel_path:
                global_logger.debug("Deleting {}".format(rel_path))
                self.remove(rel_path)