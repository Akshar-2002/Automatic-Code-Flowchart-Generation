def appliance_node_information(self):
        """
        Gets the ApplianceNodeInformation API client.

        Returns:
            ApplianceNodeInformation:
        """
        if not self.__appliance_node_information:
            self.__appliance_node_information = ApplianceNodeInformation(self.__connection)
        return self.__appliance_node_information