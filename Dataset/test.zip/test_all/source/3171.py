def format_vk(vk):
    """Format vk before using it"""

    # Force extension require to be a list
    for ext in get_extensions_filtered(vk):
        req = ext['require']
        if not isinstance(req, list):
            ext['require'] = [req]