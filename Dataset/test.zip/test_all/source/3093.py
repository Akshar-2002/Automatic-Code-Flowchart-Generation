def from_cn(cls, common_name):
        """ Retrieve a certificate by its common name. """
        # search with cn
        result_cn = [(cert['id'], [cert['cn']] + cert['altnames'])
                     for cert in cls.list({'status': ['pending', 'valid'],
                                           'items_per_page': 500,
                                           'cn': common_name})]
        # search with altname
        result_alt = [(cert['id'], [cert['cn']] + cert['altnames'])
                      for cert in cls.list({'status': ['pending', 'valid'],
                                            'items_per_page': 500,
                                            'altname': common_name})]

        result = result_cn + result_alt
        ret = {}
        for id_, fqdns in result:
            for fqdn in fqdns:
                ret.setdefault(fqdn, []).append(id_)

        cert_id = ret.get(common_name)
        if not cert_id:
            return

        return cert_id