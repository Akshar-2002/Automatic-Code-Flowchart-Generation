def rtgen_family(self, value):
        """Family setter."""
        self.bytearray[self._get_slicers(0)] = bytearray(c_ubyte(value or 0))