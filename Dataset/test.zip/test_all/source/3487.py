def distort(value):
        """
        Distorts a string by randomly replacing characters in it.

        :param value: a string to distort.

        :return: a distored string.
        """
        value = value.lower()

        if (RandomBoolean.chance(1, 5)):
            value = value[0:1].upper() + value[1:]

        if (RandomBoolean.chance(1, 3)):
            value = value + random.choice(_symbols)

        return value