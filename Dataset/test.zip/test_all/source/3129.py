def update_branch(profile, name, sha):
    """Move a branch's HEAD to a new SHA.

    Args:

        profile
            A profile generated from ``simplygithub.authentication.profile``.
            Such profiles tell this module (i) the ``repo`` to connect to,
            and (ii) the ``token`` to connect with.

        name
            The name of the branch to update.

        sha
            The commit SHA to point the branch's HEAD to.

    Returns:
        A dict with data about the branch.

    """
    ref = "heads/" + name
    data = refs.update_ref(profile, ref, sha)
    return data