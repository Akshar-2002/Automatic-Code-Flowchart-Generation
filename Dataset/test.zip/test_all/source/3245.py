def _transform_list_of_states_to_state(self, state: List[int]) -> State:
        """ 
        Private method which transform a list which contains the state of the gene
        in the models to a State object.

        Examples
        --------

        The model contains 2 genes: operon = {0, 1, 2}
                                    mucuB = {0, 1}
        >>> graph._transform_list_of_states_to_dict_of_states([0, 1])
        {operon: 0, mucuB: 1}
        >>> graph._transform_list_of_states_to_dict_of_states([2, 0])
        {operon: 2, mucuB: 0}
        """
        return State({gene: state[i] for i, gene in enumerate(self.genes)})