def _estimate_param_scan_worker(estimator, params, X, evaluate, evaluate_args,
                                failfast, return_exceptions):
    """ Method that runs estimation for several parameter settings.

    Defined as a worker for parallelization

    """
    # run estimation
    model = None
    try:  # catch any exception
        estimator.estimate(X, **params)
        model = estimator.model
    except KeyboardInterrupt:
        # we want to be able to interactively interrupt the worker, no matter of failfast=False.
        raise
    except:
        e = sys.exc_info()[1]
        if isinstance(estimator, Loggable):
            estimator.logger.warning("Ignored error during estimation: %s" % e)
        if failfast:
            raise  # re-raise
        elif return_exceptions:
            model = e
        else:
            pass  # just return model=None

    # deal with results
    res = []

    # deal with result
    if evaluate is None:  # we want full models
        res.append(model)
    # we want to evaluate function(s) of the model
    elif _types.is_iterable(evaluate):
        values = []  # the function values the model
        for ieval, name in enumerate(evaluate):
            # get method/attribute name and arguments to be evaluated
            #name = evaluate[ieval]
            args = ()
            if evaluate_args is not None:
                args = evaluate_args[ieval]
                # wrap single arguments in an iterable again to pass them.
                if _types.is_string(args):
                    args = (args, )
            # evaluate
            try:
                # try calling method/property/attribute
                value = _call_member(estimator.model, name, failfast, *args)
            # couldn't find method/property/attribute
            except AttributeError as e:
                if failfast:
                    raise e  # raise an AttributeError
                else:
                    value = None  # we just ignore it and return None
            values.append(value)
        # if we only have one value, unpack it
        if len(values) == 1:
            values = values[0]
        res.append(values)
    else:
        raise ValueError('Invalid setting for evaluate: ' + str(evaluate))

    if len(res) == 1:
        res = res[0]
    return res