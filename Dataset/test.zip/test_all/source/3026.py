def _scale_back_response(bqm, response, scalar, ignored_interactions,
                         ignored_variables, ignore_offset):
    """Helper function to scale back the response of sample method"""
    if len(ignored_interactions) + len(
            ignored_variables) + ignore_offset == 0:
        response.record.energy = np.divide(response.record.energy, scalar)
    else:
        response.record.energy = bqm.energies((response.record.sample,
                                               response.variables))
    return response