def get_callable_from_line(self, module_file, lineno):
        """Get the callable that the line number belongs to."""
        module_name = _get_module_name_from_fname(module_file)
        if module_name not in self._modules_dict:
            self.trace([module_file])
        ret = None
        # Sort callables by starting line number
        iobj = sorted(self._modules_dict[module_name], key=lambda x: x["code_id"][1])
        for value in iobj:
            if value["code_id"][1] <= lineno <= value["last_lineno"]:
                ret = value["name"]
            elif value["code_id"][1] > lineno:
                break
        return ret if ret else module_name