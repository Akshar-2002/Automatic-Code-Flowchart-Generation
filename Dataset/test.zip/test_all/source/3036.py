def overlay_gateway_access_lists_ipv6_in_cg_ipv6_acl_in_name(self, **kwargs):
        """Auto Generated Code
        """
        config = ET.Element("config")
        overlay_gateway = ET.SubElement(config, "overlay-gateway", xmlns="urn:brocade.com:mgmt:brocade-tunnels")
        name_key = ET.SubElement(overlay_gateway, "name")
        name_key.text = kwargs.pop('name')
        access_lists = ET.SubElement(overlay_gateway, "access-lists")
        ipv6 = ET.SubElement(access_lists, "ipv6")
        in_cg = ET.SubElement(ipv6, "in")
        ipv6_acl_in_name = ET.SubElement(in_cg, "ipv6-acl-in-name")
        ipv6_acl_in_name.text = kwargs.pop('ipv6_acl_in_name')

        callback = kwargs.pop('callback', self._callback)
        return callback(config)