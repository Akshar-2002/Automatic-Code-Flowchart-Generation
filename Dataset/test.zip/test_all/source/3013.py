def get_item_sh(self, item, roles=None, date_field=None):
        """Add sorting hat enrichment fields"""

        eitem_sh = {}
        created = str_to_datetime(date_field)

        for rol in roles:
            identity = self.get_sh_identity(item, rol)
            eitem_sh.update(self.get_item_sh_fields(identity, created, rol=rol))

            if not eitem_sh[rol + '_org_name']:
                eitem_sh[rol + '_org_name'] = SH_UNKNOWN_VALUE

            if not eitem_sh[rol + '_name']:
                eitem_sh[rol + '_name'] = SH_UNKNOWN_VALUE

            if not eitem_sh[rol + '_user_name']:
                eitem_sh[rol + '_user_name'] = SH_UNKNOWN_VALUE

            # Add the author field common in all data sources
            if rol == self.get_field_author():
                identity = self.get_sh_identity(item, rol)
                eitem_sh.update(self.get_item_sh_fields(identity, created, rol="author"))

                if not eitem_sh['author_org_name']:
                    eitem_sh['author_org_name'] = SH_UNKNOWN_VALUE

                if not eitem_sh['author_name']:
                    eitem_sh['author_name'] = SH_UNKNOWN_VALUE

                if not eitem_sh['author_user_name']:
                    eitem_sh['author_user_name'] = SH_UNKNOWN_VALUE

        return eitem_sh