def __get_query_filters(cls, filters={}, inverse=False):
        """
        Convert a dict with the filters to be applied ({"name1":"value1", "name2":"value2"})
        to a list of query objects which can be used together in a query using boolean
        combination logic.

        :param filters: dict with the filters to be applied
        :param inverse: if True include all the inverse filters (the one starting with *)
        :return: a list of es_dsl 'MatchPhrase' Query objects
                 Ex: [MatchPhrase(name1="value1"), MatchPhrase(name2="value2"), ..]
                 Dict representation of the object: {'match_phrase': {'field': 'home'}}
        """
        query_filters = []

        for name in filters:
            if name[0] == '*' and not inverse:
                # An inverse filter and not inverse mode
                continue
            if name[0] != '*' and inverse:
                # A direct filter and inverse mode
                continue
            field_name = name[1:] if name[0] == '*' else name

            params = {field_name: filters[name]}
            # trying to use es_dsl only and not creating hard coded queries
            query_filters.append(Q('match_phrase', **params))

        return query_filters