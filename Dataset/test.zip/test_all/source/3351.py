def _get_separated_values(self, secondary=False):
        """Separate values between odd and even series stacked"""
        series = self.secondary_series if secondary else self.series
        positive_vals = map(
            sum,
            zip(
                *[
                    serie.safe_values for index, serie in enumerate(series)
                    if index % 2
                ]
            )
        )
        negative_vals = map(
            sum,
            zip(
                *[
                    serie.safe_values for index, serie in enumerate(series)
                    if not index % 2
                ]
            )
        )
        return list(positive_vals), list(negative_vals)