def is_expired(self):
        """
        ``True`` if the signature has an expiration date, and is expired. Otherwise, ``False``
        """
        expires_at = self.expires_at
        if expires_at is not None and expires_at != self.created:
            return expires_at < datetime.utcnow()

        return False