def pay_deliver_notify(self, **deliver_info):
        """
        通知 腾讯发货

        一般形式 ::
            wxclient.pay_delivernotify(
                openid=openid,
                transid=transaction_id,
                out_trade_no=本地订单号,
                deliver_timestamp=int(time.time()),
                deliver_status="1",
                deliver_msg="ok"
            )

        :param 需要签名的的参数
        :return: 支付需要的对象
        """
        params, sign, _ = self._pay_sign_dict(
            add_noncestr=False, add_timestamp=False, **deliver_info
        )

        params['app_signature'] = sign
        params['sign_method'] = 'sha1'

        return self.post(
            url="https://api.weixin.qq.com/pay/delivernotify", data=params
        )