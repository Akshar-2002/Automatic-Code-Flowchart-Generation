def as_tree(self, visitor=None, children=None):
        """ Recursively traverses each tree (starting from each root) in order
            to generate a dictionary-based tree structure of the entire forest.
            Each level of the forest/tree is a list of nodes, and each node
            consists of a dictionary representation, where the entry
            ``children`` (by default) consists of a list of dictionary
            representations of its children.

            Optionally, a `visitor` callback can be used, which is responsible
            for generating a dictionary representation of a given
            :class:`CTENode`. By default, the :meth:`_default_node_visitor` is
            used which generates a dictionary with the current node as well as
            structural properties. See :meth:`_default_node_visitor` for the
            appropriate signature of this callback.

            Optionally, a `children` callback can be used, which is responsible
            for determining which :class:`CTENode`s are children of each visited
            :class:`CTENode`, resulting in a key (by default ``children``) and a
            list of children :class:`CTENode` objects, which are then included
            in the dictionary representation of the currently-visited node. See
            :meth:`_default_node_children` for the appropriate signature of this
            callback.

            For each node visited, the :meth:`CTENode.as_tree` method is invoked
            along with the optional `visitor` and `children` arguments. This
            method, if not overridden, will delegate to :meth:`node_as_tree`,
            which is responsible for invoking the :meth:`visitor` and
            :meth:`children` methods, as well as updating the dictionary
            representation of the node with the representation of the children
            nodes.

            :param visitor: optional function responsible for generating the
                dictionary representation of a node.

            :param children: optional function responsible for generating a
                children key and list for a node.

            :return: a dictionary representation of the structure of the forest.
        """
        return [
            root.as_tree(visitor=visitor, children=children) for root in self.roots()
        ]