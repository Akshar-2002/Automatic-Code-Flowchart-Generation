def load_molecule_in_rdkit_smiles(self, molSize,kekulize=True,bonds=[],bond_color=None,atom_color = {}, size= {} ):
        """
        Loads mol file in rdkit without the hydrogens - they do not have to appear in the final
        figure. Once loaded, the molecule is converted to SMILES format which RDKit appears to
        draw best - since we do not care about the actual coordinates of the original molecule, it
        is sufficient to have just 2D information.
        Some molecules can be problematic to import and steps such as stopping sanitize function can
        be taken. This is done automatically if problems are observed. However, better solutions can
        also be implemented and need more research.
        The molecule is then drawn from SMILES in 2D representation without hydrogens. The drawing is
        saved as an SVG file.
        """

        mol_in_rdkit = self.topology_data.mol #need to reload without hydrogens
        try:
            mol_in_rdkit = Chem.RemoveHs(mol_in_rdkit)
            self.topology_data.smiles = Chem.MolFromSmiles(Chem.MolToSmiles(mol_in_rdkit))
        except ValueError:
            mol_in_rdkit = Chem.RemoveHs(mol_in_rdkit, sanitize = False)
            self.topology_data.smiles = Chem.MolFromSmiles(Chem.MolToSmiles(mol_in_rdkit), sanitize=False)
        self.atom_identities = {}
        i=0
        for atom in self.topology_data.smiles.GetAtoms():
            self.atom_identities[mol_in_rdkit.GetProp('_smilesAtomOutputOrder')[1:].rsplit(",")[i]] = atom.GetIdx()
            i+=1
        mc = Chem.Mol(self.topology_data.smiles.ToBinary())
        if kekulize:
            try:
                Chem.Kekulize(mc)
            except:
                mc = Chem.Mol(self.topology_data.smiles.ToBinary())
        if not mc.GetNumConformers():
            rdDepictor.Compute2DCoords(mc)
        atoms=[]
        colors={}
        for i in range(mol_in_rdkit.GetNumAtoms()):
            atoms.append(i)
            if len(atom_color)==0:
                colors[i]=(1,1,1)
            else:
                colors = atom_color
        drawer = rdMolDraw2D.MolDraw2DSVG(int(molSize[0]),int(molSize[1]))
        drawer.DrawMolecule(mc,highlightAtoms=atoms,highlightBonds=bonds, highlightAtomColors=colors,highlightAtomRadii=size,highlightBondColors=bond_color)
        drawer.FinishDrawing()
        self.svg = drawer.GetDrawingText().replace('svg:','')
        filesvg = open("molecule.svg", "w+")
        filesvg.write(self.svg)