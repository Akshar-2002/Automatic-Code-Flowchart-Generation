def _format_operation_list(operation, parameters):
    """Formats parameters in operation in the way BigQuery expects.

    The input operation will be a query like ``SELECT %s`` and the output
    will be a query like ``SELECT ?``.

    :type operation: str
    :param operation: A Google BigQuery query string.

    :type parameters: Sequence[Any]
    :param parameters: Sequence of parameter values.

    :rtype: str
    :returns: A formatted query string.
    :raises: :class:`~google.cloud.bigquery.dbapi.ProgrammingError`
        if a parameter used in the operation is not found in the
        ``parameters`` argument.
    """
    formatted_params = ["?" for _ in parameters]

    try:
        return operation % tuple(formatted_params)
    except TypeError as exc:
        raise exceptions.ProgrammingError(exc)