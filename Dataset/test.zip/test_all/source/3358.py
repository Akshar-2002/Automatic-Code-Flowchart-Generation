def neighbor_state_get(self, address=None, format='json'):
        """ This method returns the state of peer(s) in a json
        format.

        ``address`` specifies the address of a peer. If not given, the
        state of all the peers return.

        ``format`` specifies the format of the response.
        This parameter must be one of the following.

        - 'json' (default)
        - 'cli'
        """
        show = {
            'params': ['neighbor', 'summary'],
            'format': format,
        }
        if address:
            show['params'].append(address)

        return call('operator.show', **show)