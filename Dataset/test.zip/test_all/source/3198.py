def clock_resized_cb(self, viewer, width, height):
        """This method is called when an individual clock is resized.
        It deletes and reconstructs the placement of the text objects
        in the canvas.
        """
        self.logger.info("resized canvas to %dx%d" % (width, height))
        # add text objects to canvas

        self.canvas.delete_all_objects()

        Text = self.canvas.get_draw_class('text')
        x, y = 20, int(height * 0.55)
        # text object for the time
        self.time_txt = Text(x, y, text='', color=self.color,
                             font=self.font, fontsize=self.largesize,
                             coord='window')
        self.canvas.add(self.time_txt, tag='_time', redraw=False)

        # for supplementary info (date, timezone, etc)
        self.suppl_txt = Text(x, height - 10, text='', color=self.color,
                              font=self.font, fontsize=self.smallsize,
                              coord='window')
        self.canvas.add(self.suppl_txt, tag='_suppl', redraw=False)

        self.canvas.update_canvas(whence=3)