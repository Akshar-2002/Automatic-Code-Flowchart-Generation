def generate_project(self):
        """
        Generate the whole project. Returns True if at least one
        file has been generated, False otherwise."""
        # checks needed properties
        if not self.name or not self.destdir or \
               not os.path.isdir(self.destdir):
            raise ValueError("Empty or invalid property values: run with 'help' command")

        _log("Generating project '%s'" % self.name)
        _log("Destination directory is: '%s'" % self.destdir)

        top = os.path.join(self.destdir, self.name)
        src = os.path.join(top, self.src_name)
        resources = os.path.join(top, self.res_name)
        utils = os.path.join(src, "utils")

        if self.complex:
            models = os.path.join(src, "models")
            ctrls = os.path.join(src, "ctrls")
            views = os.path.join(src, "views")
        else: models = ctrls = views = src

        res = self.__generate_tree(top, src, resources, models, ctrls, views, utils)
        res = self.__generate_classes(models, ctrls, views) or res
        res = self.__mksrc(os.path.join(utils, "globals.py"), templates.glob) or res

        if self.complex: self.templ.update({'model_import' : "from models.application import ApplModel",
                                            'ctrl_import' : "from ctrls.application import ApplCtrl",
                                            'view_import' : "from views.application import ApplView"})
        else: self.templ.update({'model_import' : "from ApplModel import ApplModel",
                                 'ctrl_import' : "from ApplCtrl import ApplCtrl",
                                 'view_import' : "from ApplView import ApplView"})

        res = self.__mksrc(os.path.join(top, "%s.py" % self.name), templates.main) or res

        # builder file
        if self.builder:
            res = self.__generate_builder(resources) or res

        if self.dist_gtkmvc3: res = self.__copy_framework(os.path.join(resources, "external")) or res

        if not res: _log("No actions were taken")
        else: _log("Done")
        return res