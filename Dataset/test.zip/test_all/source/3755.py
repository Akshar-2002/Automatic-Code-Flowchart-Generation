def satisfy_custom_matcher(self, args, kwargs):
        """Return a boolean indicating if the args satisfy the stub

        :return: Whether or not the stub accepts the provided arguments.
        :rtype: bool
        """
        if not self._custom_matcher:
            return False
        try:
            return self._custom_matcher(*args, **kwargs)
        except Exception:
            return False