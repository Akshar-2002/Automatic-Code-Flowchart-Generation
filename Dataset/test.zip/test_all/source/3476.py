def close_session(self, commit=True):
        """Commit and close the DB session associated with this task (no error is raised if None is open)

        Args:
            commit (bool): commit session before closing (default=True)
        """
        if self._session is not None:
            if commit:
                self._session.commit()
            self._session.close()
            self._session = None