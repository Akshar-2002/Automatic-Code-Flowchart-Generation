def on_complete(cls, req):
        """
        Callback called when the request to REST is done. Handles the errors
        and if there is none, :class:`.OutputPicker` is shown.
        """
        # handle http errors
        if not (req.status == 200 or req.status == 0):
            ViewController.log_view.add(req.text)
            alert(req.text)  # TODO: better handling
            return

        try:
            resp = json.loads(req.text)
        except ValueError:
            resp = None

        if not resp:
            alert("Chyba při konverzi!")  # TODO: better
            ViewController.log_view.add(
                "Error while generating MARC: %s" % resp.text
            )
            return

        OutputPicker.show(resp)