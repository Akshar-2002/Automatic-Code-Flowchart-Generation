def visit_keyword(self, node):
        """return an astroid.Keyword node as string"""
        if node.arg is None:
            return "**%s" % node.value.accept(self)
        return "%s=%s" % (node.arg, node.value.accept(self))