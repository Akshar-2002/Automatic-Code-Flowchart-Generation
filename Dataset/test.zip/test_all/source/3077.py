def visitSenseFlags(self, ctx: ShExDocParser.SenseFlagsContext):
        """ '!' '^'? | '^' '!'? """
        if '!' in ctx.getText():
            self.expression.negated = True
        if '^' in ctx.getText():
            self.expression.inverse = True