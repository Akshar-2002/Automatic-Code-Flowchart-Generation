def check_expected_infos(self, test_method):
        """
        This method is called after each test. It will read decorated
        informations and check if there are expected infos.

        You can set expected infos by decorators :py:func:`.expected_info_messages`
        and :py:func:`.allowed_info_messages`.
        """
        f = lambda key, default=[]: getattr(test_method, key, default)
        expected_info_messages = f(EXPECTED_INFO_MESSAGES)
        allowed_info_messages = f(ALLOWED_INFO_MESSAGES)
        self.check_infos(expected_info_messages, allowed_info_messages)