def BGPNeighborPrefixExceeded_originator_switch_info_switchIpV6Address(self, **kwargs):
        """Auto Generated Code
        """
        config = ET.Element("config")
        BGPNeighborPrefixExceeded = ET.SubElement(config, "BGPNeighborPrefixExceeded", xmlns="http://brocade.com/ns/brocade-notification-stream")
        originator_switch_info = ET.SubElement(BGPNeighborPrefixExceeded, "originator-switch-info")
        switchIpV6Address = ET.SubElement(originator_switch_info, "switchIpV6Address")
        switchIpV6Address.text = kwargs.pop('switchIpV6Address')

        callback = kwargs.pop('callback', self._callback)
        return callback(config)