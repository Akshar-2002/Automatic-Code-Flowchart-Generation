def _get_row_str(self, i):
        """
        Returns a string representation of the key information in a row
        """
        row_data = ["{:s}".format(self.data['eventID'][i]),
                    "{:g}".format(self.data['year'][i]),
                    "{:g}".format(self.data['month'][i]),
                    "{:g}".format(self.data['day'][i]),
                    "{:g}".format(self.data['hour'][i]),
                    "{:g}".format(self.data['minute'][i]),
                    "{:.1f}".format(self.data['second'][i]),
                    "{:.3f}".format(self.data['longitude'][i]),
                    "{:.3f}".format(self.data['latitude'][i]),
                    "{:.1f}".format(self.data['depth'][i]),
                    "{:.1f}".format(self.data['magnitude'][i])]
        return " ".join(row_data)