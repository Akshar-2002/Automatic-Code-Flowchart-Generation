def parse_cli_configuration(arguments: List[str]) -> CliConfiguration:
    """
    Parses the configuration passed in via command line arguments.
    :param arguments: CLI arguments
    :return: the configuration
    """
    try:
        parsed_arguments = {x.replace("_", "-"): y for x, y in vars(_argument_parser.parse_args(arguments)).items()}
    except SystemExit as e:
        if e.code == SUCCESS_EXIT_CODE:
            raise e
        raise InvalidCliArgumentError() from e

    parsed_action = parsed_arguments[ACTION_CLI_PARAMETER_ACCESS]
    if parsed_action is None:
        _argument_parser.print_help()
        exit(INVALID_CLI_ARGUMENT_EXIT_CODE)
    action = Action(parsed_action)

    session_ttl = parsed_arguments.get(SESSION_TTL_LONG_PARAMETER, None)
    if session_ttl == NO_EXPIRY_SESSION_TTL_CLI_PARAMETER_VALUE:
        session_ttl = None

    shared_parameters = dict(
        key=parsed_arguments[KEY_PARAMETER],
        log_verbosity=_get_verbosity(parsed_arguments), session_ttl=session_ttl)

    if action == Action.UNLOCK:
        return CliUnlockConfiguration(
            **shared_parameters,
            regex_key_enabled=parsed_arguments.get(REGEX_KEY_ENABLED_SHORT_PARAMETER, DEFAULT_REGEX_KEY_ENABLED))
    else:
        parameters = dict(
            **shared_parameters,
            non_blocking=parsed_arguments.get(NON_BLOCKING_LONG_PARAMETER, DEFAULT_NON_BLOCKING),
            timeout=parsed_arguments.get(TIMEOUT_LONG_PARAMETER, DEFAULT_TIMEOUT),
            metadata=parsed_arguments.get(METADATA_LONG_PARAMETER, DEFAULT_METADATA),
            on_before_locked_executables=list(itertools.chain(*parsed_arguments.get(
                ON_BEFORE_LOCK_LONG_PARAMETER, []))),
            on_lock_already_locked_executables=list(itertools.chain(*parsed_arguments.get(
                ON_LOCK_ALREADY_LOCKED_LONG_PARAMETER, []))),
            lock_poll_interval=parsed_arguments.get(
                LOCK_POLL_INTERVAL_SHORT_PARAMETER, DEFAULT_LOCK_POLL_INTERVAL_GENERATOR(1)))

        if action == Action.LOCK:
            return CliLockConfiguration(**parameters)
        else:
            return CliLockAndExecuteConfiguration(
                **parameters,
                executable=parsed_arguments[EXECUTABLE_PARAMETER])