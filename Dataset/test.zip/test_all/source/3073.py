def _read_name_text(
            self, bufr, platform_id, encoding_id, strings_offset,
            name_str_offset, length):
        """
        Return the unicode name string at *name_str_offset* or |None| if
        decoding its format is not supported.
        """
        raw_name = self._raw_name_string(
            bufr, strings_offset, name_str_offset, length
        )
        return self._decode_name(raw_name, platform_id, encoding_id)