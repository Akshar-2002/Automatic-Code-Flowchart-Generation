def _get_args(self):
        """
        Lazily evaluate the args.
        """
        if not hasattr(self, '_args_evaled'):
            # cache the args in case handler is re-invoked due to flags change
            self._args_evaled = list(chain.from_iterable(self._args))
        return self._args_evaled