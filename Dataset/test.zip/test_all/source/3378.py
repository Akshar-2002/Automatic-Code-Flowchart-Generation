def file_link(self, instance):
        '''
            Renders the link to the student upload file.
        '''
        sfile = instance.file_upload
        if not sfile:
            return mark_safe('No file submitted by student.')
        else:
            return mark_safe('<a href="%s">%s</a><br/>(<a href="%s" target="_new">Preview</a>)' % (sfile.get_absolute_url(), sfile.basename(), sfile.get_preview_url()))