def author(self):
        """
        |  Comment: The id of the user who wrote the article (set to the user who made the request on create by default)
        """
        if self.api and self.author_id:
            return self.api._get_user(self.author_id)