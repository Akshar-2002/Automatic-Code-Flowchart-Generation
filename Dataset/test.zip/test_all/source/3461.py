def extend(self, iterable):
        """Extend the right side of this GeventDeque by appending
        elements from the iterable argument.
        """
        self._deque.extend(iterable)
        if len(self._deque) > 0:
            self.notEmpty.set()