def _run_prospector(filename,
                    stamp_file_name,
                    disabled_linters,
                    show_lint_files):
    """Run prospector."""
    linter_tools = [
        "pep257",
        "pep8",
        "pyflakes"
    ]

    if can_run_pylint():
        linter_tools.append("pylint")

    # Run prospector on tests. There are some errors we don't care about:
    # - invalid-name: This is often triggered because test method names
    #                 can be quite long. Descriptive test method names are
    #                 good, so disable this warning.
    # - super-on-old-class: unittest.TestCase is a new style class, but
    #                       pylint detects an old style class.
    # - too-many-public-methods: TestCase subclasses by definition have
    #                            lots of methods.
    test_ignore_codes = [
        "invalid-name",
        "super-on-old-class",
        "too-many-public-methods"
    ]

    kwargs = dict()

    if _file_is_test(filename):
        kwargs["ignore_codes"] = test_ignore_codes
    else:
        if can_run_frosted():
            linter_tools += ["frosted"]

    return _stamped_deps(stamp_file_name,
                         _run_prospector_on,
                         [filename],
                         linter_tools,
                         disabled_linters,
                         show_lint_files,
                         **kwargs)