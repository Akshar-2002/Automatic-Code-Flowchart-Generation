def update_sensors(self):
        """
        Check path for each sensor and record wall proximity
        """
        assert isinstance(self.player.cshape.center, eu.Vector2)
        pos = self.player.cshape.center

        a = math.radians(self.player.rotation)
        for sensor in self.player.sensors:
            sensor.sensed_type = 'wall'
            rad = a + sensor.angle
            dis = min(self.distance_to_tile(pos, rad), sensor.max_range)

            # Keep state of sensed range, `dis` is from center
            sensor.proximity = dis - self.player.radius

            # Check for collisions with items
            # List of items within sensor range, do for each sensor's range
            if self.mode['items'] and len(self.mode['items']) > 0:
                nears = self.collman.ranked_objs_near(self.player, sensor.max_range)
                for near in nears:
                    other, other_dis = near
                    # Distances are from edge to edge see #2
                    other_dis += self.player.radius
                    # Skip if further
                    if other_dis > dis:
                        continue

                    # Determine if within `fov`
                    other_rad = math.atan2(other.x - self.player.x, other.y - self.player.y)
                    # Round to bearing within one revolution
                    other_rad = other_rad % (math.pi*2)
                    round_rad = rad % (math.pi*2)
                    if abs(other_rad - round_rad) < (sensor.fov/2):
                        sensor.proximity = other_dis - self.player.radius
                        sensor.sensed_type = other.btype
                        dis = other_dis

            # Redirect sensor lines
            # TODO: Decouple into view rendering
            end = pos.copy()
            end.x += math.sin(rad) * dis
            end.y += math.cos(rad) * dis
            sensor.line.start = pos
            sensor.line.end = end
            sensor.line.color = self.player.palette[sensor.sensed_type] + (int(255*0.5),)