def remove_vertex(self, vertex):
        """
        Remove vertex from G
        """
        try:
            self.vertices.pop(vertex)
        except KeyError:
            raise GraphInsertError("Vertex %s doesn't exist." % (vertex,))
        if vertex in self.nodes:
            self.nodes.pop(vertex)
        for element in self.vertices:
            if vertex in self.vertices[element]:
                self.vertices[element].remove(vertex)
        edges = []  # List for edges that include vertex
        for element in self.edges:
            if vertex in element:
                edges.append(element)
        for element in edges:
            del self.edges[element]