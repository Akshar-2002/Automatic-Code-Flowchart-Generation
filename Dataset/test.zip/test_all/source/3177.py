def gen_csv(sc, filename, field_list, source, filters):
    '''csv SecurityCenterObj, AssetListName, CSVFields, EmailAddress
    '''

    # First thing we need to do is initialize the csvfile and build the header
    # for the file.
    datafile = open(filename, 'wb')
    csvfile = csv.writer(datafile)
    header = []
    for field in field_list:
        header.append(fields.fields[field]['name'])
    csvfile.writerow(header)

    debug.write('Generating %s: ' % filename)
    # Next we will run the Security Center query.  because this could be a
    # potentially very large dataset that is returned, we don't want to run out
    # of memory.  To get around this, we will pass the query function the writer
    # function with the appropriate fields so that it is parsed inline.
    fparams = {'fobj': csvfile, 'flist': field_list}
    sc.query('vulndetails', source=source, 
             func=writer, func_params=fparams, **filters)
    debug.write('\n')

    # Lastly we need to close the datafile.
    datafile.close()