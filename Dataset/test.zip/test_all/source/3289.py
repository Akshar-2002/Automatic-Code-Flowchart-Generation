def _bsecurate_cli_compare_basis_sets(args):
    '''Handles compare-basis-sets subcommand'''
    ret = curate.compare_basis_sets(args.basis1, args.basis2, args.version1, args.version2, args.uncontract_general,
          args.data_dir, args.data_dir)
    if ret:
        return "No difference found"
    else:
        return "DIFFERENCES FOUND. SEE ABOVE"