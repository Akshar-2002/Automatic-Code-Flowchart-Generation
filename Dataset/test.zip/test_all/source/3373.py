def ToJson(self):
        """
        Convert object members to a dictionary that can be parsed as JSON.

        Returns:
             dict:
        """
        obj = {
            'usage': self.Usage,
            'data': '' if not self.Data else self.Data.hex()
        }
        return obj