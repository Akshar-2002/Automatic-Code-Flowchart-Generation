def minmax_auto_scale(img, as_uint16):
    """
    Utility function for rescaling all pixel values of input image to fit the range of uint8.
    Rescaling method is min-max, which is all pixel values are normalized to [0, 1] by using img.min() and img.max()
    and then are scaled up by 255 times.
    If the argument `as_uint16` is True, output image dtype is np.uint16 and the range of pixel values is [0, 65535] (scaled up by 65535 after normalized to [0, 1]).

    :param img (numpy.ndarray): input image.
    :param as_uint16: If True, output image dtype is uint16.
    :return: numpy.ndarray
    """

    if as_uint16:
        output_high = 65535
        output_type = np.uint16
    else:
        output_high = 255
        output_type = np.uint8

    return rescale_pixel_intensity(img, input_low=img.min(), input_high=img.max(),
                                   output_low=0, output_high=output_high, output_type=output_type)