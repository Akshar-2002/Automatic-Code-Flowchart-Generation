def set(self, key, value):
        """
        Updates the value of the given key in the loaded content.

        Args:
            key (str): Key of the property to update.
            value (str): New value of the property.

        Return:
            bool: Indicates whether or not a change was made.
        """

        match = self._get_match(key=key)

        if not match:
            self._log.info('"%s" does not exist, so it will be added.', key)

            if isinstance(value, str):
                self._log.info('"%s" will be added as a PHP string value.',
                               key)
                value_str = '\'{}\''.format(value)
            else:
                self._log.info('"%s" will be added as a PHP object value.',
                               key)
                value_str = str(value).lower()

            new = 'define(\'{key}\', {value});'.format(
                key=key,
                value=value_str)

            self._log.info('"%s" will be added as: %s', key, new)

            replace_this = '<?php\n'
            replace_with = '<?php\n' + new + '\n'
            self._content = self._content.replace(replace_this, replace_with)
            self._log.info('Content string has been updated.')
            return True

        if self._get_value_from_match(key=key, match=match) == value:
            self._log.info('"%s" is already up-to-date.', key)
            return False

        self._log.info('"%s" exists and will be updated.', key)

        start_index = match.start(1)
        end_index = match.end(1)

        if isinstance(value, bool):
            value = str(value).lower()
            self._log.info('"%s" will be updated with boolean value: %s',
                           key,
                           value)
        else:
            self._log.info('"%s" will be updated with string value: %s',
                           key,
                           value)

        start = self._content[:start_index]
        end = self._content[end_index:]

        self._content = start + value + end
        return True