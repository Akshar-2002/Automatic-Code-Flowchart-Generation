def dump(obj, fp, *args, **kwargs):
    """Serialize a object to a file object.

    Basic Usage:

    >>> import simplekit.objson
    >>> from cStringIO import StringIO
    >>> obj = {'name': 'wendy'}
    >>> io = StringIO()
    >>> simplekit.objson.dump(obj, io)
    >>> print io.getvalue()

    :param obj: a object which need to dump
    :param fp: a instance of file object
    :param args: Optional arguments that :func:`json.dump` takes.
    :param kwargs: Keys arguments that :func:`json.dump` takes.
    :return: None
    """
    kwargs['default'] = object2dict

    json.dump(obj, fp, *args, **kwargs)