def service_command(name, command):
    """Run an init.d/upstart command."""

    service_command_template = getattr(env, 'ARGYLE_SERVICE_COMMAND_TEMPLATE',
                                       u'/etc/init.d/%(name)s %(command)s')
    sudo(service_command_template % {'name': name,
                                     'command': command}, pty=False)