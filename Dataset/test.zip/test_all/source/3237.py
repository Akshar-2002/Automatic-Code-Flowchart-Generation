def _process_abundance_vector(self, a, z, isomers, yps):
        '''
        This private method takes as input one vector definition and
        processes it, including sorting by charge number and
        mass number. It returns the processed input variables
        plus an element and isotope vector and a list of
        isomers.

        '''
        def cmp_to_key(mycmp):
            'Convert a cmp= function into a key= function'
            class K(object):
                def __init__(self, obj, *args):
                    self.obj = obj
                def __lt__(self, other):
                    return mycmp(self.obj, other.obj) < 0
                def __gt__(self, other):
                    return mycmp(self.obj, other.obj) > 0
                def __eq__(self, other):
                    return mycmp(self.obj, other.obj) == 0
                def __le__(self, other):
                    return mycmp(self.obj, other.obj) <= 0
                def __ge__(self, other):
                    return mycmp(self.obj, other.obj) >= 0
                def __ne__(self, other):
                    return mycmp(self.obj, other.obj) != 0
            return K

        tmp=[]
        isom=[]
        for i in range(len(a)):
            if z[i]!=0 and isomers[i]==1: #if its not 'NEUt and not an isomer'
                tmp.append([self.stable_names[int(z[i])]+'-'+str(int(a[i])),yps[i],z[i],a[i]])
            elif isomers[i]!=1: #if it is an isomer
                if yps[i]==0:
                    isom.append([self.stable_names[int(z[i])]+'-'+str(int(a[i]))+'-'+str(int(isomers[i]-1)),1e-99])
                else:
                    isom.append([self.stable_names[int(z[i])]+'-'+str(int(a[i]))+'-'+str(int(isomers[i]-1)),yps[i]])
        tmp.sort(key = cmp_to_key(self.compar))
        tmp.sort(key = cmp_to_key(self.comparator))
        abunds=[]
        isotope_to_plot=[]
        z_iso_to_plot=[]
        a_iso_to_plot=[]
        el_iso_to_plot=[]
        for i in range(len(tmp)):
            isotope_to_plot.append(tmp[i][0])
            abunds.append(tmp[i][1])
            z_iso_to_plot.append(int(tmp[i][2]))
            a_iso_to_plot.append(int(tmp[i][3]))
            el_iso_to_plot.append(self.stable_names[int(tmp[i][2])])

        return a_iso_to_plot,z_iso_to_plot,abunds,isotope_to_plot,el_iso_to_plot,isom