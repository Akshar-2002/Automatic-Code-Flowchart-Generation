def get_values(self, *args):
        """
        Gets environment variables values.

        Usage::

            >>> environment = Environment("HOME")
            >>> environment.get_values()
            {'HOME': u'/Users/JohnDoe'}
            >>> environment.get_values("USER")
            {'HOME': u'/Users/JohnDoe', 'USER': u'JohnDoe'}

        :param \*args: Additional variables names to retrieve values from.
        :type \*args: \*
        :return: Variables : Values.
        :rtype: dict
        """

        args and self.__add_variables(*args)

        LOGGER.debug("> Object environment variables: '{0}'.".format(
            ",".join((key for key in self.__variables if key))))
        LOGGER.debug("> Available system environment variables: '{0}'".format(os.environ.keys()))

        for variable in self.__variables:
            value = os.environ.get(variable, None)
            self.__variables[variable] = foundations.strings.to_string(value) if value else None
        return self.__variables