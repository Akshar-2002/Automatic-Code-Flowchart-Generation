def n_orifices_per_row_max(self):
        """A bound on the number of orifices allowed in each row.
        The distance between consecutive orifices must be enough to retain
        structural integrity of the pipe.
        """
        c = math.pi * pipe.ID_SDR(self.nom_diam_pipe, self.sdr)
        b = self.orifice_diameter + self.s_orifice

        return math.floor(c/b)