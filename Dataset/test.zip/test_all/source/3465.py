def _credential_allows_container_list(self):
        # type: (StorageAccount) -> bool
        """Check if container list is allowed
        :param StorageAccount self: this
        :rtype: bool
        :return: if container list is allowed
        """
        if self.is_sas:
            sasparts = self.key.split('&')
            caccess = self.can_create_containers
            # search for container signed resource for service level sas
            if not caccess:
                for part in sasparts:
                    tmp = part.split('=')
                    if tmp[0] == 'sr':
                        caccess = 'c' in tmp[1] or 's' in tmp[1]
                        break
                    elif tmp[0] == 'si':
                        # assume sas policies allow container list
                        return True
            # search for list permission
            if caccess:
                for part in sasparts:
                    tmp = part.split('=')
                    if tmp[0] == 'sp':
                        return 'l' in tmp[1]
            # sas doesn't allow container level list
            return False
        else:
            # storage account key always allows container list
            return True