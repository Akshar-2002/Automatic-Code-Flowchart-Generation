def remove_program_temp_directory():
    """Remove the global temp directory and all its contents."""
    if os.path.exists(program_temp_directory):
        max_retries = 3
        curr_retries = 0
        time_between_retries = 1
        while True:
            try:
                shutil.rmtree(program_temp_directory)
                break
            except IOError:
                curr_retries += 1
                if curr_retries > max_retries:
                    raise # re-raise the exception
                time.sleep(time_between_retries)
            except:
                print("Cleaning up temp dir...", file=sys.stderr)
                raise