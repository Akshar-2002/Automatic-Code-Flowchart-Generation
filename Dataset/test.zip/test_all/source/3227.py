def hex2termhex(hexval: str, allow_short: bool = False) -> str:
    """ Convert a hex value into the nearest terminal color matched hex. """
    return rgb2termhex(*hex2rgb(hexval, allow_short=allow_short))