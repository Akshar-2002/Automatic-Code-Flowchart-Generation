def build_cfg(cls, node):
    """Build a CFG for a function.

    Args:
      node: A function definition the body of which to analyze.

    Returns:
      A CFG object.

    Raises:
      TypeError: If the input is not a function definition.
    """
    if not isinstance(node, gast.FunctionDef):
      raise TypeError('input must be a function definition')
    cfg = cls()
    cfg.entry = Node(node.args)
    cfg.head = [cfg.entry]
    cfg.visit_statements(node.body)
    cfg.exit = Node(None)
    cfg.set_head(cfg.exit)
    cfg.backlink(cfg.entry)
    return cfg