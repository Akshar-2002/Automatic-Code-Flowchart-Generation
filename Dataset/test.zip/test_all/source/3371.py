def remove_list_members(self, screen_name=None, user_id=None, slug=None,
                            list_id=None, owner_id=None, owner_screen_name=None):
        """ Perform bulk remove of list members from user ID or screenname """
        return self._remove_list_members(list_to_csv(screen_name),
                                         list_to_csv(user_id),
                                         slug, list_id, owner_id,
                                         owner_screen_name)