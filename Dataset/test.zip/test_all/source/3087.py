def fwdl_status_output_fwdl_entries_blade_slot(self, **kwargs):
        """Auto Generated Code
        """
        config = ET.Element("config")
        fwdl_status = ET.Element("fwdl_status")
        config = fwdl_status
        output = ET.SubElement(fwdl_status, "output")
        fwdl_entries = ET.SubElement(output, "fwdl-entries")
        blade_slot = ET.SubElement(fwdl_entries, "blade-slot")
        blade_slot.text = kwargs.pop('blade_slot')

        callback = kwargs.pop('callback', self._callback)
        return callback(config)