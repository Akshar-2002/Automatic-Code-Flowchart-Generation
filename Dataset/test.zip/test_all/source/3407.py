def popitem_move(self, from_dict, to_dict,
                     priority_min='-inf', priority_max='+inf'):
        '''Select an item and move it to another dictionary.

        The item comes from `from_dict`, and has the lowest score
        at least `priority_min` and at most `priority_max`.  If some
        item is found, remove it from `from_dict`, add it to `to_dict`,
        and return it.

        This runs as a single atomic operation but still requires a
        session lock.

        :param str from_dict: source dictionary
        :param str to_dict: destination dictionary
        :param float priority_min: lowest score
        :param float priority_max: highest score
        :return: pair of (key, value) if an item was moved, or
          :const:`None`

        '''
        if self._session_lock_identifier is None:
            raise ProgrammerError('must acquire lock first')
        conn = redis.Redis(connection_pool=self.pool)
        script = conn.register_script('''
        if redis.call("get", KEYS[1]) == ARGV[1]
        then
            -- find the next key and priority
            local next_items = redis.call("zrangebyscore", KEYS[3],
                ARGV[2], ARGV[3], "WITHSCORES", "LIMIT", 0, 1)
            local next_key = next_items[1]
            local next_priority = next_items[2]
            
            if not next_key then
                return {}
            end

            -- remove next item of from_dict
            redis.call("zrem", KEYS[3], next_key)

            local next_val = redis.call("hget", KEYS[2], next_key)
            -- zrem removed it from list, so also remove from hash
            redis.call("hdel", KEYS[2], next_key)

            -- put it in to_dict
            redis.call("hset", KEYS[4], next_key, next_val)
            redis.call("zadd", KEYS[5], next_priority, next_key)

            return {next_key, next_val, next_priority}
        else
            -- ERROR: No longer own the lock
            return -1
        end
        ''')
        key_value = script(keys=[self._lock_name, 
                                 self._namespace(from_dict),
                                 self._namespace(from_dict) + 'keys',
                                 self._namespace(to_dict),
                                 self._namespace(to_dict) + 'keys'],
                           args=[self._session_lock_identifier,
                                 priority_min, priority_max])

        if key_value == []:
            return None

        if None in key_value or key_value == -1:
            raise KeyError(
                'Registry.popitem_move(%r, %r) --> %r' %
                (from_dict, to_dict, key_value))

        return self._decode(key_value[0]), self._decode(key_value[1])