def list_policies(region=None, key=None, keyid=None, profile=None):
    '''
    List policies.

    CLI Example:

    .. code-block:: bash

        salt myminion boto_iam.list_policies
    '''
    conn = _get_conn(region=region, key=key, keyid=keyid, profile=profile)

    try:
        policies = []
        for ret in __utils__['boto.paged_call'](conn.list_policies):
            policies.append(ret.get('list_policies_response', {}).get('list_policies_result', {}).get('policies'))
        return policies
    except boto.exception.BotoServerError as e:
        log.debug(e)
        msg = 'Failed to list policy versions.'
        log.error(msg)
        return []