def encompassed_by(self, span):
        """
        Returns true if the given span encompasses this span.
        """
        if isinstance(span, list):
            return [sp for sp in span if sp.encompasses(self)]

        return span.encompasses(self)