def create_as(self, klass, name, **attributes):
        """
        Create an instance of the given model and type and persist it to the database.

        :param klass: The class
        :type klass: class

        :param name: The type
        :type name: str

        :param attributes: The instance attributes
        :type attributes: dict

        :return: mixed
        """
        return self.of(klass, name).create(**attributes)