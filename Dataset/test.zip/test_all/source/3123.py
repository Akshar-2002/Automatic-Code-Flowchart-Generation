def _get_token(self, req):
        """ Get the token from the Authorization header

        If the header is actually malformed where Bearer Auth was
        indicated by the request then an InvalidAuthSyntax exception
        is raised. Otherwise an AuthRequired exception since it's
        unclear in this scenario if the requestor was even aware
        Authentication was required & if so which "scheme".

        Calls _validate_auth_scheme first & bubbles up it's
        exceptions.

        :return:
            string token
        :raise:
            AuthRequired, InvalidAuthSyntax
        """

        self._validate_auth_scheme(req)

        try:
            return naked(req.auth.split(' ')[1])
        except IndexError:
            desc = 'You are using the Bearer Authentication scheme as ' \
                   'required to login but your Authorization header is ' \
                   'completely missing the access_token.'

            raise InvalidAuthSyntax(**{
                'detail': desc,
                'headers': self._get_invalid_token_headers(desc),
                'links': 'tools.ietf.org/html/rfc6750#section-2.1',
            })