def _aspirate_plunger_position(self, ul):
        """Calculate axis position for a given liquid volume.

        Translates the passed liquid volume to absolute coordinates
        on the axis associated with this pipette.

        Calibration of the pipette motor's ul-to-mm conversion is required
        """
        millimeters = ul / self._ul_per_mm(ul, 'aspirate')
        destination_mm = self._get_plunger_position('bottom') + millimeters
        return round(destination_mm, 6)