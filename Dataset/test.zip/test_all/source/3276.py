def _get_externalcmd_stats(self, app_stats):
        """
        Process:
         * high_external_command_buffer_slots
         * total_external_command_buffer_slots
         * used_external_command_buffer_slots
         * external_command_stats=
        """
        khigh = "high_external_command_buffer_slots"
        ktotal = "total_external_command_buffer_slots"
        kused = "used_external_command_buffer_slots"
        kstats = "external_command_stats"
        aliases = {
            khigh: "external_command.buffer_high",
            ktotal: "external_command.buffer_total",
            kused: "external_command.buffer_used",
            "x01": "external_command.01",
            "x05": "external_command.05",
            "x15": "external_command.15",
        }
        stats = {}
        if khigh in app_stats.keys() and str(app_stats[khigh]).isdigit():
            key = aliases[khigh]
            stats[key] = int(app_stats[khigh])

        if ktotal in app_stats.keys() and str(app_stats[ktotal].isdigit()):
            key = aliases[ktotal]
            stats[key] = int(app_stats[ktotal])

        if kused in app_stats.keys() and str(app_stats[kused].isdigit()):
            key = aliases[kused]
            stats[key] = int(app_stats[ktotal])

        if kstats in app_stats.keys():
            (x01, x05, x15) = self._convert_tripplet(app_stats[kstats])
            stats[aliases["x01"]] = x01
            stats[aliases["x05"]] = x05
            stats[aliases["x01"]] = x15

        return stats