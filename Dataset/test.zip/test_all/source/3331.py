def pltar(vrtces, plates):
    """
    Compute the total area of a collection of triangular plates.
    
    https://naif.jpl.nasa.gov/pub/naif/toolkit_docs/C/cspice/pltar_c.html
    
    :param vrtces: Array of vertices.
    :type vrtces: Nx3-Element Array of floats
    :param plates: Array of plates. 
    :type plates: Nx3-Element Array of ints
    :return: total area of the set of plates
    :rtype: float
    """
    nv = ctypes.c_int(len(vrtces))
    vrtces = stypes.toDoubleMatrix(vrtces)
    np = ctypes.c_int(len(plates))
    plates = stypes.toIntMatrix(plates)
    return libspice.pltar_c(nv, vrtces, np, plates)