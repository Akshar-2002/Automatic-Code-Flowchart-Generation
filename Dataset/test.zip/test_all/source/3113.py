def create_time_series(self, label_values, func):
        """Create a derived measurement to trac `func`.

        :type label_values: list(:class:`LabelValue`)
        :param label_values: The measurement's label values.

        :type func: function
        :param func: The function to track.

        :rtype: :class:`DerivedGaugePoint`
        :return: A read-only measurement that tracks `func`.
        """
        if label_values is None:
            raise ValueError
        if any(lv is None for lv in label_values):
            raise ValueError
        if len(label_values) != self._len_label_keys:
            raise ValueError
        if func is None:
            raise ValueError
        return self._create_time_series(label_values, func)