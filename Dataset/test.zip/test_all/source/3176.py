def export(self, nidm_version, export_dir):
        """
        Create prov graph.
        """
        # Contrast Map entity
        atts = (
            (PROV['type'], NIDM_CONTRAST_MAP),
            (NIDM_CONTRAST_NAME, self.name))

        if not self.isderfrommap:
            atts = atts + (
                (NIDM_IN_COORDINATE_SPACE, self.coord_space.id),)

        if self.label is not None:
            atts = atts + (
                (PROV['label'], self.label),)

        if self.name is not None:
            atts = atts + (
                (NIDM_CONTRAST_NAME, self.name),)

        # Parameter estimate entity
        self.add_attributes(atts)