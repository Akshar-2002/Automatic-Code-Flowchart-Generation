def delete(self, user_name: str):
        """
        Deletes the resource with the given name.
        """
        user = self._get_or_abort(user_name)
        session.delete(user)
        session.commit()
        return '', 204