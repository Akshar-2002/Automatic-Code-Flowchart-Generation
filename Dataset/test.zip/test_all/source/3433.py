def get_member_calendar(self, max_results=0):

        ''' a method to retrieve the upcoming events for all groups member belongs to

        :param max_results: [optional] integer with number of events to include
        :return: dictionary with list of event details inside [json] key

        event_details = self._reconstruct_event({})
        '''

    # https://www.meetup.com/meetup_api/docs/self/calendar/#list

        title = '%s.get_member_calendar' % self.__class__.__name__

    # validate inputs
        input_fields = {
            'max_results': max_results
        }
        for key, value in input_fields.items():
            if value:
                object_title = '%s(%s=%s)' % (title, key, str(value))
                self.fields.validate(value, '.%s' % key, object_title)

    # construct request fields
        url = '%s/self/calendar' % self.endpoint
        params = {
            'fields': 'comment_count,event_hosts,rsvp_rules,short_link,survey_questions,rsvpable'
        }
        if max_results:
            params['page'] = str(max_results)

    # send requests
        response_details = self._get_request(url, params=params)

    # construct method output
        member_calendar = {
            'json': []
        }
        for key, value in response_details.items():
            if key != 'json':
                member_calendar[key] = value
        for event in response_details['json']:
            member_calendar['json'].append(self._reconstruct_event(event))

        return member_calendar