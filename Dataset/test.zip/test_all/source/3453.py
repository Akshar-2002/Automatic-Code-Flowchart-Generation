def set_or_clear_breakpoint(self):
        """Set/Clear breakpoint"""
        editorstack = self.get_current_editorstack()
        if editorstack is not None:
            self.switch_to_plugin()
            editorstack.set_or_clear_breakpoint()