def get_app_ext(self, loops=float('inf')):
        """ get_app_ext(loops=float('inf'))

        Application extention. This part specifies the amount of loops.
        If loops is 0 or inf, it goes on infinitely.

        """

        if loops == 0 or loops == float('inf'):
            loops = 2**16 - 1
            # bb = ""  # application extension should not be used (the extension interprets zero loops to mean an infinite number of loops) Mmm, does not seem to work
        if True:
            bb = "\x21\xFF\x0B"  # application extension
            bb += "NETSCAPE2.0"
            bb += "\x03\x01"
            bb += int_to_bin(loops)
            bb += '\x00'  # end
        return bb