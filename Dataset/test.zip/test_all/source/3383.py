def intersect(self, enumerable, key=lambda x: x):
        """
        Returns enumerable that is the intersection between given enumerable
        and self
        :param enumerable: enumerable object
        :param key: key selector as lambda expression
        :return: new Enumerable object
        """
        if not isinstance(enumerable, Enumerable3):
            raise TypeError(
                u"enumerable parameter must be an instance of Enumerable")
        return self.join(enumerable, key, key).select(lambda x: x[0])