def RecordEvent(self, metric_name, value, fields=None):
    """See base class."""
    self._event_metrics[metric_name].Record(value, fields)