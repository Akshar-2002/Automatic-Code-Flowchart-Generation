def AtMaximumDepth(self, search_depth):
    """Determines if the find specification is at maximum depth.

    Args:
      search_depth (int): number of location path segments to compare.

    Returns:
      bool: True if at maximum depth, False if not.
    """
    if self._location_segments is not None:
      if search_depth >= self._number_of_location_segments:
        return True

    return False