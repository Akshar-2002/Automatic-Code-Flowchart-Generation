def draw_bounding_boxes(images, annotations, confidence_threshold=0):
    """
    Visualizes bounding boxes (ground truth or predictions) by
    returning annotated copies of the images.

    Parameters
    ----------
    images: SArray or Image
        An `SArray` of type `Image`. A single `Image` instance may also be
        given.

    annotations: SArray or list
        An `SArray` of annotations (either output from the
        `ObjectDetector.predict` function or ground truth). A single list of
        annotations may also be given, provided that it is coupled with a
        single image.

    confidence_threshold: float
        Confidence threshold can limit the number of boxes to draw. By
        default, this is set to 0, since the prediction may have already pruned
        with an appropriate confidence threshold.

    Returns
    -------
    annotated_images: SArray or Image
        Similar to the input `images`, except the images are decorated with
        boxes to visualize the object instances.

    See also
    --------
    unstack_annotations
    """
    _numeric_param_check_range('confidence_threshold', confidence_threshold, 0.0, 1.0)
    from PIL import Image
    def draw_single_image(row):
        image = row['image']
        anns = row['annotations']
        if anns == None:
            anns = []
        elif type(anns) == dict:
            anns = [anns]
        pil_img = Image.fromarray(image.pixel_data)
        _annotate_image(pil_img, anns, confidence_threshold=confidence_threshold)
        image = _np.array(pil_img)
        FORMAT_RAW = 2
        annotated_image = _tc.Image(_image_data=image.tobytes(),
                                    _width=image.shape[1],
                                    _height=image.shape[0],
                                    _channels=image.shape[2],
                                    _format_enum=FORMAT_RAW,
                                    _image_data_size=image.size)
        return annotated_image

    if isinstance(images, _tc.Image) and isinstance(annotations, list):
        return draw_single_image({'image': images, 'annotations': annotations})
    else:
        return (_tc.SFrame({'image': images, 'annotations': annotations})
                .apply(draw_single_image))