def update_labels(self, func):
        """
        Map a function over baseline and adjustment values in place.

        Note that the baseline data values must be a LabelArray.
        """
        if not isinstance(self.data, LabelArray):
            raise TypeError(
                'update_labels only supported if data is of type LabelArray.'
            )

        # Map the baseline values.
        self._data = self._data.map(func)

        # Map each of the adjustments.
        for _, row_adjustments in iteritems(self.adjustments):
            for adjustment in row_adjustments:
                adjustment.value = func(adjustment.value)