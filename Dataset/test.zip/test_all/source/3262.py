def dec(data, **kwargs):
    '''
    Alias to `{box_type}_decrypt`

    box_type: secretbox, sealedbox(default)
    '''
    kwargs['opts'] = __opts__
    return salt.utils.nacl.dec(data, **kwargs)