def getSpecificAssociatedDeviceInfo(self, macAddress, wifiInterfaceId=1, timeout=1):
        """Execute GetSpecificAssociatedDeviceInfo action to get detailed information about a Wifi client.

        :param str macAddress: MAC address in the form ``38:C9:86:26:7E:38``; be aware that the MAC address might
            be case sensitive, depending on the router
        :param int wifiInterfaceId: the id of the Wifi interface
        :param float timeout: the timeout to wait for the action to be executed
        :return: the detailed information's about a Wifi client
        :rtype: WifiDeviceInfo

        .. seealso:: :meth:`~simpletr64.actions.Wifi.getGenericAssociatedDeviceInfo`
        """
        namespace = Wifi.getServiceType("getSpecificAssociatedDeviceInfo") + str(wifiInterfaceId)
        uri = self.getControlURL(namespace)

        results = self.execute(uri, namespace, "GetSpecificAssociatedDeviceInfo", timeout=timeout,
                               NewAssociatedDeviceMACAddress=macAddress)

        return WifiDeviceInfo(results, macAddress=macAddress)