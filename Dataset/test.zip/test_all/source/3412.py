def _send_content(self, content, connection):
        """ Send a content array from the connection """

        if connection:

            if connection.async:
                callback = connection.callbacks['remote']

                if callback:
                    callback(self, self.parent_object, content)

                    self.current_connection.reset()
                    self.current_connection = None
            else:
                return (self, self.parent_object, content)