def get_lateration_parameters(all_points, indices, index, edm, W=None):
    """ Get parameters relevant for lateration from full all_points, edm and W.
    """
    if W is None:
        W = np.ones(edm.shape)

    # delete points that are not considered anchors
    anchors = np.delete(all_points, indices, axis=0)
    r2 = np.delete(edm[index, :], indices)
    w = np.delete(W[index, :], indices)

    # set w to zero where measurements are invalid
    if np.isnan(r2).any():
        nan_measurements = np.where(np.isnan(r2))[0]
        r2[nan_measurements] = 0.0
        w[nan_measurements] = 0.0
    if np.isnan(w).any():
        nan_measurements = np.where(np.isnan(w))[0]
        r2[nan_measurements] = 0.0
        w[nan_measurements] = 0.0

    # delete anchors where weight is zero to avoid ill-conditioning
    missing_anchors = np.where(w == 0.0)[0]
    w = np.asarray(np.delete(w, missing_anchors))
    r2 = np.asarray(np.delete(r2, missing_anchors))
    w.resize(edm.shape[0] - len(indices) - len(missing_anchors), 1)
    r2.resize(edm.shape[0] - len(indices) - len(missing_anchors), 1)
    anchors = np.delete(anchors, missing_anchors, axis=0)
    assert w.shape[0] == anchors.shape[0]
    assert np.isnan(w).any() == False
    assert np.isnan(r2).any() == False
    return anchors, w, r2