def _create_axes(hist: HistogramBase, vega: dict, kwargs: dict):
    """Create axes in the figure."""
    xlabel = kwargs.pop("xlabel", hist.axis_names[0])
    ylabel = kwargs.pop("ylabel", hist.axis_names[1] if len(hist.axis_names) >= 2 else None)
    vega["axes"] = [
        {"orient": "bottom", "scale": "xscale", "title": xlabel},
        {"orient": "left", "scale": "yscale", "title": ylabel}
    ]