def localize_file(path_or_buffer):
    '''Ensure localize target file.

    If the target file is remote, this function fetches into local storage.

    Args:
        path (str):
            File path or file like object or URL of target file.

    Returns:
        filename (str): file name in local storage
        temporary_file_flag (bool): temporary file flag
    '''

    path_or_buffer = _stringify_path(path_or_buffer)

    if _is_url(path_or_buffer):
        req = urlopen(path_or_buffer)
        filename = os.path.basename(req.geturl())
        if os.path.splitext(filename)[-1] is not ".pdf":
            pid = os.getpid()
            filename = "{0}.pdf".format(pid)

        with open(filename, 'wb') as f:
            shutil.copyfileobj(req, f)

        return filename, True

    elif is_file_like(path_or_buffer):
        pid = os.getpid()
        filename = "{0}.pdf".format(pid)

        with open(filename, 'wb') as f:
            shutil.copyfileobj(path_or_buffer, f)

        return filename, True

    # File path case
    else:
        return os.path.expanduser(path_or_buffer), False