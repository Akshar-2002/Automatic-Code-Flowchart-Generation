def resolve_selector(self):
        """Resolve the selector variable in place
        """
        effective_selector_list = []

        for current_selector in self._selector_list:

            # INLINE SELECTOR
            if self.get_type(current_selector) != 'selector_variable':
                effective_selector_list.append(current_selector)

            # SELECTOR VARIABLE
            else:
                # Make sure the proxy driver have a selector dictionary
                if self.get_type(current_selector) == 'selector_variable':
                    if not BROME_CONFIG['selector_dict']:
                        raise Exception("""
                            You must provide a selector dictionary if you want
                            to use the selector variable type
                        """)

                # Make sure that the selector dictionary
                # contains the selector variable
                if self._get_selector(current_selector) \
                        not in BROME_CONFIG['selector_dict']:
                    raise Exception("""
                        Cannot find the selector variable (%s)
                        in the selector dictionary
                    """ % self._get_selector(current_selector))

                effective_selector = BROME_CONFIG['selector_dict'][self._get_selector(current_selector)]  # noqa
                if type(effective_selector) is dict:
                    current_browser_id = False

                    keys = [key for key in effective_selector.keys()
                            if key not in ['default', 'hr']]

                    for key in keys:
                        for target in key.split('|'):
                            try:
                                re.search(
                                    target.lower(), self._pdriver.get_id().lower()
                                ).group(0)
                                current_browser_id = key
                            except AttributeError:
                                pass

                    if current_browser_id:
                        effective_selector_list.append(
                            effective_selector.get(current_browser_id)
                        )
                    else:
                        effective_selector_list.append(
                            effective_selector.get('default')
                        )

                else:
                    if self.get_type(effective_selector) in \
                            [value for key, value in SELECTOR_DICT.items()
                                if key != 'selector_variable']:
                        effective_selector_list.append(effective_selector)
                    else:
                        raise Exception("""
                            All selector need to start with either:
                                'nm:' (name), 'xp:' (xpath), 'cn:' (classname),
                                'id:' (id), 'cs:' (css), 'tn:' (tag name),
                                'lt:' (link text), 'pl:' (partial link text)
                        """)

        return effective_selector_list