def add(self, resource, replace=False):
        """Add just a single resource."""
        uri = resource.uri
        if (uri in self and not replace):
            raise ResourceSetDupeError(
                "Attempt to add resource already in this set")
        self[uri] = resource