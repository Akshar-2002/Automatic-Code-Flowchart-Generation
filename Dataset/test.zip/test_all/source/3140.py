def prepare_policy_template(self, scaling_type, period_sec, server_group):
        """Renders scaling policy templates based on configs and variables.
        After rendering, POSTs the json to Spinnaker for creation.

        Args:
            scaling_type (str): ``scale_up`` or ``scaling_down``. Type of policy
            period_sec (int): Period of time to look at metrics for determining scale
            server_group (str): The name of the server group to render template for
        """
        template_kwargs = {
            'app': self.app,
            'env': self.env,
            'region': self.region,
            'server_group': server_group,
            'period_sec': period_sec,
            'scaling_policy': self.settings['asg']['scaling_policy'],
        }
        if scaling_type == 'scale_up':
            template_kwargs['operation'] = 'increase'
            template_kwargs['comparisonOperator'] = 'GreaterThanThreshold'
            template_kwargs['scalingAdjustment'] = 1

        elif scaling_type == 'scale_down':
            cur_threshold = int(self.settings['asg']['scaling_policy']['threshold'])
            self.settings['asg']['scaling_policy']['threshold'] = floor(cur_threshold * 0.5)
            template_kwargs['operation'] = 'decrease'
            template_kwargs['comparisonOperator'] = 'LessThanThreshold'
            template_kwargs['scalingAdjustment'] = -1

        rendered_template = get_template(template_file='infrastructure/autoscaling_policy.json.j2', **template_kwargs)
        self.log.info('Creating a %s policy in %s for %s', scaling_type, self.env, self.app)
        wait_for_task(rendered_template)
        self.log.info('Successfully created a %s policy in %s for %s', scaling_type, self.env, self.app)