def _parse_storage_embedded_health(self, data):
        """Gets the storage data from get_embedded_health

        Parse the get_host_health_data() for essential properties

        :param data: the output returned by get_host_health_data()
        :returns: disk size in GB.

        """
        local_gb = 0
        storage = self.get_value_as_list(data['GET_EMBEDDED_HEALTH_DATA'],
                                         'STORAGE')
        if storage is None:
            # We dont raise exception because this dictionary
            # is available only when RAID is configured.
            # If we raise error here then we will always fail
            # inspection where this module is consumed. Hence
            # as a workaround just return 0.
            return local_gb

        minimum = local_gb

        for item in storage:
            cntlr = self.get_value_as_list(item, 'CONTROLLER')
            if cntlr is None:
                continue
            for s in cntlr:
                drive = self.get_value_as_list(s, 'LOGICAL_DRIVE')
                if drive is None:
                    continue
                for item in drive:
                    for key, val in item.items():
                        if key == 'CAPACITY':
                            capacity = val['VALUE']
                            local_bytes = (strutils.string_to_bytes(
                                           capacity.replace(' ', ''),
                                           return_int=True))
                            local_gb = int(local_bytes / (1024 * 1024 * 1024))
                            if minimum >= local_gb or minimum == 0:
                                minimum = local_gb

        # Return disk size 1 less than the actual disk size. This prevents
        # the deploy to fail from Nova when root_gb is same as local_gb
        # in Ironic. When the disk size is used as root_device hints,
        # then it should be given as the actual size i.e.
        # ironic (node.properties['local_gb'] + 1) else root device
        # hint will fail.
        if minimum:
            minimum = minimum - 1
        return minimum