def version():
    """
    Version
    Imports and displays current boiler version.
    :return:
    """
    echo(green('\nshift-boiler:'))
    echo(green('-' * 40))
    echo(yellow('Version: ') + '{}'.format(boiler_version))
    echo(yellow('GitHub: ') + 'https://github.com/projectshift/shift-boiler')
    echo(yellow('PyPi: ') + 'https://pypi.org/project/shiftboiler/')
    echo()