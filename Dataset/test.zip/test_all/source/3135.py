def restore_breakpoints_state(cls, breakpoints_state_list):
        """Restore the state of breakpoints given a list provided by 
        backup_breakpoints_state(). If list of breakpoint has changed 
        since backup missing or added breakpoints are ignored.
        
        breakpoints_state_list is a list of tuple. Each tuple is of form:
        (breakpoint_number, enabled, condition)
        """
        for breakpoint_state in breakpoints_state_list:
            bp = cls.breakpoints_by_number[breakpoint_state[0]]
            if bp:
                bp.enabled = breakpoint_state[1]
                bp.condition = breakpoint_state[2]
        cls.update_active_breakpoint_flag()
        return