def destroy(self, names):
        '''
        Destroy the named VMs
        '''
        mapper = salt.cloud.Map(self._opts_defaults(destroy=True))
        if isinstance(names, six.string_types):
            names = names.split(',')
        return salt.utils.data.simple_types_filter(
            mapper.destroy(names)
        )