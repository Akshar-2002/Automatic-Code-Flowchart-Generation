def namedtuple_storable(namedtuple, *args, **kwargs):
    """
    Storable factory for named tuples.
    """
    return default_storable(namedtuple, namedtuple._fields, *args, **kwargs)