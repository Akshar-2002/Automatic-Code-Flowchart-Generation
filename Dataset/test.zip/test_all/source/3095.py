def unregister(self, command):
        """
        Unregisters an existing command, so that this command is no longer available on the command line interface.

        This function is mainly used during plugin deactivation.

        :param command: Name of the command
        """
        if command not in self._commands.keys():
            self.log.warning("Can not unregister command %s" % command)
        else:
            # Click does not have any kind of a function to unregister/remove/deactivate already added commands.
            # So we need to delete the related objects manually from the click internal commands dictionary for
            # our root command.
            del(self._click_root_command.commands[command])
            # Finally lets delete the command from our internal dictionary too.
            del(self._commands[command])
            self.log.debug("Command %s got unregistered" % command)