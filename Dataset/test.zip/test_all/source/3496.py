def create_header(self):
		""" return header dict """
		try:
			self.check_valid()
			_header_list = []
			for k,v in self.inputs.items():
				if v is None:
					return  {self.__class__.__name__.replace('_','-'):None}
				elif k == 'value':
					_header_list.insert(0,str(v))
				elif isinstance(v,bool):
					if v is True:
						_header_list.append(k)
				else:
					_header_list.append('%s=%s' % (k,str(v)))
			return {self.__class__.__name__.replace('_','-'):'; '.join(_header_list)}
		except Exception, e:
			raise