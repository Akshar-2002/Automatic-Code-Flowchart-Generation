def recent_all_projects(self, limit=30, offset=0):
        """Return information about recent builds across all projects.

        Args:
            limit (int), Number of builds to return, max=100, defaults=30.
            offset (int): Builds returned from this point, default=0.

        Returns:
            A list of dictionaries.
        """
        method = 'GET'
        url = ('/recent-builds?circle-token={token}&limit={limit}&'
               'offset={offset}'.format(token=self.client.api_token,
                                        limit=limit,
                                        offset=offset))
        json_data = self.client.request(method, url)
        return json_data