def sendRemoteVoiceClips(
        self, clip_urls, message=None, thread_id=None, thread_type=ThreadType.USER
    ):
        """
        Sends voice clips from URLs to a thread

        :param clip_urls: URLs of clips to upload and send
        :param message: Additional message
        :param thread_id: User/Group ID to send to. See :ref:`intro_threads`
        :param thread_type: See :ref:`intro_threads`
        :type thread_type: models.ThreadType
        :return: :ref:`Message ID <intro_message_ids>` of the sent files
        :raises: FBchatException if request failed
        """
        clip_urls = require_list(clip_urls)
        files = self._upload(get_files_from_urls(clip_urls), voice_clip=True)
        return self._sendFiles(
            files=files, message=message, thread_id=thread_id, thread_type=thread_type
        )