def close(self):
        """This method closes the database correctly."""
        
        if self.filepath is not None:
            if path.isfile(self.filepath+'.lock'):
                remove(self.filepath+'.lock')
            self.filepath = None
            self.read_only = False
            self.lock()
            return True
        else:
            raise KPError('Can\'t close a not opened file')