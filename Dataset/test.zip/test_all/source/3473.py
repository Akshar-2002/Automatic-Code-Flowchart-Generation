def activateAaPdpContextAccept(ProtocolConfigurationOptions_presence=0,
                               GprsTimer_presence=0):
    """ACTIVATE AA PDP CONTEXT ACCEPT Section 9.5.11"""
    a = TpPd(pd=0x8)
    b = MessageType(mesType=0x51)  # 01010001
    c = LlcServiceAccessPointIdentifier()
    d = QualityOfService()
    e = MobileId()
    f = PacketDataProtocolAddress()
    g = RadioPriorityAndSpareHalfOctets()
    packet = a / b / c / d / e / f / g
    if ProtocolConfigurationOptions_presence is 1:
        i = ProtocolConfigurationOptions(ieiPCO=0x27)
        packet = packet / i
    if GprsTimer_presence is 1:
        j = GprsTimer(ieiGT=0x29)
        packet = packet / j
    return packet