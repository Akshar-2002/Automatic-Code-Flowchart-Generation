def context_id(self):
        """Return this Async's Context Id if it exists."""
        if not self._context_id:
            self._context_id = self._get_context_id()
            self.update_options(context_id=self._context_id)

        return self._context_id