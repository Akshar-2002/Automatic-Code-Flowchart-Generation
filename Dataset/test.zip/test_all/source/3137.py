def convert_values(self, matchdict: Dict[str, str]) -> Dict[str, Any]:
        """ convert values of ``matchdict``
        with converter this object has."""

        converted = {}
        for varname, value in matchdict.items():
            converter = self.converters[varname]
            converted[varname] = converter(value)
        return converted