def getfiles(self, path, ext=None, start=None, stop=None, recursive=False):
        """
        Get scheme, bucket, and keys for a set of files
        """
        from .utils import connection_with_anon, connection_with_gs

        parse = BotoClient.parse_query(path)

        scheme = parse[0]
        bucket_name = parse[1]

        if scheme == 's3' or scheme == 's3n':
            conn = connection_with_anon(self.credentials)
            bucket = conn.get_bucket(parse[1])
        elif scheme == 'gs':
            conn = connection_with_gs(bucket_name)
            bucket = conn.get_bucket()
        else:
            raise NotImplementedError("No file reader implementation for URL scheme " + scheme)

        keys = BotoClient.retrieve_keys(
            bucket, parse[2], prefix=parse[3], postfix=parse[4], recursive=recursive)
        keylist = [key.name for key in keys]
        if ext:
            if ext == 'tif' or ext == 'tiff':
                keylist = [keyname for keyname in keylist if keyname.endswith('tif')]
                keylist.append([keyname for keyname in keylist if keyname.endswith('tiff')])
            else:
                keylist = [keyname for keyname in keylist if keyname.endswith(ext)]

        keylist.sort()
        keylist = select(keylist, start, stop)

        return scheme, bucket.name, keylist