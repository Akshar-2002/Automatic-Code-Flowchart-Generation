def extract_archive(client, archive_path, extract_path=None):
    """
    Extract the archive in current path using the provided client.

    If extract_path is provided extract the archive there.
    """
    command = 'tar -xf {path}'.format(path=archive_path)

    if extract_path:
        command += ' -C {extract_path}'.format(extract_path=extract_path)

    out = execute_ssh_command(client, command)
    return out