def down(p_queue, host=None):
    if host is not None:
        return _path(_c.FSQ_DOWN, root=_path(host, root=hosts(p_queue)))
    '''Construct a path to the down file for a queue'''
    return _path(p_queue, _c.FSQ_DOWN)