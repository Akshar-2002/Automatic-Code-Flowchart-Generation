def urlencode(resource):
    """
    This implementation of urlencode supports all unicode characters

    :param: resource: Resource value to be url encoded.
    """
    if isinstance(resource, str):
        return _urlencode(resource.encode('utf-8'))

    return _urlencode(resource)