async def respond_rpc(self, msg, _context):
        """Respond to an RPC previously sent to a service."""

        rpc_id = msg.get('response_uuid')
        result = msg.get('result')
        payload = msg.get('response')

        self.service_manager.send_rpc_response(rpc_id, result, payload)