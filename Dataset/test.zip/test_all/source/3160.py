def get_channel_access(self, channel=None, read_mode='volatile'):
        """Get channel access

        :param channel: number [1:7]
        :param read_mode:
        non_volatile  = get non-volatile Channel Access
        volatile      = get present volatile (active) setting of Channel Access

        :return: A Python dict with the following keys/values:
          {
            - alerting:
            - per_msg_auth:
            - user_level_auth:
            - access_mode:{
                0: 'disabled',
                1: 'pre_boot',
                2: 'always',
                3: 'shared'
              }
            - privilege_level: {
                1: 'callback',
                2: 'user',
                3: 'operator',
                4: 'administrator',
                5: 'proprietary',
              }
           }
        """
        if channel is None:
            channel = self.get_network_channel()
        data = []
        data.append(channel & 0b00001111)
        b = 0
        read_modes = {
            'non_volatile': 1,
            'volatile': 2,
        }
        b |= (read_modes[read_mode] << 6) & 0b11000000
        data.append(b)

        response = self.raw_command(netfn=0x06, command=0x41, data=data)
        if 'error' in response:
            raise Exception(response['error'])

        data = response['data']
        if len(data) != 2:
            raise Exception('expecting 2 data bytes')

        r = {}
        r['alerting'] = data[0] & 0b10000000 > 0
        r['per_msg_auth'] = data[0] & 0b01000000 > 0
        r['user_level_auth'] = data[0] & 0b00100000 > 0
        access_modes = {
            0: 'disabled',
            1: 'pre_boot',
            2: 'always',
            3: 'shared'
        }
        r['access_mode'] = access_modes[data[0] & 0b00000011]
        privilege_levels = {
            0: 'reserved',
            1: 'callback',
            2: 'user',
            3: 'operator',
            4: 'administrator',
            5: 'proprietary',
            # 0x0F: 'no_access'
        }
        r['privilege_level'] = privilege_levels[data[1] & 0b00001111]
        return r