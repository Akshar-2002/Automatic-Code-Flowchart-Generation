def pieces(self):
        """
        Number of pieces the content is split into or ``None`` if :attr:`piece_size`
        returns ``None``
        """
        if self.piece_size is None:
            return None
        else:
            return math.ceil(self.size / self.piece_size)