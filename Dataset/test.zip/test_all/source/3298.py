def printOptions(options, tm, outFile):
  """
  Pretty print the set of options
  """
  print >>outFile, "TM parameters:"
  printTemporalMemory(tm, outFile)
  print >>outFile, "Experiment parameters:"
  for k,v in options.__dict__.iteritems():
    print >>outFile, "  %s : %s" % (k,str(v))
  outFile.flush()