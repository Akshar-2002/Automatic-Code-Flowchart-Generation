def attach_template(self, _template, _key, **unbound_var_values):
    """Attaches the template to this with the _key is supplied with this layer.

    Note: names were chosen to avoid conflicts.

    Args:
      _template: The template to construct.
      _key: The key that this layer should replace.
      **unbound_var_values: The values for the unbound_vars.
    Returns:
      A new layer with operation applied.
    Raises:
      ValueError: If _key is specified twice or there is a problem computing the
        template.
    """
    if _key in unbound_var_values:
      raise ValueError('%s specified twice.' % _key)
    unbound_var_values[_key] = self
    return _DeferredLayer(self.bookkeeper,
                          _template.as_layer().construct,
                          [],
                          unbound_var_values,
                          scope=self._scope,
                          defaults=self._defaults,
                          partial_context=self._partial_context)