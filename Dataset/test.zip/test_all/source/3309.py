def get_parameters_as_dictionary(self, query_string):
        """ Returns query string parameters as a dictionary. """
        pairs = (x.split('=', 1) for x in query_string.split('&'))
        return dict((k, unquote(v)) for k, v in pairs)