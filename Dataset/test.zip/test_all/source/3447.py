def build_tree_fast(self, new_path=None, seq_type='nucl' or 'prot'):
        """Make a tree with FastTree. Names will be truncated however."""
        # Check output #
        if new_path is None: new_path = self.prefix_path + '.tree'
        # Command #
        command_args = []
        if seq_type == 'nucl': command_args += ['-nt']
        command_args += ['-gamma']
        command_args += ['-out', new_path]
        command_args += [self.path]
        # Run it #
        sh.FastTree(*command_args)
        # Return #
        return FilePath(new_path)