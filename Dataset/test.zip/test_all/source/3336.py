def get_font(self, font):
        """Return the escpos index for `font`. Makes sure that
        the requested `font` is valid.
        """
        font = {'a': 0, 'b': 1}.get(font, font)
        if not six.text_type(font) in self.fonts:
            raise NotSupported(
                '"{}" is not a valid font in the current profile'.format(font))
        return font