async def Create(self, notes):
        '''
        notes : str
        Returns -> typing.Union[str, int, _ForwardRef('Number')]
        '''
        # map input types to rpc msg
        _params = dict()
        msg = dict(type='Backups',
                   request='Create',
                   version=2,
                   params=_params)
        _params['notes'] = notes
        reply = await self.rpc(msg)
        return reply