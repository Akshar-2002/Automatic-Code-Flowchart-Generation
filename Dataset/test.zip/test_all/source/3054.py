def clone(self, substitutions, commit=True, **kwargs):
        """
        Clone a DAG, optionally skipping the commit.

        """
        return self.store.clone(substitutions, **kwargs)