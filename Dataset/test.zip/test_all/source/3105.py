def dump_links(self, o):
        """Dump links."""
        params = {'versionId': o.version_id}
        data = {
            'self': url_for(
                '.object_api',
                bucket_id=o.bucket_id,
                key=o.key,
                _external=True,
                **(params if not o.is_head or o.deleted else {})
            ),
            'version': url_for(
                '.object_api',
                bucket_id=o.bucket_id,
                key=o.key,
                _external=True,
                **params
            )
        }

        if o.is_head and not o.deleted:
            data.update({'uploads': url_for(
                '.object_api',
                bucket_id=o.bucket_id,
                key=o.key,
                _external=True
            ) + '?uploads', })

        return data