def get_parts_of_url_path(url):
    """Given a url, take out the path part and split it by '/'.

    Args:
        url (str): the url slice

    returns
        list: parts after the domain name of the URL

    """
    parsed = urlparse(url)
    path = unquote(parsed.path).lstrip('/')
    parts = path.split('/')
    return parts