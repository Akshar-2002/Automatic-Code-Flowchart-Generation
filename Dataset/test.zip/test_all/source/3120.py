def get_source(self):
        """Return this context’s source.

        :returns:
            An instance of :class:`Pattern` or one of its sub-classes,
            a new Python object referencing the existing cairo pattern.

        """
        return Pattern._from_pointer(
            cairo.cairo_get_source(self._pointer), incref=True)