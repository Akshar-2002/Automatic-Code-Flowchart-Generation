def total_consumption(self):
        """Get the total power consumpuntion in the device lifetime."""
        if self.use_legacy_protocol:
            # TotalConsumption currently fails on the legacy protocol and
            # creates a mess in the logs. Just return 'N/A' for now.
            return 'N/A'

        res = 'N/A'
        try:
            res = self.SOAPAction("GetPMWarningThreshold", "TotalConsumption", self.moduleParameters("2"))
        except:
            return 'N/A'

        if res is None:
            return 'N/A'

        try:
            float(res)
        except ValueError:
            _LOGGER.error("Failed to retrieve total power consumption from SmartPlug")

        return res