def confirmation_pdf(self, confirmation_id):
        """
        Opens a pdf of a confirmation

        :param confirmation_id: the confirmation id
        :return: dict
        """
        return self._create_get_request(resource=CONFIRMATIONS, billomat_id=confirmation_id, command=PDF)