def change_generated_target_suffix (type, properties, suffix):
    """ Change the suffix previously registered for this type/properties
        combination. If suffix is not yet specified, sets it.
    """
    assert isinstance(type, basestring)
    assert is_iterable_typed(properties, basestring)
    assert isinstance(suffix, basestring)
    change_generated_target_ps(1, type, properties, suffix)