def compose(*fs):
    """
    Compose functions together in order:

    compose(f, g, h) = lambda n: f(g(h(n)))
    """
    # Pull the iterator out into a tuple so we can call `composed`
    # more than once.
    rs = tuple(reversed(fs))

    def composed(n):
        return reduce(lambda a, b: b(a), rs, n)

    # Attempt to make the function look pretty with
    # a fresh docstring and name.
    try:
        composed.__doc__ = 'lambda n: ' + _composed_doc(fs)
    except AttributeError:
        # One of our callables does not have a `__name__`, whatever.
        pass
    else:
        # We already know that for all `f` in `fs`, there exists `f.__name__`
        composed.__name__ = '_of_'.join(f.__name__ for f in fs)

    return composed