def forward_all_signals_async(target_pid, process_name):
    """Install all signal handler that forwards all signals to the given process."""
    def forwarding_signal_handler(signum):
        _forward_signal(signum, process_name, forwarding_signal_handler.target_pid)

    # Somehow we get a Python SystemError sometimes if we access target_pid directly from inside function.
    forwarding_signal_handler.target_pid = target_pid

    for signum in _FORWARDABLE_SIGNALS:
        # Need to directly access libc function,
        # the state of the signal module is incorrect due to the clone()
        # (it may think we are in a different thread than the main thread).
        libc.signal(signum, forwarding_signal_handler)

    # Reactivate delivery of signals such that our handler gets called.
    reset_signal_handling()