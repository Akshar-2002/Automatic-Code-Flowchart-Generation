def iterfields(klass):
    """Iterate over the input class members and yield its TypedFields.

    Args:
        klass: A class (usually an Entity subclass).

    Yields:
        (class attribute name, TypedField instance) tuples.
    """
    is_field = lambda x: isinstance(x, TypedField)

    for name, field in inspect.getmembers(klass, predicate=is_field):
        yield name, field