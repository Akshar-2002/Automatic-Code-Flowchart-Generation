def get_vcs_root():
    """Returns the vcs module and the root of the repo.

    Returns:
      A tuple containing the vcs module to use (git, hg) and the root of the
      repository. If no repository exisits then (None, None) is returned.
    """
    for vcs in (git, hg):
        repo_root = vcs.repository_root()
        if repo_root:
            return vcs, repo_root

    return (None, None)