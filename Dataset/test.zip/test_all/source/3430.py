def read_dict(file_name, clear_none=False, encoding='utf-8'):
    """
    读取字典文件
    :param encoding:
    :param clear_none:
    :param file_name:
    :return:
    """
    with open(file_name, 'rb') as f:
        data = f.read()

    if encoding is not None:
        data = data.decode(encoding)

    line_list = data.splitlines()
    data = []
    i = 0
    for line in line_list:
        i += 1
        try:
            line = force_text(line).strip()
            data.append(line)
        except:
            print('read error line %s' % i)
    if clear_none:
        data = [t for t in data if t != '']
    data = deque(data)
    return data