def enable_category(self, category: str) -> None:
        """
        Enable an entire category of commands
        :param category: the category to enable
        """
        for cmd_name in list(self.disabled_commands):
            func = self.disabled_commands[cmd_name].command_function
            if hasattr(func, HELP_CATEGORY) and getattr(func, HELP_CATEGORY) == category:
                self.enable_command(cmd_name)