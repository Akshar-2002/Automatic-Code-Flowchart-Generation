def _build_option_description(k):
    """Builds a formatted description of a registered option and prints it."""
    o = _get_registered_option(k)
    d = _get_deprecated_option(k)

    buf = ['{} '.format(k)]

    if o.doc:
        doc = '\n'.join(o.doc.strip().splitlines())
    else:
        doc = 'No description available.'

    buf.append(doc)

    if o:
        buf.append(
            '\n    [default: {}] [currently: {}]'.format(
                o.defval, _get_option(k, True)
            )
        )

    if d:
        buf.append(
            '\n    (Deprecated{})'.format(
                ', use `{}` instead.'.format(d.rkey) if d.rkey else ''
            )
        )

    buf.append('\n\n')
    return ''.join(buf)