def do_parameter(self,args):
        """Print a parameter"""
        parser = CommandArgumentParser("parameter")
        parser.add_argument(dest="id",help="Parameter to print")
        args = vars(parser.parse_args(args))
        
        print "printing parameter {}".format(args['id'])
        try:
            index = int(args['id'])            
            parameter = self.wrappedStack['resourcesByTypeName']['parameters'][index]
        except ValueError:
            parameter = self.wrappedStack['resourcesByTypeName']['parameters'][args['id']]

        print(parameter.resource_status)