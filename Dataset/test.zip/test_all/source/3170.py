def delay_svc_notification(self, service, notification_time):
        """Modify service first notification delay
        Format of the line that triggers function call::

        DELAY_SVC_NOTIFICATION;<host_name>;<service_description>;<notification_time>

        :param service: service to edit
        :type service: alignak.objects.service.Service
        :param notification_time: new value to set
        :type notification_time:
        :return: None
        """
        service.first_notification_delay = notification_time
        self.send_an_element(service.get_update_status_brok())