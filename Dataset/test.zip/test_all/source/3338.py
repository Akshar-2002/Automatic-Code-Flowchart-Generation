def next_task(self):
        """
        Returns the next task to be executed.

        This simply asks for the next Node to be evaluated, and then wraps
        it in the specific Task subclass with which we were initialized.
        """
        node = self._find_next_ready_node()

        if node is None:
            return None

        executor = node.get_executor()
        if executor is None:
            return None

        tlist = executor.get_all_targets()

        task = self.tasker(self, tlist, node in self.original_top, node)
        try:
            task.make_ready()
        except Exception as e :
            # We had a problem just trying to get this task ready (like
            # a child couldn't be linked to a VariantDir when deciding
            # whether this node is current).  Arrange to raise the
            # exception when the Task is "executed."
            self.ready_exc = sys.exc_info()

        if self.ready_exc:
            task.exception_set(self.ready_exc)

        self.ready_exc = None

        return task