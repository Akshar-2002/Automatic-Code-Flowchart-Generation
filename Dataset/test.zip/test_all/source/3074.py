def data_not_in(db_data, user_data):
        """Validate data not in user data.

        Args:
            db_data (str): The data store in Redis.
            user_data (list): The user provided data.

        Returns:
            bool: True if the data passed validation.
        """
        if isinstance(user_data, list):
            if db_data not in user_data:
                return True
        return False