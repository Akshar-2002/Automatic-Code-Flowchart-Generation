def add_logger(name, level=None, format=None):
    '''
    Set up a stdout logger.

    Args:
        name (str): name of the logger
        level: defaults to logging.INFO
        format (str): format string for logging output.
                      defaults to ``%(filename)-11s %(lineno)-3d: %(message)s``.

    Returns:
        The logger object.
    '''
    format = format or '%(filename)-11s %(lineno)-3d: %(message)s'
    log = logging.getLogger(name)

    # Set logging level.
    log.setLevel(level or logging.INFO)

    ch = logging.StreamHandler(sys.stdout)
    ch.setFormatter(logging.Formatter(format))
    log.addHandler(ch)

    return log