def bytes_required(self):
        """
        Returns
        -------
        int
            Estimated number of bytes required by arrays registered
            on the cube, taking their extents into account.
        """
        return np.sum([hcu.array_bytes(a) for a
            in self.arrays(reify=True).itervalues()])