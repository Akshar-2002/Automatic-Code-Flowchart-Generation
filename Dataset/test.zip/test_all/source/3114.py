def targets_by_artifact_set(self, targets):
    """Partitions the input targets by the sets of pinned artifacts they are managed by.

    :param collections.Iterable targets: the input targets (typically just JarLibrary targets).
    :return: a mapping of PinnedJarArtifactSet -> list of targets.
    :rtype: dict
    """
    sets_to_targets = defaultdict(list)
    for target in targets:
      sets_to_targets[self.for_target(target)].append(target)
    return dict(sets_to_targets)