def visit_break(self, node, parent):
        """visit a Break node by returning a fresh instance of it"""
        return nodes.Break(
            getattr(node, "lineno", None), getattr(node, "col_offset", None), parent
        )