def maybe_start_recording(tokens, index):
        """Return a new _MultilineStringRecorder when its time to record."""
        if _is_begin_quoted_type(tokens[index].type):
            string_type = _get_string_type_from_token(tokens[index].type)
            return _MultilineStringRecorder(index, string_type)

        return None