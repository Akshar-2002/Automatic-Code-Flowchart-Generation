def cmd(send, *_):
    """Gets a random distro.

    Syntax: {command}

    """
    url = get('http://distrowatch.com/random.php').url
    match = re.search('=(.*)', url)
    if match:
        send(match.group(1))
    else:
        send("no distro found")