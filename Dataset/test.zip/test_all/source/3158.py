def empirical_SVD(stream_list, linear=True):
    """
    Depreciated. Use empirical_svd.
    """
    warnings.warn('Depreciated, use empirical_svd instead.')
    return empirical_svd(stream_list=stream_list, linear=linear)