def get_project() -> Optional[str]:
    """
    Returns the current project name.
    """
    project = SETTINGS.project
    if not project:
        require_test_mode_enabled()
        raise RunError('Missing project name; for test mode, please set PULUMI_NODEJS_PROJECT')
    return project