def task_del(self, t):
        """
        Remove a task in this legion.
        If the task has active processes, an attempt is made to
        stop them before the task is deleted.
    """
        name = t._name
        if name in self._tasknames:
            del self._tasknames[name]
        self._tasks.discard(t)
        self._tasks_scoped.discard(t)
        try:
            t.stop()
        except:
            log = self._params.get('log', self._discard)
            log.error("Failed to stop processes for task %r -- %s", name, e, exc_info=log.isEnabledFor(logging.DEBUG))
        for pid in t.get_pids():
            self.proc_del(pid)