def Xor(bytestr, key):
  """Returns a `bytes` object where each byte has been xored with key."""
  # TODO(hanuszczak): Remove this import when string migration is done.
  # pytype: disable=import-error
  from builtins import bytes  # pylint: disable=redefined-builtin, g-import-not-at-top
  # pytype: enable=import-error
  precondition.AssertType(bytestr, bytes)

  # TODO: This seemingly no-op operation actually changes things.
  # In Python 2 this function receives a `str` object which has different
  # iterator semantics. So we use a `bytes` wrapper from the `future` package to
  # get the Python 3 behaviour. In Python 3 this should be indeed a no-op. Once
  # the migration is completed and support for Python 2 is dropped, this line
  # can be removed.
  bytestr = bytes(bytestr)

  return bytes([byte ^ key for byte in bytestr])