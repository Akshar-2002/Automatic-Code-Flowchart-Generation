def load_repo_addons(_globals):
    '''Load all fabsetup addons which are stored under ~/.fabsetup-addon-repos
    as git repositories.

    Args:
        _globals(dict): the globals() namespace of the fabric script.

    Return: None
    '''
    repos_dir = os.path.expanduser('~/.fabsetup-addon-repos')
    if os.path.isdir(repos_dir):
        basedir, repos, _ = next(os.walk(repos_dir))
        for repo_dir in [os.path.join(basedir, repo)
                         for repo in repos
                         # omit dot dirs like '.rope'
                         # or 'fabsetup-theno-termdown.disabled'
                         if '.' not in repo]:
            sys.path.append(repo_dir)
            package_name, username = package_username(repo_dir.split('/')[-1])
            load_addon(username, package_name, _globals)