def create(cls, name, ipv4_network=None, ipv6_network=None,
               comment=None):
        """
        Create the network element

        :param str name: Name of element
        :param str ipv4_network: network cidr (optional if ipv6)
        :param str ipv6_network: network cidr (optional if ipv4)
        :param str comment: comment (optional)
        :raises CreateElementFailed: element creation failed with reason
        :return: instance with meta
        :rtype: Network
        
        .. note:: Either an ipv4_network or ipv6_network must be specified
        """
        ipv4_network = ipv4_network if ipv4_network else None
        ipv6_network = ipv6_network if ipv6_network else None
        json = {'name': name,
                'ipv4_network': ipv4_network,
                'ipv6_network': ipv6_network,
                'comment': comment}

        return ElementCreator(cls, json)