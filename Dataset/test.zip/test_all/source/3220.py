def update_conf(self):
        """Update configuration values from database.

        This method should be called when there is an update notification.
        """
        parsed = self.parse_conf()

        if not parsed:
            return None

        # Update app config
        self.app.config.update(parsed)