def render(self, context):
        """Handle the actual rendering.
        """
        user = self._get_value(self.user_key, context)
        feature = self._get_value(self.feature, context)

        if feature is None:
            return ''

        allowed = show_feature(user, feature)
        return self.nodelist.render(context) if allowed else ''