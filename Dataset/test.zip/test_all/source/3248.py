def atmost(cls, lits, weights=None, bound=1, top_id=None,
            encoding=EncType.best):
        """
            A synonim for :meth:`PBEnc.leq`.
        """

        return cls.leq(lits, weights, bound, top_id, encoding)