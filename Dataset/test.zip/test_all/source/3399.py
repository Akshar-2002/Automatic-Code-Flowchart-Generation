def get_report_raw(year, report_type):
    """Download and extract a CO-TRACER report.

    Generate a URL for the given report, download the corresponding archive,
    extract the CSV report, and interpret it using the standard CSV library.

    @param year: The year for which data should be downloaded.
    @type year: int
    @param report_type: The type of report that should be downloaded. Should be
        one of the strings in constants.REPORT_TYPES.
    @type report_type: str
    @return: A DictReader with the loaded data. Note that this data has not
        been interpreted so data fields like floating point values, dates, and
        boolean values are still strings.
    @rtype: csv.DictReader
    """
    if not is_valid_report_type(report_type):
        msg = '%s is not a valid report type.' % report_type
        raise ValueError(msg)

    url = get_url(year, report_type)
    raw_contents = get_zipped_file(url)
    return csv.DictReader(cStringIO.StringIO(raw_contents))