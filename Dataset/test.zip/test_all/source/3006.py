def logical_chassis_fwdl_status_output_cluster_fwdl_entries_fwdl_entries_blade_swbd(self, **kwargs):
        """Auto Generated Code
        """
        config = ET.Element("config")
        logical_chassis_fwdl_status = ET.Element("logical_chassis_fwdl_status")
        config = logical_chassis_fwdl_status
        output = ET.SubElement(logical_chassis_fwdl_status, "output")
        cluster_fwdl_entries = ET.SubElement(output, "cluster-fwdl-entries")
        fwdl_entries = ET.SubElement(cluster_fwdl_entries, "fwdl-entries")
        blade_swbd = ET.SubElement(fwdl_entries, "blade-swbd")
        blade_swbd.text = kwargs.pop('blade_swbd')

        callback = kwargs.pop('callback', self._callback)
        return callback(config)