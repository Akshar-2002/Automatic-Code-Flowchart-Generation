def add_arguments(self, parser):
        """Unpack self.arguments for parser.add_arguments."""
        parser.add_argument('app_label', nargs='*')
        for argument in self.arguments:
            parser.add_argument(*argument.split(' '), **self.arguments[argument])