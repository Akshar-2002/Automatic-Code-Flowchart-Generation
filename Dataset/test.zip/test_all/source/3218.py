def encode(self, value):
        '''
        :param value: value to encode
        '''
        encoded = strToBytes(value) + b'\x00'
        return Bits(bytes=encoded)