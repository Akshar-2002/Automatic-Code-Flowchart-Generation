def select_many_with_index(
            self,
            collection_selector=IndexedElement,
            result_selector=lambda source_element,
                                   collection_element: collection_element):
        '''Projects each element of a sequence to an intermediate new sequence,
        incorporating the index of the element, flattens the resulting sequence
        into one sequence and optionally transforms the flattened sequence
        using a selector function.

        Note: This method uses deferred execution.

        Args:
            collection_selector: A binary function mapping each element of the
                source sequence into an intermediate sequence, by incorporating
                its index in the source sequence. The two positional arguments
                to the function are the zero-based index of the source element
                and the value of the element.  The result of the function
                should be an iterable derived from the index and element value.
                If no collection_selector is provided, the elements of the
                intermediate  sequence will consist of tuples of (index,
                element) from the source sequence.

            result_selector:
                An optional binary function mapping the elements in the
                flattened intermediate sequence together with their
                corresponding source elements to elements of the result
                sequence. The two positional arguments of the result_selector
                are, first the source element corresponding to an element from
                the intermediate sequence, and second the actual element from
                the intermediate sequence. The return value should be the
                corresponding value in the result sequence. If no
                result_selector function is provided, the elements of the
                flattened intermediate sequence are returned untransformed.

        Returns:
            A Queryable over a generated sequence whose elements are the result
            of applying the one-to-many collection_selector to each element of
            the source sequence which incorporates both the index and value of
            the source element, concatenating the results into an intermediate
            sequence, and then mapping each of those elements through the
            result_selector into the result sequence.

        Raises:
            ValueError: If this Queryable has been closed.
            TypeError: If projector [and selector] are not callable.
        '''
        if self.closed():
            raise ValueError("Attempt to call select_many_with_index() on a "
                             "closed Queryable.")

        if not is_callable(collection_selector):
            raise TypeError("select_many_with_index() parameter "
             "projector={0} is not callable".format(repr(collection_selector)))

        if not is_callable(result_selector):
            raise TypeError("select_many_with_index() parameter "
                "selector={0} is not callable".format(repr(result_selector)))

        return self._create(
                self._generate_select_many_with_index(collection_selector,
                                                      result_selector))