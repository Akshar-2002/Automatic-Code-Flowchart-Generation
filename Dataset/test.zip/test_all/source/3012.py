def windows_install(path_to_python=""):
    """
    Sets the .py extension to be associated with the ftype Python which is
    then set to the python.exe you provide in the path_to_python variable or
    after the -p flag if run as a script. Once the python environment is set
    up the function proceeds to set PATH and PYTHONPATH using setx.

    Parameters
    ----------
    path_to_python : the path the python.exe you want windows to execute when
    running .py files
    """
    if not path_to_python:
        print("Please enter the path to your python.exe you wish Windows to use to run python files. If you do not, this script will not be able to set up a full python environment in Windows. If you already have a python environment set up in Windows such that you can run python scripts from command prompt with just a file name then ignore this message. Otherwise, you will need to run dev_setup.py again with the command line option '-p' followed by the correct full path to python.\nRun dev_setup.py with the -h flag for more details")
        print("Would you like to continue? [y/N] ")
        ans = input()
        if ans == 'y':
            pass
        else:
            return

    # be sure to add python.exe if the user forgets to include the file name
    if os.path.isdir(path_to_python):
        path_to_python = os.path.join(path_to_python, "python.exe")
    if not os.path.isfile(path_to_python):
        print("The path to python provided is not a full path to the python.exe file or this path does not exist, was given %s.\nPlease run again with the command line option '-p' followed by the correct full path to python.\nRun dev_setup.py with the -h flag for more details" % path_to_python)
        return

    # make windows associate .py with python
    subprocess.check_call('assoc .py=Python', shell=True)
    subprocess.check_call('ftype Python=%s ' %
                          path_to_python + '"%1" %*', shell=True)

    PmagPyDir = os.path.abspath(".")
    ProgramsDir = os.path.join(PmagPyDir, 'programs')
    dirs_to_add = [ProgramsDir]
    for d in next(os.walk(ProgramsDir))[1]:
        dirs_to_add.append(os.path.join(ProgramsDir, d))
    path = str(subprocess.check_output('echo %PATH%', shell=True)).strip('\n')
    if "PATH" in path:
        path = ''
    pypath = str(subprocess.check_output(
        'echo %PYTHONPATH%', shell=True)).strip('\n')
    if "PYTHONPATH" in pypath:
        pypath = PmagPyDir + ';' + ProgramsDir
    else:
        pypath += ';' + PmagPyDir + ';' + ProgramsDir
    for d_add in dirs_to_add:
        path += ';' + d_add
    unique_path_list = []
    for p in path.split(';'):
        p = p.replace('"', '')
        if p not in unique_path_list:
            unique_path_list.append(p)
    unique_pypath_list = []
    for p in pypath.split(';'):
        p = p.replace('"', '')
        if p not in unique_pypath_list:
            unique_pypath_list.append(p)
    path = functools.reduce(lambda x, y: x + ';' + y, unique_path_list)
    pypath = functools.reduce(lambda x, y: x + ';' + y, unique_pypath_list)
    print('setx PATH "%s"' % path)
    subprocess.call('setx PATH "%s"' % path, shell=True)
    print('setx PYTHONPATH "%s"' % pypath)
    subprocess.call('setx PYTHONPATH "%s"' % (pypath), shell=True)

    print("Install complete. Please restart the command prompt to complete install")