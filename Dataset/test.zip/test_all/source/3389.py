def download_file_with_progress_bar(url):
    """Downloads a file from the given url, displays 
    a progress bar.
    Returns a io.BytesIO object
    """
    request = requests.get(url, stream=True)
    if request.status_code == 404:
        msg = ('there was a 404 error trying to reach {} \nThis probably '
               'means the requested version does not exist.'.format(url))
        logger.error(msg)
        sys.exit()
    total_size = int(request.headers["Content-Length"])
    chunk_size = 1024
    bars = int(total_size / chunk_size)
    bytes_io = io.BytesIO()
    pbar = tqdm(request.iter_content(chunk_size=chunk_size), total=bars,
                unit="kb", leave=False)
    for chunk in pbar:
        bytes_io.write(chunk)
    return bytes_io