def _handle_client_error():
    """
    Handle boto exception and convert to class
    IO exceptions

    Raises:
        OSError subclasses: IO error.
    """
    try:
        yield

    except _ClientError as exception:
        error = exception.response['Error']
        if error['Code'] in _ERROR_CODES:
            raise _ERROR_CODES[error['Code']](error['Message'])
        raise