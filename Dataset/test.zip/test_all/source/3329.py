def debracket(string):
    """ Eliminate the bracketed var names in doc, line strings """
    result = re.sub(BRACKET_RE, ';', str(string))
    result = result.lstrip(';')
    result = result.lstrip(' ')
    result = result.replace('; ;',';')
    return result