def perform_create(self, serializer):
        """ determine user when node is added """
        if serializer.instance is None:
            serializer.save(user=self.request.user)