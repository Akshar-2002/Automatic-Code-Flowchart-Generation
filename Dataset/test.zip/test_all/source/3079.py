def get_position(self, dt):
        """Given dt in [0, 1], return the current position of the tile."""
        return self.sx + self.dx * dt, self.sy + self.dy * dt