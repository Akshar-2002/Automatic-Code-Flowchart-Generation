def _runUnrealBuildTool(self, target, platform, configuration, args, capture=False):
		"""
		Invokes UnrealBuildTool with the specified parameters
		"""
		platform = self._transformBuildToolPlatform(platform)
		arguments = [self.getBuildScript(), target, platform, configuration] + args
		if capture == True:
			return Utility.capture(arguments, cwd=self.getEngineRoot(), raiseOnError=True)
		else:
			Utility.run(arguments, cwd=self.getEngineRoot(), raiseOnError=True)