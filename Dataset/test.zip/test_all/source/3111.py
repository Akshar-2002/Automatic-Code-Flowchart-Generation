def info(self, fetch=False):
        """
        Print a table of info about the current filter
        """
        # Get the info from the class
        tp = (int, bytes, bool, str, float, tuple, list, np.ndarray)
        info = [[k, str(v)] for k, v in vars(self).items() if isinstance(v, tp)
                and k not in ['rsr', 'raw', 'centers'] and not k.startswith('_')]

        # Make the table
        table = at.Table(np.asarray(info).reshape(len(info), 2),
                         names=['Attributes', 'Values'])

        # Sort and print
        table.sort('Attributes')

        if fetch:
            return table
        else:
            table.pprint(max_width=-1, max_lines=-1, align=['>', '<'])