def retrieve(self, id) :
        """
        Retrieve a single source

        Returns a single source available to the user by the provided id
        If a source with the supplied unique identifier does not exist it returns an error

        :calls: ``get /deal_sources/{id}``
        :param int id: Unique identifier of a DealSource.
        :return: Dictionary that support attriubte-style access and represent DealSource resource.
        :rtype: dict
        """

        _, _, deal_source = self.http_client.get("/deal_sources/{id}".format(id=id))
        return deal_source