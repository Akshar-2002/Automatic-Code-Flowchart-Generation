def apply_dict_depth_first(nodes, func, depth=0, as_dict=True, parents=None, pre=None, post=None):
    '''
    This function is similar to the `apply_depth_first` except that it operates
    on the `OrderedDict`-based structure returned from `apply_depth_first` when
    `as_dict=True`.

    Note that if `as_dict` is `False`, the result of this function is given in
    the entry/tuple form.
    '''
    if as_dict:
        items = OrderedDict()
    else:
        items = []

    if parents is None:
        parents = []

    node_count = len(nodes)
    for i, (k, node) in enumerate(nodes.iteritems()):
        first = (i == 0)
        last = (i == (node_count - 1))
        if pre is not None:
            pre(k, node, parents, first, last, depth)
        item = func(k, node, parents, first, last, depth)
        item_parents = parents + [(k, node)]
        if node.children is not None:
            children = apply_dict_depth_first(node.children, func,
                                              depth=depth + 1,
                                              as_dict=as_dict,
                                              parents=item_parents,
                                              pre=pre, post=post)
        else:
            children = None
        if post is not None:
            post(k, node, parents, first, last, depth)
        if as_dict:
            items[k] = Node(item, children)
        elif children:
            items.append((item, children))
        else:
            items.append(item)
    return items