def fence_fetch_point_send(self, target_system, target_component, idx, force_mavlink1=False):
                '''
                Request a current fence point from MAV

                target_system             : System ID (uint8_t)
                target_component          : Component ID (uint8_t)
                idx                       : point index (first point is 1, 0 is for return point) (uint8_t)

                '''
                return self.send(self.fence_fetch_point_encode(target_system, target_component, idx), force_mavlink1=force_mavlink1)