def get_info(self):
        """Get the information about the channel groups.

        Returns
        -------
        dict
            information about this channel group

        Notes
        -----
        The items in selectedItems() are ordered based on the user's selection
        (which appears pretty random). It's more consistent to use the same
        order of the main channel list. That's why the additional for-loop
        is necessary. We don't care about the order of the reference channels.
        """
        selectedItems = self.idx_l0.selectedItems()
        selected_chan = [x.text() for x in selectedItems]
        chan_to_plot = []
        for chan in self.chan_name + ['_REF']:
            if chan in selected_chan:
                chan_to_plot.append(chan)

        selectedItems = self.idx_l1.selectedItems()
        ref_chan = []
        for selected in selectedItems:
            ref_chan.append(selected.text())

        hp = self.idx_hp.value()
        if hp == 0:
            low_cut = None
        else:
            low_cut = hp

        lp = self.idx_lp.value()
        if lp == 0:
            high_cut = None
        else:
            high_cut = lp

        scale = self.idx_scale.value()

        group_info = {'name': self.group_name,
                      'chan_to_plot': chan_to_plot,
                      'ref_chan': ref_chan,
                      'hp': low_cut,
                      'lp': high_cut,
                      'scale': float(scale),
                      'color': self.idx_color
                      }

        return group_info