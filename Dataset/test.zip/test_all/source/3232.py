def skolemize(gin: Graph) -> Graph:
    """
    Replace all of the blank nodes in graph gin with FHIR paths
    :param gin: input graph
    :return: output graph
    """
    gout = Graph()

    # Emit any unreferenced subject BNodes (boxes)
    anon_subjs = [s for s in gin.subjects() if isinstance(s, BNode) and len([gin.subject_predicates(s)]) == 0]
    if anon_subjs:
        idx = None if len(anon_subjs) == 1 else 0
        for s in anon_subjs:
            map_node(s, FHIR['treeRoot' + ('_{}'.format(idx) if idx is not None else '')], gin, gout)
            if idx is not None:
                idx += 1

    # Cover all other non-bnode entries
    for subj in set(s for s in gin.subjects() if isinstance(s, URIRef)):
        map_node(subj, subj, gin, gout)
    return gout