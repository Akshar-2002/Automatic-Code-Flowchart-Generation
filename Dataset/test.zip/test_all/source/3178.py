def do_searchfy(self, query, **kwargs):
        """
        Verifying a searchfy query in this platform.

        This might be redefined in any class inheriting from Platform.

        Performing additional procesing may be possible by iterating the requested profiles
        to extract more entities from the URI would be slow. Sample code may be:

            if kwargs["process"]:
                r["attributes"] += json.loads(self.getInfo(process=True, mode="usufy", qURI=uri, query=i))

        Args:
        -----
            query: The element to be searched.

        Return:
        -------
            A list of elements to be appended.
        """
        results = []
        print("[*] Launching search using the {} module...".format(self.__class__.__name__))
        test = self.check_searchfy(query, kwargs)

        if test:
            try:
                # Recovering all the found aliases in the traditional way
                ids = re.findall(self.searchfyAliasRegexp, test, re.DOTALL)
            except:
                # Version 2 of the wrappers
                verifier = self.modes.get(mode)
                
                if verifier and verifier.get("alias_extractor"):
                    ids = re.findall(verifier.get("alias_extractor"), test, re.DOTALL)
                else:
                    return []
                    
            for j, alias in enumerate(ids):
                r = {
                    "type": "i3visio.profile",
                    "value": self.platformName + " - " + alias,
                    "attributes": []
                }

                # Appending platform name
                aux = {}
                aux["type"] = "i3visio.platform"
                aux["value"] = self.platformName
                aux["attributes"] = []
                r["attributes"].append(aux)
                
                # Appending the alias
                aux = {}
                aux["type"] = "i3visio.alias"
                aux["value"] = alias
                aux["attributes"] = []
                r["attributes"].append(aux)
                
                # Appending the query performed to grab this items
                aux = {}
                aux["type"] = "i3visio.search"
                aux["value"] = query
                aux["attributes"] = []
                r["attributes"].append(aux)
                
                # Appending platform URI
                try:                    
                    aux = {}
                    aux["type"] = "i3visio.uri"
                    uri = self.createURL(word=alias, mode="usufy")
                    aux["value"] = uri
                    aux["attributes"] = []
                    r["attributes"].append(aux)
                except NameError:
                    pass

                # Appending the result to results: in this case only one profile will be grabbed"""
                results.append(r)
        return results