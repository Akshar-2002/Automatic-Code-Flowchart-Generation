def _acronym_lic(self, license_statement):
        """Convert license acronym."""
        pat = re.compile(r'\(([\w+\W?\s?]+)\)')
        if pat.search(license_statement):
            lic = pat.search(license_statement).group(1)
            if lic.startswith('CNRI'):
                acronym_licence = lic[:4]
            else:
                acronym_licence = lic.replace(' ', '')
        else:
            acronym_licence = ''.join(
                [w[0]
                 for w in license_statement.split(self.prefix_lic)[1].split()])
        return acronym_licence