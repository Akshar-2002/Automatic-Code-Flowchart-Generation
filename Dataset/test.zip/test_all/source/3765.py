def read(self, size:int=None):
        """
        :param size: number of characters to read from the buffer
        :return: string that has been read from the buffer
        """
        if size:
            result = self._buffer[0:size]
            self._buffer = self._buffer[size:]
            return result
        else:
            result = self._buffer
            self._buffer = ''
            return result