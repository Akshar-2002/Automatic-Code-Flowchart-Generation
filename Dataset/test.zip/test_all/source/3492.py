def get_valid_format_order(cls, format_target, format_order=None):
        """ Checks to see if the target format string follows the proper style
        """
        format_order = format_order or cls.parse_format_order(format_target)
        cls.validate_no_token_duplicates(format_order)
        format_target = cls.remove_tokens(format_target, format_order)
        format_target = cls.remove_static_text(format_target)
        cls.validate_separator_characters(format_target)
        cls.validate_matched_parenthesis(format_target)
        return format_order