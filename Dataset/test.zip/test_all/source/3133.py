def _validate_non_abstract_edge_has_defined_endpoint_types(class_name, properties):
    """Validate that the non-abstract edge properties dict has defined in/out link properties."""
    edge_source = properties.get(EDGE_SOURCE_PROPERTY_NAME, None)
    edge_destination = properties.get(EDGE_DESTINATION_PROPERTY_NAME, None)
    has_defined_endpoint_types = all((
        edge_source is not None and edge_source.type_id == PROPERTY_TYPE_LINK_ID,
        edge_destination is not None and edge_destination.type_id == PROPERTY_TYPE_LINK_ID,
    ))
    if not has_defined_endpoint_types:
        raise IllegalSchemaStateError(u'Found a non-abstract edge class with undefined or illegal '
                                      u'in/out properties: {} {}'.format(class_name, properties))