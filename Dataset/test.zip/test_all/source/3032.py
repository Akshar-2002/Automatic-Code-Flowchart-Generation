def process_module(self, yam):
        """Process data nodes, RPCs and notifications in a single module."""
        for ann in yam.search(("ietf-yang-metadata", "annotation")):
            self.process_annotation(ann)
        for ch in yam.i_children[:]:
            if ch.keyword == "rpc":
                self.process_rpc(ch)
            elif ch.keyword == "notification":
                self.process_notification(ch)
            else:
                continue
            yam.i_children.remove(ch)
        self.process_children(yam, "//nc:*", 1)