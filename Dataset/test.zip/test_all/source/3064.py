def signout(self, redirect_url = "/"):
        """
            注销登录状态

            参数:
                redirect_url    跳转链接，为 None 时不跳转 (Ajax 可能用得到)。
        """
        self.clear_cookie(self._USER_NAME)
        if redirect_url: self.redirect(redirect_url)