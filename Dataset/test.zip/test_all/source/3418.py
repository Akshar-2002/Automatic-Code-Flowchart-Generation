def _get_key_dir():
    '''
    return the location of the GPG key directory
    '''
    gpg_keydir = None
    if 'config.get' in __salt__:
        gpg_keydir = __salt__['config.get']('gpg_keydir')

    if not gpg_keydir:
        gpg_keydir = __opts__.get(
            'gpg_keydir',
            os.path.join(
                __opts__.get(
                    'config_dir',
                    os.path.dirname(__opts__['conf_file']),
                ),
                'gpgkeys'
            ))

    return gpg_keydir