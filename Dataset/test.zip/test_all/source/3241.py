def copy_models(module_from, module_to):
    """Copy models from one module to another
    :param module_from:
    :param module_to:
    :return:
    """
    module_from = get_module(module_from)
    module_to = get_module(module_to)
    models = get_models(module_from)
    if models:
        models = models.copy()
        models.update(((t.key, t) for t in module_tables(module_from)))
        module_to.__odm_models__ = models
        return models