def create_product(self, product, version, build, name=None, description=None, attributes={}):
        '''
        create_product(self, product, version, build, name=None, description=None, attributes={})

        Create product

        :Parameters:
        * *product* (`string`) -- product
        * *version* (`string`) -- version
        * *build* (`string`) -- build
        * *name* (`string`) -- name
        * *description* (`string`) -- description
        * *attributes* (`object`) -- product attributes

        '''
        request_data = {'product': product, 'version': version, 'build': build}
        if name: request_data['name']=name
        if description: request_data['description']=description
        if attributes: request_data['attributes']=attributes
        ret_data= self._call_rest_api('post', '/products', data=request_data, error='Failed to create a new product')
        pid = ret_data
        message = 'New product created [pid = %s] '%pid
        self.logger.info(message)
        return str(pid)