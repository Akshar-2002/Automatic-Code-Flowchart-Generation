def is_probably_prime(self):
        """Tests with miller-rabin
        :return: True iff prime
        """

        if self.is_naive_prime():
            return True

        # check if multiple pf low primes
        for prime in LOW_PRIMES:
            if self.to_int % prime == 0:
                return False

        # if all else fails, call rabin to determine if to_int is prime
        return self.test_miller_rabin(5)