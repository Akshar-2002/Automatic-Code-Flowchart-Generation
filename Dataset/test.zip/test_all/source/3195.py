def get_pool(parallel, kwargs):
    """
    Yields:
        a ThreadPoolExecutor if parallel is True and `concurrent.futures` exists.
        `None` otherwise.
    """

    if parallel:
        try:
            from concurrent.futures import ThreadPoolExecutor
            with ThreadPoolExecutor(thread_name_prefix="insights-collector-pool", **kwargs) as pool:
                yield pool
        except ImportError:
            yield None
    else:
        yield None