def shewhart(self, data: ['SASdata', str] = None,
                 boxchart: str = None,
                 cchart: str = None,
                 irchart: str = None,
                 mchart: str = None,
                 mrchart: str = None,
                 npchart: str = None,
                 pchart: str = None,
                 rchart: str = None,
                 schart: str = None,
                 uchart: str = None,
                 xrchart: str = None,
                 xschart: str = None,
                 procopts: str = None,
                 stmtpassthrough: str = None,
                 **kwargs: dict) -> 'SASresults':
        """
        Python method to call the SHEWHART procedure

        Documentation link:
        https://go.documentation.sas.com/?cdcId=pgmsascdc&cdcVersion=9.4_3.4&docsetId=qcug&docsetTarget=qcug_shewhart_toc.htm&locale=en

        :param data: SASdata object or string. This parameter is required.
        :parm boxchart: The boxchart variable can only be a string type.
        :parm cchart: The cchart variable can only be a string type.
        :parm irchart: The irchart variable can only be a string type.
        :parm mchart: The mchart variable can only be a string type.
        :parm mrchart: The mrchart variable can only be a string type.
        :parm npchart: The npchart variable can only be a string type.
        :parm pchart: The pchart variable can only be a string type.
        :parm rchart: The rchart variable can only be a string type.
        :parm schart: The schart variable can only be a string type.
        :parm uchart: The uchart variable can only be a string type.
        :parm xrchart: The xrchart variable can only be a string type.
        :parm xschart: The xschart variable can only be a string type.
        :parm procopts: The procopts variable is a generic option available for advanced use. It can only be a string type.
        :parm stmtpassthrough: The stmtpassthrough variable is a generic option available for advanced use. It can only be a string type.
        :return: SAS Result Object
        """