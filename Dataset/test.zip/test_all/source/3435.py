def plural(random=random, *args, **kwargs):
    """
    Return a plural noun.

    >>> mock_random.seed(0)
    >>> plural(random=mock_random)
    'onions'
    >>> plural(random=mock_random, capitalize=True)
    'Chimps'
    >>> plural(random=mock_random, slugify=True)
    'blisters'
    """
    return inflectify.plural(random.choice(nouns))