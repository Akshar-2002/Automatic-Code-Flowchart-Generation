def venues(self):
        """Get a list of all venue objects.

          >>> venues = din.venues()
        """
        response = self._request(V2_ENDPOINTS['VENUES'])
        # Normalize `dateHours` to array
        for venue in response["result_data"]["document"]["venue"]:
            if venue.get("id") in VENUE_NAMES:
                venue["name"] = VENUE_NAMES[venue.get("id")]
            if isinstance(venue.get("dateHours"), dict):
                venue["dateHours"] = [venue["dateHours"]]
            if "dateHours" in venue:
                for dh in venue["dateHours"]:
                    if isinstance(dh.get("meal"), dict):
                        dh["meal"] = [dh["meal"]]
        return response