def print_tree(self, *, verbose=True):
        """Print a ascii-formatted tree representation of the data contents."""
        print("{0} ({1})".format(self.natural_name, self.filepath))
        self._print_branch("", depth=0, verbose=verbose)