def _validate(self, val):
        """
        val must be None or one of the objects in self.objects.
        """
        if not self.check_on_set:
            self._ensure_value_is_in_objects(val)
            return

        if not (val in self.objects or (self.allow_None and val is None)):
            # CEBALERT: can be called before __init__ has called
            # super's __init__, i.e. before attrib_name has been set.
            try:
                attrib_name = self.name
            except AttributeError:
                attrib_name = ""

            items = []
            limiter = ']'
            length = 0
            for item in self.objects:
                string = str(item)
                length += len(string)
                if length < 200:
                    items.append(string)
                else:
                    limiter = ', ...]'
                    break
            items = '[' + ', '.join(items) + limiter
            raise ValueError("%s not in Parameter %s's list of possible objects, "
                             "valid options include %s"%(val,attrib_name, items))