def clone(url, directory, single_branch=None):
    print_info('Cloning {0} to {1} {2}'.format(
        url,
        directory,
        '[full clone]' if single_branch is None else '[{0}]'.format(single_branch)
    ))
    # type: (str, str, str) -> Repo
    """
    Clone a repository, optionally using shallow clone
    :rtype: Repo
    :param url: URL of the repository
    :param directory: Directory to clone to
    :param single_branch: branch to clone if shallow clone is preferred
    :return: GitPython repository object of the newly cloned repository
    """
    args = {
        'url': url,
        'to_path': directory,
        'progress': SimpleProgressPrinter(),
        'recursive': True
    }

    if single_branch is not None:
        args['depth'] = 1
        args['branch'] = single_branch
        args['single_branch'] = True

    return Repo.clone_from(**args)