def find_plugin(value,
                key=DEFAULT_LOOKUP_KEY,
                conn=None):
    """
    get's the plugin matching the key and value

    example: find_plugin("plugin1", "ServiceName") => list of 0 or 1 item
    example: find_plugin("plugin1", "Name") => list of 0-to-many items

    :param value:
    :param key: <str> (default "Name")
    :param conn:
    :return:
    """
    # cast to list to hide rethink internals from caller
    result = list(RPC.filter({
        key: value
    }).run(conn))
    return result