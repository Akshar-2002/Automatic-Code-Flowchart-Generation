def MI_referenceNames(self,
                          env,
                          objectName,
                          resultClassName,
                          role):
        # pylint: disable=invalid-name
        """Return instance names of an association class.

        Implements the WBEM operation ReferenceNames in terms
        of the references method.  A derived class will not normally
        override this method.

        """

        logger = env.get_logger()
        logger.log_debug('CIMProvider MI_referenceNames <2> called. ' \
                         'resultClass: %s' % (resultClassName))
        ch = env.get_cimom_handle()
        if not resultClassName:
            raise pywbem.CIMError(
                pywbem.CIM_ERR_FAILED,
                "Empty resultClassName passed to ReferenceNames")

        assocClass = ch.GetClass(resultClassName, objectName.namespace,
                                 LocalOnly=False,
                                 IncludeQualifiers=True)
        keys = pywbem.NocaseDict()
        keyNames = [p.name for p in assocClass.properties.values()
                    if 'key' in p.qualifiers]
        for keyName in keyNames:
            p = assocClass.properties[keyName]
            keys.__setitem__(p.name, p)
        _strip_quals(keys)
        model = pywbem.CIMInstance(classname=assocClass.classname,
                                   properties=keys)
        model.path = pywbem.CIMInstanceName(classname=assocClass.classname,
                                            namespace=objectName.namespace)
        #if role is None:
        #    raise pywbem.CIMError(pywbem.CIM_ERR_FAILED,
        #                          "** this shouldn't happen")
        if role:
            if role not in model.properties:
                raise pywbem.CIMError(pywbem.CIM_ERR_FAILED,
                                      "** this shouldn't happen")
            model[role] = objectName
        for inst in self.references(env=env,
                                    object_name=objectName,
                                    model=model,
                                    assoc_class=assocClass,
                                    result_class_name='',
                                    role=role,
                                    result_role=None,
                                    keys_only=True):
            for prop in inst.properties.values():
                if hasattr(prop.value, 'namespace') and \
                   prop.value.namespace is None:
                    prop.value.namespace = objectName.namespace
            yield build_instance_name(inst, keyNames)
        logger.log_debug('CIMProvider MI_referenceNames returning')