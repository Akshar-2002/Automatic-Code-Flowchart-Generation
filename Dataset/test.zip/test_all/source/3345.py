def getSyntax(self,
                  xmlFileName=None,
                  mimeType=None,
                  languageName=None,
                  sourceFilePath=None,
                  firstLine=None):
        """Get syntax by one of parameters:
            * xmlFileName
            * mimeType
            * languageName
            * sourceFilePath
        First parameter in the list has biggest priority
        """
        syntax = None

        if syntax is None and xmlFileName is not None:
            try:
                syntax = self._getSyntaxByXmlFileName(xmlFileName)
            except KeyError:
                _logger.warning('No xml definition %s' % xmlFileName)

        if syntax is None and mimeType is not None:
            try:
                syntax = self._getSyntaxByMimeType(mimeType)
            except KeyError:
                _logger.warning('No syntax for mime type %s' % mimeType)

        if syntax is None and languageName is not None:
            try:
                syntax = self._getSyntaxByLanguageName(languageName)
            except KeyError:
                _logger.warning('No syntax for language %s' % languageName)

        if syntax is None and sourceFilePath is not None:
            baseName = os.path.basename(sourceFilePath)
            try:
                syntax = self._getSyntaxBySourceFileName(baseName)
            except KeyError:
                pass

        if syntax is None and firstLine is not None:
            try:
                syntax = self._getSyntaxByFirstLine(firstLine)
            except KeyError:
                pass

        return syntax