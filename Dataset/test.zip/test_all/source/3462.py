def _fill_vao(self):
        """Put array location in VAO for shader in same order as arrays given to Mesh."""
        with self.vao:
            self.vbos = []
            for loc, verts in enumerate(self.arrays):
                vbo = VBO(verts)
                self.vbos.append(vbo)
                self.vao.assign_vertex_attrib_location(vbo, loc)