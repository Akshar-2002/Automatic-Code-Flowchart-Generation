def occipital_flatmap(cortex, radius=None):
    '''
    occipital_flatmap(cortex) yields a flattened mesh of the occipital cortex of the given cortex
      object.
      
    Note that if the cortex is not registrered to fsaverage, this will fail.

    The option radius may be given to specify the fraction of the cortical sphere (in radians) to
    include in the map.
    '''
    mdl = retinotopy_model('benson17', hemi=cortex.chirality)
    mp = mdl.map_projection
    if radius is not None: mp = mp.copy(radius=radius)
    return mp(cortex)