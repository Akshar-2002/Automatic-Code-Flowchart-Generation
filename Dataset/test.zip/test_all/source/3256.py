def extrema(self, x0, y0, w, h):
        """
        Returns the minimum and maximum values contained in a given area.

        :param x0: Starting x index.
        :param y0: Starting y index.
        :param w:  Width of the area to scan.
        :param h:  Height of the area to scan.
        :return:   Tuple containing the minimum and maximum values of the given area.
        """
        minimum = 9223372036854775807
        maximum = 0
        for y in range(y0, y0 + h):
            for x in range(x0, x0 + w):
                value = self[x, y]
                if value != self.filler:
                    minimum = min(minimum, value)
                    maximum = max(maximum, value)
        return minimum, maximum