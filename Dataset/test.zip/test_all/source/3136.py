def name(self, key, value):
    """Populate the ``name`` key.

    Also populates the ``status``, ``birth_date`` and ``death_date`` keys through side effects.
    """
    def _get_title(value):
        c_value = force_single_element(value.get('c', ''))
        if c_value != 'title (e.g. Sir)':
            return c_value

    def _get_value(value):
        a_value = force_single_element(value.get('a', ''))
        q_value = force_single_element(value.get('q', ''))
        return a_value or normalize_name(q_value)

    if value.get('d'):
        dates = value['d']
        try:
            self['death_date'] = normalize_date(dates)
        except ValueError:
            dates = dates.split(' - ')
            if len(dates) == 1:
                dates = dates[0].split('-')
            self['birth_date'] = normalize_date(dates[0])
            self['death_date'] = normalize_date(dates[1])

    self['status'] = force_single_element(value.get('g', '')).lower()

    return {
        'numeration': force_single_element(value.get('b', '')),
        'preferred_name': force_single_element(value.get('q', '')),
        'title': _get_title(value),
        'value': _get_value(value),
    }