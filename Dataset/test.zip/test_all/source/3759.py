def xline(self):
        """
        Interact with segy in crossline mode

        Returns
        -------
        xline : Line or None

        Raises
        ------
        ValueError
            If the file is unstructured

        Notes
        -----
        .. versionadded:: 1.1
        """
        if self.unstructured:
            raise ValueError(self._unstructured_errmsg)

        if self._xline is not None:
            return self._xline

        self._xline = Line(self,
                           self.xlines,
                           self._xline_length,
                           self._xline_stride,
                           self.offsets,
                           'crossline',
                          )
        return self._xline