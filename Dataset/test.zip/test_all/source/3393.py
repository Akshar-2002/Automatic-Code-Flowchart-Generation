def getAutoServiceLevelEnabled(self):
    """Returns True if enabled, False if disabled"""
    command = '$GE'
    settings = self.sendCommand(command)
    flags = int(settings[2], 16)
    return not (flags & 0x0020)