def exists(self, share_name, directory_name=None, file_name=None, timeout=None, snapshot=None):
        '''
        Returns a boolean indicating whether the share exists if only share name is
        given. If directory_name is specificed a boolean will be returned indicating
        if the directory exists. If file_name is specified as well, a boolean will be
        returned indicating if the file exists.

        :param str share_name:
            Name of a share.
        :param str directory_name:
            The path to a directory.
        :param str file_name:
            Name of a file.
        :param int timeout:
            The timeout parameter is expressed in seconds.
        :param str snapshot:
            A string that represents the snapshot version, if applicable.
        :return: A boolean indicating whether the resource exists.
        :rtype: bool
        '''
        _validate_not_none('share_name', share_name)
        try:
            request = HTTPRequest()
            request.method = 'HEAD' if file_name is not None else 'GET'
            request.host_locations = self._get_host_locations()
            request.path = _get_path(share_name, directory_name, file_name)

            if file_name is not None:
                restype = None
                expected_errors = [_RESOURCE_NOT_FOUND_ERROR_CODE, _PARENT_NOT_FOUND_ERROR_CODE]
            elif directory_name is not None:
                restype = 'directory'
                expected_errors = [_RESOURCE_NOT_FOUND_ERROR_CODE, _SHARE_NOT_FOUND_ERROR_CODE,
                                   _PARENT_NOT_FOUND_ERROR_CODE]
            else:
                restype = 'share'
                expected_errors = [_SHARE_NOT_FOUND_ERROR_CODE]

            request.query = {
                'restype': restype,
                'timeout': _int_to_str(timeout),
                'sharesnapshot': _to_str(snapshot)
            }
            self._perform_request(request, expected_errors=expected_errors)
            return True
        except AzureHttpError as ex:
            _dont_fail_not_exist(ex)
            return False