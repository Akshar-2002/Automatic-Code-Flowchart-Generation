def write(self):
        """write the current settings to the config file"""
        with open(storage.config_file, 'w') as cfg:
            yaml.dump(self.as_dict(), cfg, default_flow_style=False)

        storage.refresh()