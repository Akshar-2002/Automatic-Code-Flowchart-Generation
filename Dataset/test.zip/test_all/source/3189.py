def is_equal(self, other):
        """
        Computes whether two Partial Orderings contain the same information
        """
        if not (hasattr(other, 'get_domain') or hasattr(other, 'upper') or hasattr(other, 'lower')):
            other = self.coerce(other)
        if self.is_domain_equal(other)  \
            and len(self.upper.symmetric_difference(other.upper)) == 0 \
            and len(self.lower.symmetric_difference(other.lower)) == 0:
            return True
        return False