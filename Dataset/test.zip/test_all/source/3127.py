def convert_elementwise_mul_scalar(net, node, module, builder):
    """Convert a scalar multiplication from mxnet to coreml.

    Parameters
    ----------
    net: network
        A mxnet network object.

    node: layer
        Node to convert.

    module: module
        An module for MXNet

    builder: NeuralNetworkBuilder
        A neural network builder object.
    """
    import numpy
    input_name, output_name = _get_input_output_name(net, node)
    name = node['name']
    param = _get_attr(node)

    mult = literal_eval(param['scalar'])
    builder.add_scale(name=name,
                      W=numpy.array([mult]),
                      b=0,
                      has_bias=False,
                      input_name=input_name,
                      output_name=output_name)