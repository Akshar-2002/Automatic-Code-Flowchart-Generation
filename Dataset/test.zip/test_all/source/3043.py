def list_permissions(username=None, resource=None, resource_type='keyspace', permission=None, contact_points=None,
                     port=None, cql_user=None, cql_pass=None):
    '''
    List permissions.

    :param username:       The name of the user to list permissions for.
    :type  username:       str
    :param resource:       The resource (keyspace or table), if None, permissions for all resources are listed.
    :type  resource:       str
    :param resource_type:  The resource_type (keyspace or table), defaults to 'keyspace'.
    :type  resource_type:  str
    :param permission:     A permission name (e.g. select), if None, all permissions are listed.
    :type  permission:     str
    :param contact_points: The Cassandra cluster addresses, can either be a string or a list of IPs.
    :type  contact_points: str | list[str]
    :param cql_user:       The Cassandra user if authentication is turned on.
    :type  cql_user:       str
    :param cql_pass:       The Cassandra user password if authentication is turned on.
    :type  cql_pass:       str
    :param port:           The Cassandra cluster port, defaults to None.
    :type  port:           int
    :return:               Dictionary of permissions.
    :rtype:                dict

    CLI Example:

    .. code-block:: bash

        salt 'minion1' cassandra_cql.list_permissions

        salt 'minion1' cassandra_cql.list_permissions username=joe resource=test_keyspace permission=select

        salt 'minion1' cassandra_cql.list_permissions username=joe resource=test_table resource_type=table \
          permission=select contact_points=minion1
    '''
    keyspace_cql = "{0} {1}".format(resource_type, resource) if resource else "all keyspaces"
    permission_cql = "{0} permission".format(permission) if permission else "all permissions"
    query = "list {0} on {1}".format(permission_cql, keyspace_cql)

    if username:
        query = "{0} of {1}".format(query, username)

    log.debug("Attempting to list permissions with query '%s'", query)

    ret = {}

    try:
        ret = cql_query(query, contact_points, port, cql_user, cql_pass)
    except CommandExecutionError:
        log.critical('Could not list permissions.')
        raise
    except BaseException as e:
        log.critical('Unexpected error while listing permissions: %s', e)
        raise

    return ret