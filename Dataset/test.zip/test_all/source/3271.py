def _evaluate(self):
        """Lazily retrieve and paginate report results and build Record instances from returned data"""
        if self._elements:
            for element in self._elements:
                yield element
        else:
            for page in itertools.count():
                raw_elements = self._retrieve_raw_elements(page)

                for raw_element in raw_elements:
                    element = self._parse_raw_element(raw_element)
                    self._elements.append(element)
                    yield element
                    if self.__limit and len(self._elements) >= self.__limit:
                        break

                if any([
                    len(raw_elements) < self.page_size,
                    (self.__limit and len(self._elements) >= self.__limit)
                ]):
                    break