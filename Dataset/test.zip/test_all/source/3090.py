def _serialize_parameters(parameters):
        """Serialize some parameters to match python native types with formats
        specified in google api docs like:
        * True/False -> "true"/"false",
        * {"a": 1, "b":2} -> "a:1|b:2"

        :type parameters: dict oif query parameters
        """

        for key, value in parameters.items():
            if isinstance(value, bool):
                parameters[key] = "true" if value else "false"
            elif isinstance(value, dict):
                parameters[key] = "|".join(
                    ("%s:%s" % (k, v) for k, v in value.items()))
            elif isinstance(value, (list, tuple)):
                parameters[key] = "|".join(value)
        return parameters