def set_dependencies(analysis, dependencies, path):
    """
    Syncronize the Analysis result with the needed dependencies.
    """

    for toc in (analysis.binaries, analysis.datas):
        for i, tpl in enumerate(toc):
            if not tpl[1] in dependencies.keys():
                logger.info("Adding dependency %s located in %s" % (tpl[1], path))
                dependencies[tpl[1]] = path
            else:
                dep_path = get_relative_path(path, dependencies[tpl[1]])
                logger.info("Referencing %s to be a dependecy for %s, located in %s" % (tpl[1], path, dep_path))
                analysis.dependencies.append((":".join((dep_path, tpl[0])), tpl[1], "DEPENDENCY"))
                toc[i] = (None, None, None)
        # Clean the list
        toc[:] = [tpl for tpl in toc if tpl != (None, None, None)]