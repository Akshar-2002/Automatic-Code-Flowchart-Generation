def get_uid(user=None):
    '''
    Get the uid for a given user name. If no user given, the current euid will
    be returned. If the user does not exist, None will be returned. On systems
    which do not support pwd or os.geteuid, None will be returned.
    '''
    if not HAS_PWD:
        return None
    elif user is None:
        try:
            return os.geteuid()
        except AttributeError:
            return None
    else:
        try:
            return pwd.getpwnam(user).pw_uid
        except KeyError:
            return None