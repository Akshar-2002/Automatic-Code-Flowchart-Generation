def update(self, scriptid, params=None):
        ''' /v1/startupscript/update
        POST - account
        Update an existing startup script

        Link: https://www.vultr.com/api/#startupscript_update
        '''
        params = update_params(params, {'SCRIPTID': scriptid})
        return self.request('/v1/startupscript/update', params, 'POST')