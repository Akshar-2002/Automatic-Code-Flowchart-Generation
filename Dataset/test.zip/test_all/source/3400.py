def suggest_path(root_dir):
    """List all files and subdirectories in a directory.
    If the directory is not specified, suggest root directory,
    user directory, current and parent directory.
    :param root_dir: string: directory to list
    :return: list
    """
    if not root_dir:
        return [os.path.abspath(os.sep), '~', os.curdir, os.pardir]

    if '~' in root_dir:
        root_dir = os.path.expanduser(root_dir)

    if not os.path.exists(root_dir):
        root_dir, _ = os.path.split(root_dir)

    return list_path(root_dir)