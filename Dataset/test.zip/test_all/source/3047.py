def get_smtp_mail(self):
        """
        Returns the SMTP formatted email, as it may be passed to sendmail.

        :rtype:  string
        :return: The SMTP formatted mail.
        """
        header = self.get_smtp_header()
        body = self.get_body().replace('\n', '\r\n')
        return header + '\r\n' + body + '\r\n'