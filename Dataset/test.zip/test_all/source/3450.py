def selection_pos(self):
        """Return start and end positions of the visual selection respectively."""
        buff = self._vim.current.buffer
        beg = buff.mark('<')
        end = buff.mark('>')
        return beg, end