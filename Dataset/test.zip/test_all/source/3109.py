def on_ok(self, sender):
        """
        This callback is called when one task reaches status `S_OK`.
        It removes the WFKQ file if all its children have reached `S_OK`.
        """
        if self.remove_wfkq:
            for task in self.wfkq_tasks:
                if task.status != task.S_OK: continue
                children = self.wfkq_task_children[task]
                if all(child.status == child.S_OK for child in children):
                   path = task.outdir.has_abiext("WFQ")
                   if path:
                       self.history.info("Removing WFQ: %s" % path)
                       os.remove(path)

        # If wfk task we create a link to a wfq file so abinit is happy
        if sender == self.wfk_task:
            wfk_path = self.wfk_task.outdir.has_abiext("WFK")
            # Check if netcdf
            filename, extension = os.path.splitext(wfk_path)
            infile = 'out_WFQ' + extension
            infile = os.path.join(os.path.dirname(wfk_path), infile)
            os.symlink(wfk_path, infile)

        return super().on_ok(sender)