def register_new_suffix_tree(case_insensitive=False):
    """Factory method, returns new suffix tree object.
    """
    assert isinstance(case_insensitive, bool)
    root_node = register_new_node()

    suffix_tree_id = uuid4()
    event = SuffixTree.Created(
        originator_id=suffix_tree_id,
        root_node_id=root_node.id,
        case_insensitive=case_insensitive,
    )
    entity = SuffixTree.mutate(event=event)

    assert isinstance(entity, SuffixTree)

    entity.nodes[root_node.id] = root_node

    publish(event)

    return entity