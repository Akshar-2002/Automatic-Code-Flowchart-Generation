def list(self):
        '''
        View the list of the pages.
        '''
        kwd = {
            'pager': '',
            'title': '单页列表',
        }
        self.render('wiki_page/page_list.html',
                    kwd=kwd,
                    view=MWiki.query_recent(),
                    view_all=MWiki.query_all(),
                    format_date=tools.format_date,
                    userinfo=self.userinfo,
                    cfg=CMS_CFG)